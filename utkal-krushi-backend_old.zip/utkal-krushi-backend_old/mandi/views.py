import os
import json
import logging
import requests
from pathlib import Path
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from django.core.cache import cache

logger = logging.getLogger(__name__)

# ── Data.gov.in Configuration ─────────────────────────────────
DATA_GOV_API_KEY = os.environ.get(
    "DATA_GOV_IN_API_KEY",
    "579b464db66ec23bdd0000011221b0e6da4a4da94502983f5c1e8002"
)
RESOURCE_ID = "9ef74154-802f-4a05-9b35-a6d17e17094b"  # Agmarknet Daily Prices Resource
BASE_OGD_URL = f"https://api.data.gov.in/resource/{RESOURCE_ID}"

FALLBACK_FILE = Path(__file__).parent / "seed_json" / "mandi_prices.json"


def fetch_live_ogd_mandi(district=None, commodity=None):
    """
    Fetches live commodity prices from data.gov.in (Agmarknet).
    Caches results for 30 minutes.
    """
    cache_key = f"ogd_mandi_odisha_{district}_{commodity}".lower().replace(" ", "_")
    cached = cache.get(cache_key)
    if cached:
        return cached

    params = {
        "api-key": DATA_GOV_API_KEY,
        "format": "json",
        "limit": 150,
        "filters[state]": "Odisha",
    }

    try:
        response = requests.get(BASE_OGD_URL, params=params, timeout=5)
        if response.status_code == 200:
            data = response.json()
            records = data.get("records", [])

            if records:
                formatted_records = []
                for r in records:
                    rec_dist = str(r.get("district", "")).strip()
                    rec_comm = str(r.get("commodity", "")).strip()

                    if district and district.lower() not in rec_dist.lower():
                        continue
                    if commodity and commodity.lower() not in rec_comm.lower():
                        continue

                    formatted_records.append({
                        "commodity": rec_comm or "General Crop",
                        "market": r.get("market", "District Mandi"),
                        "district": rec_dist or "Odisha",
                        "variety": r.get("variety", "Standard"),
                        "min_price": float(r.get("min_price", 0)),
                        "max_price": float(r.get("max_price", 0)),
                        "modal_price": float(r.get("modal_price", 0)),
                        "date": r.get("arrival_date", "Today"),
                        "unit": "₹/quintal",
                        "source": "data.gov.in (Agmarknet Live)",
                        "is_live": True,
                    })

                if formatted_records:
                    cache.set(cache_key, formatted_records, 60 * 30)  # 30 min cache
                    return formatted_records

    except Exception as e:
        logger.warning(f"Failed to fetch live data.gov.in Mandi prices: {e}")

    return None


def get_fallback_mandi_prices(district=None, commodity=None):
    """Fallback local seed data when government API is offline."""
    default_records = [
        {"commodity": "Paddy (Common)", "market": "Cuttack Mandi", "district": "Cuttack", "min_price": 2040, "max_price": 2183, "modal_price": 2183, "date": "Today", "unit": "₹/quintal", "source": "Odisha Agmarknet (Baseline)", "is_live": False},
        {"commodity": "Rice", "market": "Khordha Central Market", "district": "Khordha", "min_price": 2850, "max_price": 3100, "modal_price": 2980, "date": "Today", "unit": "₹/quintal", "source": "Odisha Agmarknet (Baseline)", "is_live": False},
        {"commodity": "Maize", "market": "Nabarangpur Mandi", "district": "Nabarangpur", "min_price": 1750, "max_price": 1960, "modal_price": 1870, "date": "Today", "unit": "₹/quintal", "source": "Odisha Agmarknet (Baseline)", "is_live": False},
        {"commodity": "Potato", "market": "Puri Market Yard", "district": "Puri", "min_price": 1200, "max_price": 1450, "modal_price": 1350, "date": "Today", "unit": "₹/quintal", "source": "Odisha Agmarknet (Baseline)", "is_live": False},
        {"commodity": "Onion", "market": "Sambalpur Main Mandi", "district": "Sambalpur", "min_price": 1800, "max_price": 2200, "modal_price": 2000, "date": "Today", "unit": "₹/quintal", "source": "Odisha Agmarknet (Baseline)", "is_live": False},
        {"commodity": "Tomato", "market": "Bhubaneswar Market", "district": "Khordha", "min_price": 1400, "max_price": 1800, "modal_price": 1600, "date": "Today", "unit": "₹/quintal", "source": "Odisha Agmarknet (Baseline)", "is_live": False},
    ]

    if FALLBACK_FILE.exists():
        try:
            with open(FALLBACK_FILE, "r", encoding="utf-8") as f:
                records = json.load(f)
                if isinstance(records, list) and len(records) > 0:
                    default_records = records
        except Exception:
            pass

    filtered = []
    for r in default_records:
        if district and district.lower() not in r.get("district", "").lower():
            continue
        if commodity and commodity.lower() not in r.get("commodity", "").lower():
            continue
        filtered.append(r)

    return filtered if filtered else default_records


@api_view(["GET"])
@permission_classes([AllowAny])
def mandi_prices(request):
    """GET /mandi/prices/?district=Khordha&commodity=Paddy"""
    district = request.query_params.get("district", "").strip()
    commodity = request.query_params.get("commodity", "").strip()

    records = fetch_live_ogd_mandi(district, commodity)

    if not records:
        records = get_fallback_mandi_prices(district, commodity)

    return Response({
        "count": len(records),
        "district_filter": district or "All Odisha",
        "commodity_filter": commodity or "All Commodities",
        "data_gov_connected": any(r.get("is_live") for r in records),
        "records": records
    })


@api_view(["GET"])
@permission_classes([AllowAny])
def mandi_commodities(request):
    """GET /mandi/commodities/"""
    return Response({
        "commodities": ["Paddy", "Rice", "Maize", "Potato", "Onion", "Tomato", "Mustard", "Jute", "Cotton", "Groundnut"]
    })


# ── Backward Compatibility Aliases for urls.py imports ──────────────
mandi_prices_view = mandi_prices
mandi_commodities_view = mandi_commodities