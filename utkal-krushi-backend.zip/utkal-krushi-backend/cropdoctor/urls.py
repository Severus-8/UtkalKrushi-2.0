from django.urls import path
from . import views

def get_v(*names):
    for n in names:
        if hasattr(views, n):
            return getattr(views, n)
    return None

urlpatterns = []
diag = get_v("diagnose", "crop_doctor_diagnose", "diagnose_crop")
if diag:
    urlpatterns += [
        path("diagnose/", diag),
        path("diagnose", diag),
        path("", diag),
    ]
