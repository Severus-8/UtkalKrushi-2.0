from django.urls import path
from . import views

def get_v(*names):
    for n in names:
        if hasattr(views, n):
            return getattr(views, n)
    return None

urlpatterns = []
ent = get_v("entries", "ledger_entries", "get_entries")
if ent: urlpatterns += [path("entries/", ent), path("entries", ent)]

summ = get_v("summary", "ledger_summary", "get_summary")
if summ: urlpatterns += [path("summary/", summ), path("summary", summ)]
