"""
Smart Crop Yield & Fertilizer Calculator -- ML layer.

Two real, dataset-validated models sit behind these endpoints (see
smartyield/ml/train.py for provenance + smartyield/ml/artifacts/metrics.json
for the accuracy report):

  1. Crop-suitability classifier (RandomForest, 2,200 Indian soil/climate
     samples) -> POST /api/smartyield/recommend-crop
  2. Odisha yield regressor (RandomForest, 16,025 real govt. district-yield
     records, 1997-2020) -> POST /api/smartyield/predict-yield

GET /api/smartyield/model-info returns the full validation report so it can
be shown to judges / displayed as a "model accuracy" badge in the UI.
"""
import json
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

import joblib
import pandas as pd
from rest_framework.decorators import api_view
from rest_framework.response import Response

from fertilizer.models import CropFertilizerProfile

ART_DIR = Path(__file__).resolve().parent / "ml" / "artifacts"

ACRE_PER_UNIT = {
    "acre": Decimal("1"), "guntha": Decimal("1") / Decimal("40"),
    "decimal": Decimal("1") / Decimal("100"), "hectare": Decimal("2.471"),
    "bigha": Decimal("0.33"),
}

APP_TO_GOVT_CROP = {
    "paddy": "Rice", "ragi": "Ragi", "moong": "Moong(Green Gram)",
    "mustard": "Rapeseed &Mustard", "groundnut": "Groundnut",
    "chilli": "Dry Chillies", "maize": "Maize",
}

# Cached in-process; Django's autoreloader / gunicorn workers each load once.
_cache = {}


def _load(name):
    if name not in _cache:
        _cache[name] = joblib.load(ART_DIR / f"{name}.joblib")
    return _cache[name]


def _metrics():
    if "metrics" not in _cache:
        with open(ART_DIR / "metrics.json", encoding="utf-8") as fh:
            _cache["metrics"] = json.load(fh)
    return _cache["metrics"]


def _round(value, places=2):
    q = Decimal("0.01") if places == 2 else Decimal("0.1")
    return float(Decimal(str(value)).quantize(q, rounding=ROUND_HALF_UP))


@api_view(["GET"])
def model_info_view(request):
    """Full validation report: dataset provenance, holdout + cross-validated
    accuracy, and the before/after calibration vs the old static baseline."""
    try:
        return Response(_metrics())
    except FileNotFoundError:
        return Response(
            {"detail": "Models not trained yet. Run: python manage.py train_smart_models"},
            status=503,
        )


@api_view(["POST"])
def recommend_crop_view(request):
    """
    Body: {"N": 90, "P": 42, "K": 43, "temperature": 24.5,
           "humidity": 80, "ph": 6.5, "rainfall": 210}
    Returns the top-5 crop suitability predictions with confidence, from
    the RandomForest trained on the 2,200-sample Indian soil/climate dataset.
    """
    data = request.data
    required = ["N", "P", "K", "temperature", "humidity", "ph", "rainfall"]
    missing = [f for f in required if data.get(f) in (None, "")]
    if missing:
        return Response({"detail": f"Missing fields: {', '.join(missing)}"}, status=400)

    try:
        row = pd.DataFrame([{f: float(data[f]) for f in required}])
    except (TypeError, ValueError):
        return Response({"detail": "All fields must be numeric."}, status=400)

    try:
        clf = _load("crop_classifier")
        le = _load("crop_label_encoder")
    except FileNotFoundError:
        return Response(
            {"detail": "Model not trained yet. Run: python manage.py train_smart_models"},
            status=503,
        )

    proba = clf.predict_proba(row)[0]
    ranked = sorted(zip(le.classes_, proba), key=lambda x: -x[1])[:5]
    metrics = _metrics().get("crop_suitability_model", {})

    return Response({
        "recommendations": [
            {"crop": crop, "confidence": _round(p * 100, 2)} for crop, p in ranked
        ],
        "modelAccuracy": {
            "holdoutAccuracy": metrics.get("holdout_test_accuracy"),
            "cv5FoldAccuracy": metrics.get("cv_5fold_accuracy_mean"),
            "trainedOn": f"{metrics.get('n_samples')} real Indian soil/climate samples",
        },
    })


@api_view(["POST"])
def predict_yield_view(request):
    """
    Body: {"crop": "paddy", "district": "Khordha", "season": "Kharif",
           "landArea": 2, "unit": "acre", "year": 2026}
    Returns an ML-predicted yield (qtl/acre), trained on 16,025 real
    district-season-year yield records for Odisha (1997-2020). Falls back
    to the static fertilizer-profile baseline for crops/districts outside
    the training data's coverage, and always says which one was used.
    """
    data = request.data
    crop_id = (data.get("crop") or "").strip().lower()
    district = (data.get("district") or "").strip()
    season = (data.get("season") or "Kharif").strip()
    unit = (data.get("unit") or "acre").lower()

    if unit not in ACRE_PER_UNIT:
        return Response({"detail": f"Unsupported unit '{unit}'"}, status=400)
    try:
        land_area = Decimal(str(data.get("landArea", 1)))
    except Exception:
        return Response({"detail": "landArea must be a number"}, status=400)
    if land_area <= 0:
        return Response({"detail": "landArea must be greater than 0"}, status=400)
    acres = land_area * ACRE_PER_UNIT[unit]

    year = data.get("year")
    try:
        year = int(year) if year else 2024
    except (TypeError, ValueError):
        year = 2024

    govt_crop = APP_TO_GOVT_CROP.get(crop_id)
    metrics = _metrics().get("yield_prediction_model", {})

    profile = CropFertilizerProfile.objects.filter(crop_id=crop_id).first()
    static_qtl_acre = float(profile.yield_qtl_per_acre) if profile else None

    if govt_crop is None:
        # Crop outside the 7 the yield model was trained on -- be honest,
        # don't guess with the ML model, use the calculator's own baseline.
        if static_qtl_acre is None:
            return Response({"detail": f"Unknown crop '{crop_id}'."}, status=404)
        return Response({
            "cropId": crop_id,
            "predictedYieldQtlPerAcre": static_qtl_acre,
            "totalYieldQtl": _round(static_qtl_acre * float(acres)),
            "source": "static_fallback",
            "note": "This crop is outside the yield model's training coverage "
                    "(7 Odisha crops, 1997-2020 govt. data); using the "
                    "fertilizer calculator's standard estimate instead.",
        })

    try:
        reg = _load("yield_regressor")
        district_le = _load("yield_district_encoder")
        crop_le = _load("yield_crop_encoder")
        season_le = _load("yield_season_encoder")
    except FileNotFoundError:
        return Response(
            {"detail": "Model not trained yet. Run: python manage.py train_smart_models"},
            status=503,
        )

    try:
        district_enc = district_le.transform([district])[0]
    except ValueError:
        return Response({
            "detail": f"District '{district}' not found in the Odisha training data.",
            "availableDistricts": sorted(district_le.classes_.tolist()),
        }, status=404)

    crop_enc = crop_le.transform([govt_crop])[0]
    try:
        season_enc = season_le.transform([season])[0]
    except ValueError:
        season_enc = season_le.transform([season_le.classes_[0]])[0]
        season = season_le.classes_[0]

    row = pd.DataFrame([{
        "district_enc": district_enc, "crop_enc": crop_enc,
        "season_enc": season_enc, "year": year,
    }])
    predicted_qtl_acre = float(reg.predict(row)[0])

    return Response({
        "cropId": crop_id,
        "district": district,
        "season": season,
        "year": year,
        "predictedYieldQtlPerAcre": _round(predicted_qtl_acre),
        "totalYieldQtl": _round(predicted_qtl_acre * float(acres)),
        "acres": _round(float(acres)),
        "staticCalculatorEstimateQtlPerAcre": static_qtl_acre,
        "source": "ml_model",
        "modelAccuracy": {
            "holdoutR2": metrics.get("holdout_r2"),
            "holdoutMaeQtlPerAcre": metrics.get("holdout_mae_qtl_per_acre"),
            "cv5FoldR2": metrics.get("cv_5fold_r2_mean"),
            "trainedOn": f"{metrics.get('n_samples')} real Odisha district-season-year "
                         f"records, {metrics.get('years_covered', ['1997','2020'])[0]}"
                         f"-{metrics.get('years_covered', ['1997','2020'])[1]} "
                         "(Govt. of India / data.gov.in)",
        },
    })
