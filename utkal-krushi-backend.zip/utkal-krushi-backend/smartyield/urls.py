from django.urls import path
from . import views

urlpatterns = [
    path("model-info/", views.model_info, name="model-info"),
    path("model-info", views.model_info),
    path("predict-yield/", views.predict_yield, name="predict-yield"),
    path("predict-yield", views.predict_yield),
    path("recommend-crop/", views.recommend_crop, name="recommend-crop"),
    path("recommend-crop", views.recommend_crop),
]
