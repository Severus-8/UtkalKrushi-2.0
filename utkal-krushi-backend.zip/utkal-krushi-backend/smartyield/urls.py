from django.urls import path

from .views import model_info_view, predict_yield_view, recommend_crop_view

urlpatterns = [
    path("model-info", model_info_view),
    path("recommend-crop", recommend_crop_view),
    path("predict-yield", predict_yield_view),
]
