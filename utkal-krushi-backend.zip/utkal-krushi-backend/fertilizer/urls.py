from django.urls import path
from . import views

def get_v(*names):
    for n in names:
        if hasattr(views, n):
            return getattr(views, n)
    return None

urlpatterns = []
calc = get_v("calculate", "calculate_fertilizer", "fertilizer_calc")
if calc:
    urlpatterns += [
        path("calculate/", calc),
        path("calculate", calc),
        path("", calc),
    ]
