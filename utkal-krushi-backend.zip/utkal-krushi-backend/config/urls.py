import importlib.util
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path("admin/", admin.site.urls),
]

# Safe dynamic inclusion of all app URL configurations
APPS = [
    ("accounts", "accounts/"),
    ("weather", "weather/"),
    ("cropdoctor", "cropdoctor/"),
    ("fertilizer", "fertilizer/"),
    ("mandi", "mandi/"),
    ("schemes", "schemes/"),
    ("chatbot", "chatbot/"),
    ("ledger", "ledger/"),
    ("smartyield", "api/smartyield/"),
    ("smartyield", "smartyield/"),
    ("sensors", "api/sensors/"),
    ("sensors", "sensors/"),
]

for app_name, route in APPS:
    mod_name = f"{app_name}.urls"
    if importlib.util.find_spec(mod_name) is not None:
        urlpatterns.append(path(route, include(mod_name)))
