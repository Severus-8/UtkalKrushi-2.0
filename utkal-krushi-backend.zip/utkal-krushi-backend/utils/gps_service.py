"""
GPS & Geolocation Service for Utkal Krushi.
Provides coordinates-to-district mapping and OpenStreetMap Nominatim reverse geocoding.
"""
import requests
import math

# All 30 Odisha Districts with centroid coordinates
ODISHA_DISTRICT_COORDS = {
    "angul": (20.8381, 85.0975, "Angul"),
    "balangir": (20.7084, 83.4759, "Balangir"),
    "balasore": (21.4942, 86.9317, "Balasore"),
    "bargarh": (21.3347, 83.6197, "Bargarh"),
    "bhadrak": (21.0562, 86.4977, "Bhadrak"),
    "boudh": (20.8407, 84.3235, "Boudh"),
    "cuttack": (20.4625, 85.8830, "Cuttack"),
    "deogarh": (21.5333, 84.7333, "Deogarh"),
    "dhenkanal": (20.6706, 85.5989, "Dhenkanal"),
    "gajapati": (18.8167, 84.1500, "Gajapati"),
    "ganjam": (19.3149, 84.7941, "Ganjam (Berhampur)"),
    "jagatsinghpur": (20.2667, 86.1667, "Jagatsinghpur"),
    "jajpur": (20.8337, 86.3363, "Jajpur"),
    "jharsuguda": (21.8550, 84.0075, "Jharsuguda"),
    "kalahandi": (20.1848, 83.4681, "Kalahandi (Bhawanipatna)"),
    "kandhamal": (20.4770, 84.2307, "Kandhamal (Phulbani)"),
    "kendrapara": (20.5014, 86.8617, "Kendrapara"),
    "kendujhar": (21.6288, 85.5817, "Kendujhar (Keonjhar)"),
    "khordha": (20.2961, 85.8245, "Khordha (Bhubaneswar)"),
    "koraput": (18.8145, 82.7108, "Koraput"),
    "malkangiri": (18.3500, 81.9000, "Malkangiri"),
    "mayurbhanj": (21.9419, 86.7217, "Mayurbhanj (Baripada)"),
    "nabarangpur": (19.2333, 82.5500, "Nabarangpur"),
    "nayagarh": (20.0937, 85.0975, "Nayagarh"),
    "nuapada": (20.8333, 82.5333, "Nuapada"),
    "puri": (19.8135, 85.8312, "Puri"),
    "rayagada": (19.1719, 83.4157, "Rayagada"),
    "sambalpur": (21.4669, 83.9756, "Sambalpur"),
    "subarnapur": (20.8333, 83.7500, "Subarnapur (Sonepur)"),
    "sundargarh": (22.2604, 84.8536, "Sundargarh (Rourkela)"),
}


def haversine_distance(lat1, lon1, lat2, lon2):
    """Calculate distance between two coordinates in kilometers using Haversine formula."""
    R = 6371.0  # Earth radius in km

    d_lat = math.radians(lat2 - lat1)
    d_lon = math.radians(lon2 - lon1)

    a = (math.sin(d_lat / 2) ** 2 +
         math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) *
         math.sin(d_lon / 2) ** 2)

    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c


def find_nearest_odisha_district(lat, lon):
    """Find the closest Odisha district based on latitude and longitude."""
    closest_district = None
    min_dist = float("inf")

    for district_key, (d_lat, d_lon, display_name) in ODISHA_DISTRICT_COORDS.items():
        dist = haversine_distance(lat, lon, d_lat, d_lon)
        if dist < min_dist:
            min_dist = dist
            closest_district = {
                "district_key": district_key,
                "district_name": display_name,
                "latitude": d_lat,
                "longitude": d_lon,
                "distance_km": round(dist, 2)
            }

    return closest_district


def reverse_geocode_osm(lat, lon):
    """
    Reverse geocode coordinates using OpenStreetMap Nominatim API.
    Free, no API key required, complies with rate limits (1 req/sec).
    """
    url = f"https://nominatim.openstreetmap.org/reverse"
    params = {
        "lat": lat,
        "lon": lon,
        "format": "json",
        "addressdetails": 1
    }
    headers = {
        "User-Agent": "UtkalKrushiApp/2.0 (Farmer Agriculture Platform)"
    }

    try:
        response = requests.get(url, params=params, headers=headers, timeout=5)
        if response.status_code == 200:
            data = response.json()
            address = data.get("address", {})

            return {
                "village": address.get("village") or address.get("hamlet") or address.get("town") or address.get("suburb", ""),
                "district": address.get("state_district") or address.get("county") or address.get("district", ""),
                "state": address.get("state", ""),
                "postcode": address.get("postcode", ""),
                "display_name": data.get("display_name", "")
            }
    except Exception as e:
        print(f"Error reverse geocoding via OSM: {e}")

    # Fallback to nearest Odisha district if API fails
    nearest = find_nearest_odisha_district(lat, lon)
    return {
        "village": "",
        "district": nearest["district_name"] if nearest else "Odisha",
        "state": "Odisha",
        "postcode": "",
        "display_name": nearest["district_name"] if nearest else ""
    }
