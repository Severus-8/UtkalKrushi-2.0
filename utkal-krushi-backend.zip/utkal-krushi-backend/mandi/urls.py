from django.urls import path
from . import views

urlpatterns = []
prices_v = getattr(views, "mandi_prices", getattr(views, "mandi_prices_view", None))
comm_v = getattr(views, "mandi_commodities", getattr(views, "mandi_commodities_view", None))

if prices_v:
    urlpatterns += [
        path("prices/", prices_v, name="mandi-prices"),
        path("prices", prices_v),
    ]
if comm_v:
    urlpatterns += [
        path("commodities/", comm_v, name="mandi-commodities"),
        path("commodities", comm_v),
    ]
