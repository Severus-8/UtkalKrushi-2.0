from django.db import models
from django.conf import settings

class SensorDevice(models.Model):
    farmer = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="sensor_devices", null=True, blank=True)
    device_id = models.CharField(max_length=64, unique=True)
    sensor_type = models.CharField(max_length=20)
    field_name = models.CharField(max_length=100, default="Main Field")
    district = models.CharField(max_length=50, blank=True)
    is_active = models.BooleanField(default=True)
    registered_at = models.DateTimeField(auto_now_add=True)

class SensorReading(models.Model):
    device = models.ForeignKey(SensorDevice, on_delete=models.CASCADE, related_name="readings")
    value = models.FloatField()
    unit = models.CharField(max_length=10, default="%")
    timestamp = models.DateTimeField(auto_now_add=True)
