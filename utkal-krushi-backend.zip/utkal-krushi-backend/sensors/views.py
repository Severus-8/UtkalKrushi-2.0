from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework import status

from .models import SensorDevice, SensorReading
from .serializers import (
    SensorDeviceSerializer,
    SensorReadingSerializer,
    IngestReadingSerializer,
)


def infer_sensor_type(device_id: str, unit: str = "", explicit: str = "") -> str:
    """Map device_id / unit / explicit type → moisture|ph|temperature|humidity."""
    if explicit:
        t = explicit.lower().strip()
        if t in ("moisture", "ph", "temperature", "humidity", "npk"):
            return t

    d = (device_id or "").upper()
    u = (unit or "").lower()

    if "PH" in d or u in ("ph", "pH"):
        return "ph"
    if "TEMP" in d or u in ("c", "°c", "celsius"):
        return "temperature"
    if "HUM" in d or (u == "%" and "MOIST" not in d and "SOIL" not in d and "HUM" in d):
        return "humidity"
    if "MOIST" in d or "SOIL" in d or u == "%":
        return "moisture"
    if u == "%":
        return "moisture"
    return "moisture"


@api_view(["GET", "POST"])
@permission_classes([AllowAny])
def device_list(request):
    if request.method == "GET":
        devices = SensorDevice.objects.all().order_by("-registered_at")
        return Response(SensorDeviceSerializer(devices, many=True).data)

    data = request.data.copy() if hasattr(request.data, "copy") else dict(request.data)
    if not data.get("sensor_type"):
        data["sensor_type"] = infer_sensor_type(
            data.get("device_id", ""), "", data.get("sensor_type", "")
        )
    ser = SensorDeviceSerializer(data=data)
    if ser.is_valid():
        ser.save()
        return Response(ser.data, status=status.HTTP_201_CREATED)
    return Response(ser.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(["POST"])
@permission_classes([AllowAny])
def ingest_reading(request):
    """
    POST /api/sensors/ingest/
    Body: { "device_id": "SENSOR-MOIST-01", "value": 64.2, "unit": "%", "sensor_type": "moisture" }
    """
    ser = IngestReadingSerializer(data=request.data)
    if not ser.is_valid():
        return Response(ser.errors, status=status.HTTP_400_BAD_REQUEST)

    device_id = ser.validated_data["device_id"]
    value = ser.validated_data["value"]
    unit = ser.validated_data.get("unit", "%")
    explicit_type = request.data.get("sensor_type", "")

    sensor_type = infer_sensor_type(device_id, unit, explicit_type)

    device, created = SensorDevice.objects.get_or_create(
        device_id=device_id,
        defaults={
            "sensor_type": sensor_type,
            "field_name": "Demo Field",
            "is_active": True,
        },
    )

    # Fix old rows that were created with blank/wrong type
    if (not created) and (
        not device.sensor_type
        or device.sensor_type not in ("moisture", "ph", "temperature", "humidity", "npk")
        or device.sensor_type != sensor_type
    ):
        device.sensor_type = sensor_type
        device.is_active = True
        device.save(update_fields=["sensor_type", "is_active"])

    reading = SensorReading.objects.create(device=device, value=value, unit=unit)

    return Response(
        {
            **SensorReadingSerializer(reading).data,
            "device_id": device.device_id,
            "sensor_type": device.sensor_type,
        },
        status=status.HTTP_201_CREATED,
    )


@api_view(["GET"])
@permission_classes([AllowAny])
def latest_readings(request):
    """
    GET /api/sensors/latest/
    Returns:
    {
      "moisture": { "value": 64.2, "unit": "%", "timestamp": "...", "device_id": "..." },
      "ph": { ... }
    }
    """
    result = {}
    devices = SensorDevice.objects.filter(is_active=True)

    for device in devices:
        # Ensure type is usable
        st = (device.sensor_type or "").strip().lower()
        if st not in ("moisture", "ph", "temperature", "humidity", "npk"):
            st = infer_sensor_type(device.device_id, "", "")
            if device.sensor_type != st:
                device.sensor_type = st
                device.save(update_fields=["sensor_type"])

        latest = device.readings.order_by("-timestamp").first()
        if not latest:
            continue

        # Prefer newest reading if multiple devices share a type
        prev = result.get(st)
        if prev is None or str(latest.timestamp) >= str(prev.get("timestamp", "")):
            result[st] = {
                "value": latest.value,
                "unit": latest.unit,
                "timestamp": latest.timestamp,
                "device_id": device.device_id,
                "field_name": getattr(device, "field_name", "") or "",
            }

    return Response(result)


@api_view(["GET"])
@permission_classes([AllowAny])
def reading_history(request, device_id):
    limit = int(request.query_params.get("limit", 24))
    try:
        device = SensorDevice.objects.get(device_id=device_id)
    except SensorDevice.DoesNotExist:
        return Response({"error": "Device not found"}, status=404)
    readings = device.readings.order_by("-timestamp")[:limit]
    return Response(SensorReadingSerializer(readings, many=True).data)