from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework import status
from .models import SensorDevice, SensorReading
from .serializers import SensorDeviceSerializer, SensorReadingSerializer, IngestReadingSerializer

@api_view(["GET", "POST"])
@permission_classes([AllowAny])
def device_list(request):
    if request.method == "GET":
        return Response(SensorDeviceSerializer(SensorDevice.objects.all(), many=True).data)
    ser = SensorDeviceSerializer(data=request.data)
    if ser.is_valid():
        ser.save()
        return Response(ser.data, status=status.HTTP_201_CREATED)
    return Response(ser.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(["POST"])
@permission_classes([AllowAny])
def ingest_reading(request):
    ser = IngestReadingSerializer(data=request.data)
    if not ser.is_valid(): return Response(ser.errors, status=400)
    device, _ = SensorDevice.objects.get_or_create(device_id=ser.validated_data["device_id"])
    reading = SensorReading.objects.create(device=device, value=ser.validated_data["value"], unit=ser.validated_data.get("unit", "%"))
    return Response(SensorReadingSerializer(reading).data, status=201)

@api_view(["GET"])
@permission_classes([AllowAny])
def latest_readings(request):
    devices = SensorDevice.objects.filter(is_active=True)
    res = {}
    for d in devices:
        latest = d.readings.first()
        if latest:
            res[d.sensor_type] = {"value": latest.value, "unit": latest.unit, "timestamp": latest.timestamp, "device_id": d.device_id}
    return Response(res)

@api_view(["GET"])
@permission_classes([AllowAny])
def reading_history(request, device_id):
    try: device = SensorDevice.objects.get(device_id=device_id)
    except SensorDevice.DoesNotExist: return Response({"error": "Not found"}, status=404)
    return Response(SensorReadingSerializer(device.readings.all()[:24], many=True).data)
