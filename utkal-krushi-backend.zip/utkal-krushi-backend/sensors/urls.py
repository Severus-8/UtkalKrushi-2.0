from django.urls import path
from . import views

urlpatterns = [
    path("devices/", views.device_list, name="sensor-devices"),
    path("devices", views.device_list),
    path("ingest/", views.ingest_reading, name="sensor-ingest"),
    path("ingest", views.ingest_reading),
    path("latest/", views.latest_readings, name="sensor-latest"),
    path("latest", views.latest_readings),
    path("history/<str:device_id>/", views.reading_history, name="sensor-history"),
    path("history/<str:device_id>", views.reading_history),
]
