# fix_backend_urls.py
import os
import importlib.util
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

APP_URLS = {
    # 1. Accounts app URLs
    "accounts/urls.py": '''from django.urls import path
from . import views

def get_v(*names):
    for n in names:
        if hasattr(views, n):
            return getattr(views, n)
    return None

urlpatterns = []
reg = get_v("register", "register_farmer", "register_user", "RegisterView", "FarmerRegisterView")
if reg: urlpatterns += [path("register/", reg), path("register", reg)]

log = get_v("login", "login_farmer", "login_user", "LoginView", "FarmerLoginView")
if log: urlpatterns += [path("login/", log), path("login", log)]

prof = get_v("profile", "get_profile", "user_profile", "ProfileView")
if prof: urlpatterns += [path("profile/", prof), path("profile", prof)]
''',

    # 2. Weather app URLs
    "weather/urls.py": '''from django.urls import path
from . import views

def get_v(*names):
    for n in names:
        if hasattr(views, n):
            return getattr(views, n)
    return None

urlpatterns = []
w_view = get_v("get_weather", "weather", "weather_view", "current_weather")
if w_view:
    urlpatterns += [
        path("", w_view),
        path("forecast/", w_view),
        path("forecast", w_view),
    ]
''',

    # 3. CropDoctor app URLs
    "cropdoctor/urls.py": '''from django.urls import path
from . import views

def get_v(*names):
    for n in names:
        if hasattr(views, n):
            return getattr(views, n)
    return None

urlpatterns = []
diag = get_v("diagnose", "crop_doctor_diagnose", "diagnose_crop")
if diag:
    urlpatterns += [
        path("diagnose/", diag),
        path("diagnose", diag),
        path("", diag),
    ]
''',

    # 4. Fertilizer app URLs
    "fertilizer/urls.py": '''from django.urls import path
from . import views

def get_v(*names):
    for n in names:
        if hasattr(views, n):
            return getattr(views, n)
    return None

urlpatterns = []
calc = get_v("calculate", "calculate_fertilizer", "fertilizer_calc")
if calc:
    urlpatterns += [
        path("calculate/", calc),
        path("calculate", calc),
        path("", calc),
    ]
''',

    # 5. Mandi app URLs
    "mandi/urls.py": '''from django.urls import path
from . import views

urlpatterns = []
prices_v = getattr(views, "mandi_prices", getattr(views, "mandi_prices_view", None))
comm_v = getattr(views, "mandi_commodities", getattr(views, "mandi_commodities_view", None))

if prices_v:
    urlpatterns += [
        path("prices/", prices_v, name="mandi-prices"),
        path("prices", prices_v),
    ]
if comm_v:
    urlpatterns += [
        path("commodities/", comm_v, name="mandi-commodities"),
        path("commodities", comm_v),
    ]
''',

    # 6. Schemes app URLs
    "schemes/urls.py": '''from django.urls import path
from . import views

def get_v(*names):
    for n in names:
        if hasattr(views, n):
            return getattr(views, n)
    return None

urlpatterns = []
sch = get_v("schemes", "get_schemes", "schemes_list", "list_schemes")
if sch:
    urlpatterns += [
        path("", sch),
        path("list/", sch),
    ]
''',

    # 7. Chatbot app URLs
    "chatbot/urls.py": '''from django.urls import path
from . import views

def get_v(*names):
    for n in names:
        if hasattr(views, n):
            return getattr(views, n)
    return None

urlpatterns = []
bot = get_v("ask", "ask_chatbot", "chatbot_ask")
if bot:
    urlpatterns += [
        path("ask/", bot),
        path("ask", bot),
        path("", bot),
    ]
''',

    # 8. Ledger app URLs
    "ledger/urls.py": '''from django.urls import path
from . import views

def get_v(*names):
    for n in names:
        if hasattr(views, n):
            return getattr(views, n)
    return None

urlpatterns = []
ent = get_v("entries", "ledger_entries", "get_entries")
if ent: urlpatterns += [path("entries/", ent), path("entries", ent)]

summ = get_v("summary", "ledger_summary", "get_summary")
if summ: urlpatterns += [path("summary/", summ), path("summary", summ)]
''',

    # 9. SmartYield ML URLs
    "smartyield/urls.py": '''from django.urls import path
from . import views

urlpatterns = [
    path("model-info/", views.model_info, name="model-info"),
    path("model-info", views.model_info),
    path("predict-yield/", views.predict_yield, name="predict-yield"),
    path("predict-yield", views.predict_yield),
    path("recommend-crop/", views.recommend_crop, name="recommend-crop"),
    path("recommend-crop", views.recommend_crop),
]
''',

    # 10. Sensors app URLs
    "sensors/urls.py": '''from django.urls import path
from . import views

urlpatterns = [
    path("devices/", views.device_list, name="sensor-devices"),
    path("devices", views.device_list),
    path("ingest/", views.ingest_reading, name="sensor-ingest"),
    path("ingest", views.ingest_reading),
    path("latest/", views.latest_readings, name="sensor-latest"),
    path("latest", views.latest_readings),
    path("history/<str:device_id>/", views.reading_history, name="sensor-history"),
    path("history/<str:device_id>", views.reading_history),
]
''',

    # 11. Master Master config/urls.py
    "config/urls.py": '''import importlib.util
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path("admin/", admin.site.urls),
]

# Safe dynamic inclusion of all app URL configurations
APPS = [
    ("accounts", "accounts/"),
    ("weather", "weather/"),
    ("cropdoctor", "cropdoctor/"),
    ("fertilizer", "fertilizer/"),
    ("mandi", "mandi/"),
    ("schemes", "schemes/"),
    ("chatbot", "chatbot/"),
    ("ledger", "ledger/"),
    ("smartyield", "api/smartyield/"),
    ("smartyield", "smartyield/"),
    ("sensors", "api/sensors/"),
    ("sensors", "sensors/"),
]

for app_name, route in APPS:
    mod_name = f"{app_name}.urls"
    if importlib.util.find_spec(mod_name) is not None:
        urlpatterns.append(path(route, include(mod_name)))
'''
}

def fix_all_urls():
    print("🛠️ Generating missing app urls.py & fixing config/urls.py...")
    for rel_path, content in APP_URLS.items():
        file_path = BASE_DIR / rel_path
        if file_path.parent.exists():
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(content.strip() + "\n")
            print(f"  ✅ Fixed: {rel_path}")
        else:
            print(f"  ⚠️ Skipped: {rel_path} (app directory does not exist)")
    print("\n✨ All URL modules generated successfully!")

if __name__ == "__main__":
    fix_all_urls()