from django.urls import path
from . import views

def get_v(*names):
    for n in names:
        if hasattr(views, n):
            return getattr(views, n)
    return None

urlpatterns = []
w_view = get_v("get_weather", "weather", "weather_view", "current_weather")
if w_view:
    urlpatterns += [
        path("", w_view),
        path("forecast/", w_view),
        path("forecast", w_view),
    ]
