import time
import random
import requests

API = "http://127.0.0.1:8000/api/sensors/ingest/"

DEVICES = [
    {"device_id": "SENSOR-MOIST-01", "sensor_type": "moisture", "base": 64.0, "unit": "%", "jitter": 2.5},
    {"device_id": "SENSOR-PH-01", "sensor_type": "ph", "base": 6.7, "unit": "pH", "jitter": 0.15},
    {"device_id": "SENSOR-TEMP-01", "sensor_type": "temperature", "base": 29.5, "unit": "°C", "jitter": 0.8},
    {"device_id": "SENSOR-HUM-01", "sensor_type": "humidity", "base": 72.0, "unit": "%", "jitter": 3.0},
]

print("📡 Simulator ->", API)
print("Ctrl+C to stop\n")

while True:
    for d in DEVICES:
        val = round(d["base"] + random.uniform(-d["jitter"], d["jitter"]), 2)
        payload = {
            "device_id": d["device_id"],
            "value": val,
            "unit": d["unit"],
            "sensor_type": d["sensor_type"],
        }
        try:
            r = requests.post(API, json=payload, timeout=3)
            print(f"{d['sensor_type']:12} {val:7} {d['unit']:4} -> {r.status_code} {r.text[:80]}")
        except Exception as e:
            print("ERR (is runserver up?):", e)
        time.sleep(0.4)
    time.sleep(3)