import time, random, requests
API = "http://localhost:8000/api/sensors/ingest/"
DEVICES = [{"device_id": "SENSOR-MOIST-01", "base": 64.0, "unit": "%"}, {"device_id": "SENSOR-PH-01", "base": 6.7, "unit": "pH"}]
print("📡 Telemetry Simulator Running...")
while True:
    for d in DEVICES:
        val = round(d["base"] + random.uniform(-1.5, 1.5), 2)
        try: requests.post(API, json={"device_id": d["device_id"], "value": val, "unit": d["unit"]}, timeout=2)
        except Exception: pass
    time.sleep(4)
