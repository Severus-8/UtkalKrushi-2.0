from rest_framework import serializers
from .models import Farmer


class FarmerSerializer(serializers.ModelSerializer):
    has_location = serializers.BooleanField(read_only=True)
    coordinates = serializers.SerializerMethodField()

    class Meta:
        model = Farmer
        fields = [
            "id", "username", "phone", "email", "district", "village",
            "preferred_lang", "land_area_acres",
            "field_latitude", "field_longitude", "auto_gps_enabled",
            "location_last_updated", "has_location", "coordinates",
            "google_id", "profile_picture", "created_at", "updated_at",
        ]
        read_only_fields = ["id", "created_at", "updated_at", "google_id"]

    def get_coordinates(self, obj):
        return obj.get_coordinates()


class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, min_length=6)

    class Meta:
        model = Farmer
        fields = [
            "id", "username", "password", "phone", "email", "district",
            "village", "preferred_lang", "land_area_acres",
            "field_latitude", "field_longitude", "auto_gps_enabled",
        ]

    def create(self, validated_data):
        password = validated_data.pop("password")
        farmer = Farmer(**validated_data)
        farmer.set_password(password)
        farmer.save()
        return farmer


class UpdateLocationSerializer(serializers.Serializer):
    """Serializer for updating GPS location"""
    field_latitude = serializers.DecimalField(max_digits=9, decimal_places=6)
    field_longitude = serializers.DecimalField(max_digits=9, decimal_places=6)
    auto_gps_enabled = serializers.BooleanField(required=False, default=True)


class GoogleAuthSerializer(serializers.Serializer):
    """Serializer for Google OAuth token"""
    token = serializers.CharField(required=True, help_text="Google OAuth ID token")
