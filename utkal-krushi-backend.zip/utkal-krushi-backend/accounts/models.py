from django.contrib.auth.models import AbstractUser
from django.db import models


class Farmer(AbstractUser):
    """Custom user model for a farmer's profile with GPS field location tracking."""
    phone = models.CharField(max_length=15, unique=True)
    district = models.CharField(max_length=100, blank=True)
    village = models.CharField(max_length=100, blank=True)
    preferred_lang = models.CharField(
        max_length=5,
        choices=[("en", "English"), ("or", "Odia"), ("hi", "Hindi")],
        default="or",
    )
    land_area_acres = models.DecimalField(max_digits=6, decimal_places=2, null=True, blank=True)

    # GPS Location Fields (Phase 1 - Rain Prediction System)
    field_latitude = models.DecimalField(
        max_digits=9,
        decimal_places=6,
        null=True,
        blank=True,
        help_text="Automatically captured from GPS or manually entered"
    )
    field_longitude = models.DecimalField(
        max_digits=9,
        decimal_places=6,
        null=True,
        blank=True,
        help_text="Automatically captured from GPS or manually entered"
    )
    auto_gps_enabled = models.BooleanField(
        default=True,
        help_text="Enable automatic GPS location capture for weather/rain alerts"
    )
    location_last_updated = models.DateTimeField(null=True, blank=True)

    # Google OAuth fields
    google_id = models.CharField(max_length=255, unique=True, null=True, blank=True)
    profile_picture = models.URLField(max_length=500, blank=True)

    # Account metadata
    created_at = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    USERNAME_FIELD = "username"
    REQUIRED_FIELDS = ["phone"]

    def __str__(self):
        return f"{self.username} ({self.phone})"

    def has_location(self):
        """Check if farmer has valid GPS coordinates"""
        return self.field_latitude is not None and self.field_longitude is not None

    def get_coordinates(self):
        """Return coordinates as tuple or None"""
        if self.has_location():
            return (float(self.field_latitude), float(self.field_longitude))
        return None
