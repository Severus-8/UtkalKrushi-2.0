import os
import sys
import requests
from django.contrib.auth import authenticate
from django.utils import timezone
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken

# Add utils to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from utils.gps_service import find_nearest_odisha_district, reverse_geocode_osm

from .models import Farmer
from .serializers import (
    RegisterSerializer,
    FarmerSerializer,
    UpdateLocationSerializer,
    GoogleAuthSerializer,
)


def _tokens_for(farmer):
    refresh = RefreshToken.for_user(farmer)
    return {"access": str(refresh.access_token), "refresh": str(refresh)}


class RegisterView(APIView):
    """POST /accounts/register/  {username, password, phone, district, village, preferred_lang, field_latitude, field_longitude}"""
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        farmer = serializer.save()
        return Response(
            {"farmer": FarmerSerializer(farmer).data, **_tokens_for(farmer)},
            status=status.HTTP_201_CREATED,
        )


class LoginView(APIView):
    """POST /accounts/login/  {username, password}"""
    permission_classes = [AllowAny]

    def post(self, request):
        username = request.data.get("username")
        password = request.data.get("password")
        farmer = authenticate(request, username=username, password=password)
        if farmer is None:
            return Response({"detail": "Invalid credentials"}, status=status.HTTP_401_UNAUTHORIZED)
        return Response({"farmer": FarmerSerializer(farmer).data, **_tokens_for(farmer)})


class ProfileView(APIView):
    """GET/PUT /accounts/profile/"""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        return Response(FarmerSerializer(request.user).data)

    def put(self, request):
        serializer = FarmerSerializer(request.user, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


class UpdateLocationView(APIView):
    """POST /accounts/location/ - Update farmer GPS coordinates"""
    permission_classes = [IsAuthenticated]

    def post(self, request):
        serializer = UpdateLocationSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        user = request.user
        user.field_latitude = serializer.validated_data["field_latitude"]
        user.field_longitude = serializer.validated_data["field_longitude"]
        user.auto_gps_enabled = serializer.validated_data.get("auto_gps_enabled", True)
        user.location_last_updated = timezone.now()
        user.save()

        return Response({
            "status": "success",
            "message": "Field location updated successfully",
            "coordinates": (float(user.field_latitude), float(user.field_longitude)),
            "farmer": FarmerSerializer(user).data
        })


class GoogleAuthView(APIView):
    """POST /accounts/google/ - Google OAuth Sign-in / Sign-up"""
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = GoogleAuthSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        token = serializer.validated_data["token"]

        # Get user info from request (sent by frontend) or verify token
        google_id = request.data.get("sub")
        email = request.data.get("email")
        name = request.data.get("name", "")
        picture = request.data.get("picture", "")

        # If frontend didn't send user info, verify access token
        if not google_id:
            try:
                google_response = requests.get(
                    "https://www.googleapis.com/oauth2/v3/userinfo",
                    headers={"Authorization": f"Bearer {token}"},
                    timeout=5
                )
                if google_response.status_code != 200:
                    return Response(
                        {"detail": "Invalid Google token"},
                        status=status.HTTP_400_BAD_REQUEST
                    )

                google_data = google_response.json()
                google_id = google_data.get("sub")
                email = google_data.get("email")
                name = google_data.get("name", "")
                picture = google_data.get("picture", "")
            except requests.RequestException:
                return Response(
                    {"detail": "Failed to verify Google token"},
                    status=status.HTTP_400_BAD_REQUEST
                )

        # Check if farmer exists by google_id or email
        farmer = Farmer.objects.filter(google_id=google_id).first()
            if not farmer and email:
                farmer = Farmer.objects.filter(email=email).first()

            if farmer:
                # Update existing farmer info
                farmer.google_id = google_id
                if picture:
                    farmer.profile_picture = picture
                farmer.save()
            else:
                # Create new farmer account
                username = email.split("@")[0] if email else f"farmer_{google_id[:8]}"
                # Handle username collision
                base_username = username
                counter = 1
                while Farmer.objects.filter(username=username).exists():
                    username = f"{base_username}_{counter}"
                    counter += 1

                # Generate a temporary phone if not provided (phone is required by model)
                dummy_phone = f"+91{google_id[:10]}" if len(google_id) >= 10 else f"+91999999{google_id}"

                farmer = Farmer.objects.create(
                    username=username,
                    email=email,
                    phone=dummy_phone,
                    google_id=google_id,
                    profile_picture=picture,
                    first_name=name.split()[0] if name else "",
                    last_name=" ".join(name.split()[1:]) if len(name.split()) > 1 else "",
                )

            return Response(
                {
                    "farmer": FarmerSerializer(farmer).data,
                    "is_new_user": farmer.phone.startswith("+91999999"),
                    **_tokens_for(farmer),
                },
                status=status.HTTP_200_OK,
            )

        except requests.RequestException as e:
            return Response(
                {"detail": f"Error contacting Google authentication service: {str(e)}"},
                status=status.HTTP_503_SERVICE_UNAVAILABLE
            )


@api_view(["POST", "GET"])
@permission_classes([AllowAny])
def auto_detect_location(request):
    """
    POST/GET /accounts/detect-location/
    Params / Body: { "lat": 20.2961, "lon": 85.8245 }
    Returns auto-detected district, village, and sets it on user profile if logged in.
    """
    lat = request.data.get("lat") or request.query_params.get("lat")
    lon = request.data.get("lon") or request.query_params.get("lon")

    if not lat or not lon:
        return Response(
            {"detail": "Please provide 'lat' and 'lon' parameters"},
            status=status.HTTP_400_BAD_REQUEST
        )

    try:
        lat = float(lat)
        lon = float(lon)
    except (ValueError, TypeError):
        return Response(
            {"detail": "Invalid coordinates format"},
            status=status.HTTP_400_BAD_REQUEST
        )

    # 1. Reverse geocode via OpenStreetMap
    geo_data = reverse_geocode_osm(lat, lon)

    # 2. Match nearest Odisha District
    nearest_district = find_nearest_odisha_district(lat, lon)

    # 3. If user is authenticated, update their field location automatically
    if request.user.is_authenticated:
        user = request.user
        user.field_latitude = lat
        user.field_longitude = lon
        if not user.district and nearest_district:
            user.district = nearest_district["district_name"]
        if not user.village and geo_data.get("village"):
            user.village = geo_data["village"]
        user.location_last_updated = timezone.now()
        user.save()

    return Response({
        "status": "success",
        "coordinates": {"lat": lat, "lon": lon},
        "detected_district": nearest_district["district_name"] if nearest_district else geo_data.get("district", ""),
        "detected_village": geo_data.get("village", ""),
        "state": geo_data.get("state", "Odisha"),
        "full_address": geo_data.get("display_name", ""),
        "nearest_district_distance_km": nearest_district["distance_km"] if nearest_district else 0
    })

