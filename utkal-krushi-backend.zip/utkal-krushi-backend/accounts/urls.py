from django.urls import path
from .views import (
    RegisterView,
    LoginView,
    ProfileView,
    UpdateLocationView,
    GoogleAuthView,
    auto_detect_location,
)

urlpatterns = [
    path("register/", RegisterView.as_view(), name="register"),
    path("register", RegisterView.as_view()),
    path("login/", LoginView.as_view(), name="login"),
    path("login", LoginView.as_view()),
    path("profile/", ProfileView.as_view(), name="profile"),
    path("profile", ProfileView.as_view()),
    path("location/", UpdateLocationView.as_view(), name="update_location"),
    path("location", UpdateLocationView.as_view()),
    path("google/", GoogleAuthView.as_view(), name="google_auth"),
    path("google", GoogleAuthView.as_view()),
    path("detect-location/", auto_detect_location, name="auto_detect_location"),
    path("detect-location", auto_detect_location),
]