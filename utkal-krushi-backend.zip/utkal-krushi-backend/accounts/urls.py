from django.urls import path
from . import views

def get_view_func(name):
    v = getattr(views, name, None)
    if v is None:
        return None
    # If it's a Class-Based View, call .as_view()
    if hasattr(v, 'as_view'):
        return v.as_view()
    return v

urlpatterns = []

# Register endpoint
reg_view = None
for name in ["RegisterView", "FarmerRegisterView", "register", "register_farmer", "register_user"]:
    reg_view = get_view_func(name)
    if reg_view:
        break

if reg_view:
    urlpatterns += [
        path("register/", reg_view, name="register"),
        path("register", reg_view),
    ]

# Login endpoint
login_view = None
for name in ["LoginView", "FarmerLoginView", "login", "login_farmer", "login_user"]:
    login_view = get_view_func(name)
    if login_view:
        break

if login_view:
    urlpatterns += [
        path("login/", login_view, name="login"),
        path("login", login_view),
    ]

# Profile endpoint
profile_view = None
for name in ["ProfileView", "FarmerProfileView", "profile", "get_profile", "user_profile"]:
    profile_view = get_view_func(name)
    if profile_view:
        break

if profile_view:
    urlpatterns += [
        path("profile/", profile_view, name="profile"),
        path("profile", profile_view),
    ]