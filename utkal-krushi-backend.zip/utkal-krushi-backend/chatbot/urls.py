from django.urls import path
from . import views

def get_v(*names):
    for n in names:
        if hasattr(views, n):
            return getattr(views, n)
    return None

urlpatterns = []
bot = get_v("ask", "ask_chatbot", "chatbot_ask")
if bot:
    urlpatterns += [
        path("ask/", bot),
        path("ask", bot),
        path("", bot),
    ]
