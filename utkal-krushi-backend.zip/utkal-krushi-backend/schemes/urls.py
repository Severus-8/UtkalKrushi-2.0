from django.urls import path
from . import views

def get_v(*names):
    for n in names:
        if hasattr(views, n):
            return getattr(views, n)
    return None

urlpatterns = []
sch = get_v("schemes", "get_schemes", "schemes_list", "list_schemes")
if sch:
    urlpatterns += [
        path("", sch),
        path("list/", sch),
    ]
