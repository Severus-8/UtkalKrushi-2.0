from django.apps import AppConfig


class RainforecastConfig(AppConfig):
    name = 'rainforecast'
