from django.db import models
from django.conf import settings


class RainPrediction(models.Model):
    """Stores rain prediction results with confidence scores and data sources"""
    farmer = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="rain_predictions",
        null=True,
        blank=True
    )
    latitude = models.DecimalField(max_digits=9, decimal_places=6)
    longitude = models.DecimalField(max_digits=9, decimal_places=6)
    district = models.CharField(max_length=100, blank=True)

    # Prediction results
    rain_probability = models.FloatField(help_text="0-100 percentage")
    confidence_score = models.FloatField(help_text="0-100 confidence level")

    # Contributing sources and their individual predictions
    local_algorithm_score = models.FloatField(null=True, blank=True)
    open_meteo_score = models.FloatField(null=True, blank=True)
    nasa_power_score = models.FloatField(null=True, blank=True)
    sensor_data_score = models.FloatField(null=True, blank=True)

    # Source agreement percentage
    sources_agreement = models.FloatField(null=True, blank=True)

    # Weather data used for prediction
    pressure = models.FloatField(null=True, blank=True, help_text="hPa")
    humidity = models.FloatField(null=True, blank=True, help_text="percentage")
    temperature = models.FloatField(null=True, blank=True, help_text="Celsius")
    wind_speed = models.FloatField(null=True, blank=True, help_text="km/h")
    cloud_cover = models.FloatField(null=True, blank=True, help_text="percentage")

    # Metadata
    prediction_time = models.DateTimeField(auto_now_add=True)
    valid_until = models.DateTimeField()

    class Meta:
        ordering = ['-prediction_time']
        indexes = [
            models.Index(fields=['farmer', '-prediction_time']),
            models.Index(fields=['latitude', 'longitude', '-prediction_time']),
        ]

    def __str__(self):
        return f"Rain {self.rain_probability}% @ {self.district} ({self.prediction_time})"


class IrrigationAlert(models.Model):
    """Stores irrigation recommendations based on rain predictions"""
    ALERT_TYPES = [
        ('skip', 'Skip Irrigation'),
        ('reduce', 'Reduce Irrigation'),
        ('normal', 'Normal Irrigation'),
        ('increase', 'Increase Irrigation'),
    ]

    farmer = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="irrigation_alerts"
    )
    prediction = models.ForeignKey(
        RainPrediction,
        on_delete=models.CASCADE,
        related_name="alerts"
    )

    alert_type = models.CharField(max_length=20, choices=ALERT_TYPES)
    recommendation = models.TextField(help_text="Detailed recommendation message")
    water_savings_liters = models.FloatField(null=True, blank=True)

    # Alert visibility
    is_active = models.BooleanField(default=True)
    dismissed_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.alert_type} for {self.farmer.username} - {self.recommendation[:50]}"
