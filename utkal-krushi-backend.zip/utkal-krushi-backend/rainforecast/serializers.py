from rest_framework import serializers
from .models import RainPrediction, IrrigationAlert


class RainPredictionSerializer(serializers.ModelSerializer):
    class Meta:
        model = RainPrediction
        fields = [
            'id', 'farmer', 'latitude', 'longitude', 'district',
            'rain_probability', 'confidence_score',
            'local_algorithm_score', 'open_meteo_score', 'nasa_power_score', 'sensor_data_score',
            'sources_agreement',
            'pressure', 'humidity', 'temperature', 'wind_speed', 'cloud_cover',
            'prediction_time', 'valid_until'
        ]
        read_only_fields = ['id', 'prediction_time']


class IrrigationAlertSerializer(serializers.ModelSerializer):
    prediction_data = RainPredictionSerializer(source='prediction', read_only=True)

    class Meta:
        model = IrrigationAlert
        fields = [
            'id', 'farmer', 'prediction', 'prediction_data',
            'alert_type', 'recommendation', 'water_savings_liters',
            'is_active', 'dismissed_at', 'created_at', 'expires_at'
        ]
        read_only_fields = ['id', 'created_at']
