from django.urls import path
from .views import (
    predict_rain,
    irrigation_advice,
    active_alerts,
    dismiss_alert
)

urlpatterns = [
    path("predict/", predict_rain, name="predict_rain"),
    path("predict", predict_rain),
    path("irrigation-advice/", irrigation_advice, name="irrigation_advice"),
    path("irrigation-advice", irrigation_advice),
    path("active-alerts/", active_alerts, name="active_alerts"),
    path("active-alerts", active_alerts),
    path("dismiss-alert/", dismiss_alert, name="dismiss_alert"),
    path("dismiss-alert", dismiss_alert),
]
