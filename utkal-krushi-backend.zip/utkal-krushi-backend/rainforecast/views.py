"""
Rain Forecast API Views
Endpoints:
- GET /api/rain-forecast/predict/ - Generate rain prediction with cross-validation
- GET /api/rain-forecast/irrigation-advice/ - Get irrigation recommendation
- GET /api/rain-forecast/active-alerts/ - Get user's active alerts
- POST /api/rain-forecast/dismiss-alert/ - Dismiss an alert
"""
from datetime import datetime, timedelta
from django.utils import timezone
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.response import Response

from .models import RainPrediction, IrrigationAlert
from .serializers import RainPredictionSerializer, IrrigationAlertSerializer
from .algorithm import (
    calculate_rain_probability_local,
    cross_validate_predictions,
    generate_irrigation_recommendation
)
from .data_sources import (
    fetch_open_meteo_data,
    fetch_nasa_power_data,
    fetch_sensor_data_for_farmer
)
from utils.gps_service import find_nearest_odisha_district


@api_view(["GET", "POST"])
@permission_classes([AllowAny])
def predict_rain(request):
    """
    GET/POST /api/rain-forecast/predict/
    Params: lat, lon (or uses authenticated user's field location)

    Returns comprehensive rain prediction with cross-validation.
    """
    # Get coordinates
    lat = request.data.get("lat") or request.query_params.get("lat")
    lon = request.data.get("lon") or request.query_params.get("lon")

    farmer = request.user if request.user.is_authenticated else None

    # Use farmer's field location if available
    if not lat or not lon:
        if farmer and farmer.has_location():
            coords = farmer.get_coordinates()
            if coords:
                lat, lon = coords

    if not lat or not lon:
        return Response(
            {"detail": "Please provide 'lat' and 'lon' or update your profile location"},
            status=status.HTTP_400_BAD_REQUEST
        )

    try:
        lat = float(lat)
        lon = float(lon)
    except (ValueError, TypeError):
        return Response(
            {"detail": "Invalid coordinates format"},
            status=status.HTTP_400_BAD_REQUEST
        )

    # Detect district
    district_info = find_nearest_odisha_district(lat, lon)
    district_name = district_info["district_name"] if district_info else "Odisha"

    # --- PHASE 3: Fetch data from multiple sources ---

    # 1. Open-Meteo Weather Data
    open_meteo = fetch_open_meteo_data(lat, lon)

    # 2. NASA POWER Satellite Data
    nasa_data = fetch_nasa_power_data(lat, lon)

    # 3. Field Sensor Data (if available)
    sensor_data = fetch_sensor_data_for_farmer(farmer) if farmer else None

    if not open_meteo:
        return Response(
            {"detail": "Unable to fetch weather data. Please try again."},
            status=status.HTTP_503_SERVICE_UNAVAILABLE
        )

    # --- PHASE 4: Run Local Algorithm ---
    local_prediction = calculate_rain_probability_local(
        pressure=open_meteo.get("pressure"),
        humidity=open_meteo.get("humidity"),
        temperature=open_meteo.get("temperature"),
        wind_speed=open_meteo.get("wind_speed"),
        cloud_cover=open_meteo.get("cloud_cover"),
        sensor_moisture=sensor_data.get("moisture") if sensor_data else None
    )

    # --- PHASE 5: Cross-Validate All Sources ---
    cross_validated = cross_validate_predictions(
        local_pred=local_prediction,
        open_meteo_prob=open_meteo.get("precipitation_probability"),
        nasa_prob=nasa_data.get("estimated_probability") if nasa_data else None,
        sensor_based_prob=None  # Could implement sensor-only prediction
    )

    # --- Save Prediction to Database ---
    prediction = RainPrediction.objects.create(
        farmer=farmer,
        latitude=lat,
        longitude=lon,
        district=district_name,
        rain_probability=cross_validated["final_rain_probability"],
        confidence_score=cross_validated["final_confidence"],
        local_algorithm_score=cross_validated["local_algorithm_score"],
        open_meteo_score=cross_validated["open_meteo_score"],
        nasa_power_score=cross_validated["nasa_power_score"],
        sensor_data_score=cross_validated["sensor_data_score"],
        sources_agreement=cross_validated["sources_agreement"],
        pressure=open_meteo.get("pressure"),
        humidity=open_meteo.get("humidity"),
        temperature=open_meteo.get("temperature"),
        wind_speed=open_meteo.get("wind_speed"),
        cloud_cover=open_meteo.get("cloud_cover"),
        valid_until=timezone.now() + timedelta(hours=12)
    )

    return Response({
        "status": "success",
        "prediction": RainPredictionSerializer(prediction).data,
        "reasoning": local_prediction.get("reasoning"),
        "data_sources_used": {
            "open_meteo": open_meteo is not None,
            "nasa_power": nasa_data is not None,
            "field_sensors": sensor_data is not None
        }
    })


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def irrigation_advice(request):
    """
    GET /api/rain-forecast/irrigation-advice/
    Returns irrigation recommendation based on latest rain prediction.
    """
    farmer = request.user

    # Get latest valid prediction for this farmer
    prediction = RainPrediction.objects.filter(
        farmer=farmer,
        valid_until__gte=timezone.now()
    ).order_by('-prediction_time').first()

    if not prediction:
        # Generate fresh prediction if none exists
        if not farmer.has_location():
            return Response(
                {"detail": "Please set your field location first"},
                status=status.HTTP_400_BAD_REQUEST
            )

        coords = farmer.get_coordinates()
        # Recursively call predict_rain logic (simplified - you could refactor)
        return Response({
            "detail": "No recent prediction found. Please visit /api/rain-forecast/predict/ first."
        }, status=status.HTTP_404_NOT_FOUND)

    # --- PHASE 6: Generate Irrigation Recommendation ---
    land_area = float(farmer.land_area_acres) if farmer.land_area_acres else 1.0
    recommendation = generate_irrigation_recommendation(
        rain_probability=prediction.rain_probability,
        confidence=prediction.confidence_score,
        land_area_acres=land_area
    )

    # Create or update alert
    alert, created = IrrigationAlert.objects.get_or_create(
        farmer=farmer,
        prediction=prediction,
        is_active=True,
        defaults={
            'alert_type': recommendation['alert_type'],
            'recommendation': recommendation['recommendation'],
            'water_savings_liters': recommendation['water_savings_liters'],
            'expires_at': timezone.now() + timedelta(hours=recommendation['expires_hours'])
        }
    )

    if not created:
        # Update existing alert
        alert.alert_type = recommendation['alert_type']
        alert.recommendation = recommendation['recommendation']
        alert.water_savings_liters = recommendation['water_savings_liters']
        alert.expires_at = timezone.now() + timedelta(hours=recommendation['expires_hours'])
        alert.save()

    return Response({
        "status": "success",
        "alert": IrrigationAlertSerializer(alert).data,
        "prediction_summary": {
            "rain_probability": prediction.rain_probability,
            "confidence": prediction.confidence_score,
            "district": prediction.district
        }
    })


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def active_alerts(request):
    """
    GET /api/rain-forecast/active-alerts/
    Returns all active irrigation alerts for the farmer.
    """
    farmer = request.user
    alerts = IrrigationAlert.objects.filter(
        farmer=farmer,
        is_active=True,
        expires_at__gte=timezone.now()
    ).order_by('-created_at')

    return Response({
        "status": "success",
        "count": alerts.count(),
        "alerts": IrrigationAlertSerializer(alerts, many=True).data
    })


@api_view(["POST"])
@permission_classes([IsAuthenticated])
def dismiss_alert(request):
    """
    POST /api/rain-forecast/dismiss-alert/
    Body: { "alert_id": 123 }
    Dismisses an active alert.
    """
    alert_id = request.data.get("alert_id")
    if not alert_id:
        return Response(
            {"detail": "alert_id is required"},
            status=status.HTTP_400_BAD_REQUEST
        )

    try:
        alert = IrrigationAlert.objects.get(
            id=alert_id,
            farmer=request.user,
            is_active=True
        )
        alert.is_active = False
        alert.dismissed_at = timezone.now()
        alert.save()

        return Response({
            "status": "success",
            "message": "Alert dismissed successfully"
        })
    except IrrigationAlert.DoesNotExist:
        return Response(
            {"detail": "Alert not found or already dismissed"},
            status=status.HTTP_404_NOT_FOUND
        )
