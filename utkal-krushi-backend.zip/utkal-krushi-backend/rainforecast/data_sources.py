"""
Data Sources Aggregator for Rain Forecast System.
Fetches data from:
1. Open-Meteo API (Weather Forecast)
2. NASA POWER API (Satellite Climate Data)
3. Local IoT Field Sensors
"""
import requests
from datetime import datetime, timedelta
from sensors.models import SensorDevice, SensorReading


def fetch_open_meteo_data(lat, lon):
    """
    Fetch comprehensive weather data from Open-Meteo API.
    Returns current conditions + precipitation probability.
    """
    url = "https://api.open-meteo.com/v1/forecast"
    params = {
        "latitude": lat,
        "longitude": lon,
        "current": "temperature_2m,relative_humidity_2m,surface_pressure,precipitation,rain,weather_code,wind_speed_10m,wind_direction_10m,cloud_cover",
        "hourly": "precipitation_probability,precipitation,surface_pressure",
        "daily": "precipitation_probability_max,precipitation_sum",
        "timezone": "Asia/Kolkata",
        "forecast_days": 2,
    }

    try:
        response = requests.get(url, params=params, timeout=8)
        if response.status_code == 200:
            data = response.json()
            current = data.get("current", {})
            daily = data.get("daily", {})

            # Get max precipitation probability for today
            precip_prob_max = daily.get("precipitation_probability_max", [None])[0]

            return {
                "temperature": current.get("temperature_2m"),
                "humidity": current.get("relative_humidity_2m"),
                "pressure": current.get("surface_pressure"),
                "wind_speed": current.get("wind_speed_10m"),
                "cloud_cover": current.get("cloud_cover"),
                "precipitation": current.get("precipitation", 0),
                "precipitation_probability": precip_prob_max if precip_prob_max is not None else 0,
                "raw": data
            }
    except Exception as e:
        print(f"Error fetching Open-Meteo data: {e}")

    return None


def fetch_nasa_power_data(lat, lon):
    """
    Fetch satellite-derived precipitation data from NASA POWER API.
    Free, no API key required, global coverage.
    """
    # NASA POWER uses PRECTOTCORR (Precipitation Corrected)
    url = "https://power.larc.nasa.gov/api/temporal/hourly/point"

    today = datetime.now().strftime("%Y%m%d")
    tomorrow = (datetime.now() + timedelta(days=1)).strftime("%Y%m%d")

    params = {
        "parameters": "PRECTOTCORR,RH2M,PS",  # Precipitation, Relative Humidity, Surface Pressure
        "community": "AG",  # Agroclimatology
        "longitude": lon,
        "latitude": lat,
        "start": today,
        "end": tomorrow,
        "format": "JSON"
    }

    try:
        response = requests.get(url, params=params, timeout=10)
        if response.status_code == 200:
            data = response.json()
            properties = data.get("properties", {})
            parameter = properties.get("parameter", {})

            # Extract precipitation values
            precip_values = list(parameter.get("PRECTOTCORR", {}).values())
            precip_values = [v for v in precip_values if v != -999]  # Filter fill values

            if precip_values:
                max_precip = max(precip_values)
                # Convert mm/hr to probability estimate
                # >0.5 mm/hr = ~60% prob, >2.0 mm/hr = ~90% prob
                if max_precip > 2.0:
                    prob = 90
                elif max_precip > 0.5:
                    prob = 65
                elif max_precip > 0.1:
                    prob = 40
                else:
                    prob = 15

                return {
                    "precipitation_max_mm_hr": max_precip,
                    "estimated_probability": prob,
                    "raw": data
                }
    except Exception as e:
        print(f"Error fetching NASA POWER data: {e}")

    return None


def fetch_sensor_data_for_farmer(farmer):
    """
    Fetch latest sensor readings from the farmer's registered devices.
    Returns moisture, temperature, humidity readings if available.
    """
    if not farmer:
        return None

    # Get active sensors for this farmer
    sensors = SensorDevice.objects.filter(farmer=farmer, is_active=True)
    if not sensors.exists():
        # Fallback to any demo sensor readings
        sensors = SensorDevice.objects.filter(is_active=True)

    readings = {}
    for sensor in sensors:
        latest = sensor.readings.order_by("-timestamp").first()
        if latest:
            sensor_type = sensor.sensor_type.lower()
            readings[sensor_type] = {
                "value": latest.value,
                "unit": latest.unit,
                "timestamp": latest.timestamp
            }

    # Extract specific values
    moisture = readings.get("moisture", {}).get("value")
    humidity = readings.get("humidity", {}).get("value")
    temperature = readings.get("temperature", {}).get("value")

    if moisture is not None or humidity is not None:
        return {
            "moisture": moisture,
            "humidity": humidity,
            "temperature": temperature,
            "all_readings": readings
        }

    return None
