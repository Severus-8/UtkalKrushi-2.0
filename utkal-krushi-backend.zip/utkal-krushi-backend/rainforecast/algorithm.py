"""
Rain Forecast Algorithm - Rule-Based Prediction Engine
Combines atmospheric pressure, humidity, wind, temperature, cloud cover, and sensor data
"""
import math
from datetime import datetime, timedelta


def calculate_rain_probability_local(pressure, humidity, temperature, wind_speed, cloud_cover, sensor_moisture=None):
    """
    Rule-based algorithm to predict rain probability based on atmospheric conditions.

    Args:
        pressure: Atmospheric pressure in hPa
        humidity: Relative humidity (0-100)
        temperature: Temperature in Celsius
        wind_speed: Wind speed in km/h
        cloud_cover: Cloud cover percentage (0-100)
        sensor_moisture: Optional soil moisture from field sensors (0-100)

    Returns:
        dict: {
            'rain_probability': float (0-100),
            'confidence': float (0-100),
            'reasoning': str
        }
    """
    score = 0
    confidence = 50  # Base confidence
    reasons = []

    # Rule 1: Low Pressure + High Humidity = High Rain Chance
    if pressure and pressure < 1010:
        if humidity and humidity > 80:
            score += 40
            confidence += 20
            reasons.append("Low pressure (<1010 hPa) with high humidity (>80%)")
        elif humidity and humidity > 70:
            score += 25
            confidence += 10
            reasons.append("Low pressure with moderate-high humidity")

    # Rule 2: Very High Humidity Alone
    if humidity and humidity > 85:
        score += 20
        confidence += 10
        reasons.append("Very high humidity (>85%)")
    elif humidity and humidity > 75:
        score += 10
        reasons.append("High humidity (>75%)")

    # Rule 3: Heavy Cloud Cover + Wind
    if cloud_cover and cloud_cover > 80:
        score += 15
        if wind_speed and wind_speed > 15:
            score += 10
            reasons.append("Heavy cloud cover (>80%) with significant wind")
        else:
            reasons.append("Heavy cloud cover")

    # Rule 4: Temperature Drop Pattern (indicates incoming weather system)
    # In real implementation, you'd compare to historical temp - simplified here
    if temperature and temperature < 25 and humidity and humidity > 70:
        score += 10
        reasons.append("Cool temperature with high humidity")

    # Rule 5: Sensor Data Cross-Check
    # If soil moisture suddenly drops but humidity rises = rain likely incoming
    if sensor_moisture is not None:
        if sensor_moisture < 40 and humidity and humidity > 75:
            score += 15
            confidence += 15
            reasons.append("Low soil moisture with rising humidity (rain imminent)")

    # Rule 6: Stable High Pressure = Low Rain
    if pressure and pressure > 1020:
        score -= 20
        confidence += 10
        reasons.append("High pressure system (>1020 hPa) - stable weather")

    # Cap score between 0-100
    rain_probability = max(0, min(100, score))

    # Adjust confidence based on data availability
    data_points = sum([
        1 if pressure else 0,
        1 if humidity else 0,
        1 if temperature else 0,
        1 if wind_speed else 0,
        1 if cloud_cover else 0,
        1 if sensor_moisture is not None else 0
    ])

    confidence = confidence * (data_points / 6.0)  # Scale confidence by data availability
    confidence = max(30, min(95, confidence))  # Keep between 30-95%

    return {
        'rain_probability': round(rain_probability, 1),
        'confidence': round(confidence, 1),
        'reasoning': ' | '.join(reasons) if reasons else 'Stable atmospheric conditions'
    }


def cross_validate_predictions(local_pred, open_meteo_prob, nasa_prob=None, sensor_based_prob=None):
    """
    Cross-validate predictions from multiple sources and compute weighted average.

    Args:
        local_pred: dict from calculate_rain_probability_local()
        open_meteo_prob: float (0-100) from Open-Meteo API
        nasa_prob: float (0-100) from NASA POWER API (optional)
        sensor_based_prob: float (0-100) from sensor-only analysis (optional)

    Returns:
        dict: {
            'final_rain_probability': float,
            'final_confidence': float,
            'sources_agreement': float,
            'local_algorithm_score': float,
            'open_meteo_score': float,
            'nasa_power_score': float,
            'sensor_data_score': float
        }
    """
    sources = []
    weights = []

    # Local Algorithm (30% weight)
    if local_pred:
        sources.append(local_pred['rain_probability'])
        weights.append(0.30)

    # Open-Meteo (25% weight)
    if open_meteo_prob is not None:
        sources.append(open_meteo_prob)
        weights.append(0.25)

    # NASA POWER (20% weight)
    if nasa_prob is not None:
        sources.append(nasa_prob)
        weights.append(0.20)

    # Sensor-based (25% weight)
    if sensor_based_prob is not None:
        sources.append(sensor_based_prob)
        weights.append(0.25)

    # Normalize weights to sum to 1.0
    total_weight = sum(weights)
    weights = [w / total_weight for w in weights]

    # Calculate weighted average
    final_probability = sum(s * w for s, w in zip(sources, weights))

    # Calculate variance for confidence scoring
    # Lower variance = higher agreement = higher confidence
    if len(sources) > 1:
        mean = sum(sources) / len(sources)
        variance = sum((s - mean) ** 2 for s in sources) / len(sources)
        std_dev = math.sqrt(variance)

        # Convert variance to confidence score (inverse relationship)
        # High variance (30+) = low confidence, Low variance (0-10) = high confidence
        sources_agreement = max(0, 100 - (std_dev * 3))

        # Blend local confidence with agreement score
        final_confidence = (local_pred.get('confidence', 70) * 0.6) + (sources_agreement * 0.4)
    else:
        sources_agreement = 100  # Only one source, full "agreement"
        final_confidence = local_pred.get('confidence', 70)

    return {
        'final_rain_probability': round(final_probability, 1),
        'final_confidence': round(final_confidence, 1),
        'sources_agreement': round(sources_agreement, 1),
        'local_algorithm_score': local_pred['rain_probability'] if local_pred else None,
        'open_meteo_score': open_meteo_prob,
        'nasa_power_score': nasa_prob,
        'sensor_data_score': sensor_based_prob
    }


def generate_irrigation_recommendation(rain_probability, confidence, land_area_acres=1.0):
    """
    Generate irrigation recommendation based on rain forecast.

    Args:
        rain_probability: float (0-100)
        confidence: float (0-100)
        land_area_acres: float (default 1.0)

    Returns:
        dict: {
            'alert_type': str ('skip', 'reduce', 'normal', 'increase'),
            'recommendation': str (user-facing message),
            'water_savings_liters': float,
            'expires_hours': int
        }
    """
    # Average irrigation = 1000 liters per acre per day for vegetables/rice
    base_water_per_acre = 1000

    if rain_probability >= 70 and confidence >= 75:
        # High rain, high confidence - SKIP irrigation
        water_savings = base_water_per_acre * land_area_acres
        return {
            'alert_type': 'skip',
            'recommendation': f'Skip irrigation for next 24 hours. Heavy rain expected ({rain_probability}% chance). Save water and prevent overwatering.',
            'water_savings_liters': water_savings,
            'expires_hours': 24
        }

    elif rain_probability >= 50 and confidence >= 60:
        # Moderate-high rain - REDUCE irrigation
        reduction = 0.5  # 50% reduction
        water_savings = base_water_per_acre * land_area_acres * reduction
        return {
            'alert_type': 'reduce',
            'recommendation': f'Reduce irrigation by 50% for next 12 hours. Moderate rain likely ({rain_probability}% chance).',
            'water_savings_liters': water_savings,
            'expires_hours': 12
        }

    elif rain_probability < 20:
        # Low rain chance - NORMAL or INCREASE
        if confidence >= 70:
            return {
                'alert_type': 'normal',
                'recommendation': f'Continue normal irrigation schedule. Low rain probability ({rain_probability}%) with clear skies expected.',
                'water_savings_liters': 0,
                'expires_hours': 24
            }
        else:
            return {
                'alert_type': 'normal',
                'recommendation': f'Maintain regular irrigation. Weather forecast uncertain, monitor field moisture.',
                'water_savings_liters': 0,
                'expires_hours': 12
            }

    else:
        # Uncertain range (20-50%)
        return {
            'alert_type': 'normal',
            'recommendation': f'Normal irrigation advised. Rain chance is moderate ({rain_probability}%) but not certain. Check field before watering.',
            'water_savings_liters': 0,
            'expires_hours': 12
        }
