import requests
from django.conf import settings
from rest_framework.decorators import api_view
from rest_framework.response import Response

FALLBACK_REPLIES = {
    "or": "କ୍ଷମା କରନ୍ତୁ, ମୁଁ ଏହି ପ୍ରଶ୍ନର ନିର୍ଦ୍ଦିଷ୍ଟ ଉତ୍ତର ଦେଇପାରିବି ନାହିଁ। ଦୟାକରି ଆପଣଙ୍କ ନିକଟସ୍ଥ କୃଷି ବିଭାଗ କିମ୍ବା KISAN CALL CENTRE (1800-180-1551) ସହିତ ଯୋଗାଯୋଗ କରନ୍ତୁ।",
    "hi": "क्षमा करें, मैं इस प्रश्न का सटीक उत्तर नहीं दे पा रहा। कृपया अपने नज़दीकी कृषि कार्यालय या किसान कॉल सेंटर (1800-180-1551) से संपर्क करें।",
    "en": "Sorry, I don't have a confident answer for that yet. Please contact your local agriculture office or the Kisan Call Centre (1800-180-1551).",
}


@api_view(["POST"])
def chatbot_view(request):
    """
    POST /api/chatbot/ask   {"message": "...", "lang": "or"}

    If GEMINI_API_KEY is set in .env, this forwards the question to Gemini
    with an Odisha-agriculture system prompt. Otherwise it returns a
    friendly fallback message so the endpoint still works out of the box.
    """
    message = (request.data.get("message") or "").strip()
    lang = request.data.get("lang", "en")
    if not message:
        return Response({"detail": "message is required"}, status=400)

    if settings.GEMINI_API_KEY:
        try:
            resp = requests.post(
                "https://generativelanguage.googleapis.com/v1beta/models/"
                "gemini-1.5-flash:generateContent",
                params={"key": settings.GEMINI_API_KEY},
                json={
                    "contents": [{
                        "parts": [{
                            "text": (
                                "You are Krushi AI, an expert assistant for Odisha farmers. "
                                f"Answer concisely in the language code '{lang}' "
                                "(or=Odia, hi=Hindi, en=English). Question: " + message
                            )
                        }]
                    }]
                },
                timeout=15,
            )
            resp.raise_for_status()
            data = resp.json()
            reply = data["candidates"][0]["content"]["parts"][0]["text"]
            return Response({"reply": reply.strip()})
        except (requests.RequestException, KeyError, IndexError):
            pass  # fall through to the fallback reply below

    return Response({"reply": FALLBACK_REPLIES.get(lang, FALLBACK_REPLIES["en"])})
