from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response

from .models import LedgerEntry
from .serializers import LedgerEntrySerializer


@api_view(["GET", "POST"])
@permission_classes([AllowAny])
def ledger_view(request):
    """
    GET  /api/ledger        -> list entries (for the logged-in farmer, if authenticated)
    POST /api/ledger/save   -> create a new entry
    """
    if request.method == "GET":
        qs = LedgerEntry.objects.all()
        if request.user.is_authenticated:
            qs = qs.filter(farmer=request.user)
        qs = qs.order_by("-created_at")
        return Response(LedgerEntrySerializer(qs, many=True).data)

    serializer = LedgerEntrySerializer(data=request.data, context={"request": request})
    serializer.is_valid(raise_exception=True)
    entry = serializer.save()
    return Response(LedgerEntrySerializer(entry).data, status=201)
