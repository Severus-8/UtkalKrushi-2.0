from django.core.management.base import BaseCommand

from cropdoctor.models import CropDisease
from fertilizer.models import CropFertilizerProfile
from mandi.models import MandiPrice
from schemes.models import Scheme


class Command(BaseCommand):
    help = "Seed demo data for crop-doctor, fertilizer, mandi, and schemes apps."

    def handle(self, *args, **options):
        self._seed_crop_diseases()
        self._seed_fertilizer_profiles()
        self._seed_mandi_prices()
        self._seed_schemes()
        self.stdout.write(self.style.SUCCESS("Seed data loaded."))

    def _seed_crop_diseases(self):
        diseases = [
            dict(
                disease_id="rice-blast", name="Rice Blast (Pyricularia oryzae)",
                name_or="ଧାନ ବ୍ଲାଷ୍ଟ ରୋଗ (ପତ୍ର ପୋଡ଼ା)", crop="Rice / Paddy", severity="High",
                symptom_keywords="blast,spindle,diamond,grey spot,gray spot,neck rot,paddy leaf spot",
                symptoms="Spindle-shaped lesions with grey center and dark brown margins on leaves; neck rot on panicles.",
                organic_remedy="Spray 10% cow urine + Neem seed kernel extract (5%), or Pseudomonas fluorescens @ 10g/L.",
                chemical_treatment="Spray Tricyclazole 75% WP @ 0.6g/L of water during morning hours.",
                preventive_tips="Avoid excess urea nitrogen; treat seeds with Carbendazim before sowing; maintain proper spacing.",
            ),
            dict(
                disease_id="bacterial-leaf-blight", name="Bacterial Leaf Blight (BLB) of Rice",
                name_or="ଧାନ ଜୀବାଣୁ ଜନିତ ପତ୍ରପୋଡ଼ା ରୋଗ", crop="Rice / Paddy", severity="Critical",
                symptom_keywords="blight,yellow leaf,wavy lesion,leaf margin,water soaked",
                symptoms="Water-soaked yellow to straw-colored wavy lesions along leaf margins, progressing from tip to base.",
                organic_remedy="Drain standing water for 2-3 days; spray filtered fresh cow dung extract (20g/L).",
                chemical_treatment="Spray Streptocycline (0.1g) + Copper Oxychloride (2.5g) per litre of water.",
                preventive_tips="Plant BLB-resistant varieties (CR Dhan 800, Pooja, Hasanta); stop nitrogen top-dressing during outbreak.",
            ),
            dict(
                disease_id="stem-borer", name="Yellow Stem Borer (Paddy)",
                name_or="ଧାନ କାଣ୍ଡ ବିନ୍ଧା ପୋକ", crop="Rice / Paddy", severity="Medium",
                symptom_keywords="dead heart,white ear,stem borer,hollowed stem,central shoot dry",
                symptoms="Dead heart in vegetative stage and white/empty ear heads (white ear) at reproductive stage.",
                organic_remedy="Release Trichogramma japonicum egg parasitoids @ 5 cards/acre weekly.",
                chemical_treatment="Apply Chlorantraniliprole 0.4% GR @ 4 kg/acre or Cartap Hydrochloride 4G @ 10 kg/acre.",
                preventive_tips="Avoid close spacing; clip seedling tips before transplanting; use light traps for adult moths.",
            ),
            dict(
                disease_id="powdery-mildew", name="Powdery Mildew",
                name_or="ପାଉଡ଼ର ଫପୁସ ରୋଗ", crop="Pulses / Vegetables", severity="Medium",
                symptom_keywords="white powder,powdery,white coating,mildew",
                symptoms="White powdery fungal growth on leaves and stems, leading to yellowing and leaf drop.",
                organic_remedy="Spray a solution of neem oil (5ml/L) or diluted milk (1:9 with water) weekly.",
                chemical_treatment="Spray Wettable Sulphur 80% WP @ 2g/L or Hexaconazole 5% EC @ 2ml/L.",
                preventive_tips="Ensure good air circulation, avoid overhead irrigation in the evening, remove infected leaves.",
            ),
            dict(
                disease_id="early-blight", name="Early Blight (Tomato/Potato)",
                name_or="ପ୍ରାରମ୍ଭିକ ଝୁଲସା ରୋଗ", crop="Vegetables", severity="Medium",
                symptom_keywords="brown ring,concentric ring,leaf spot,target spot,potato leaf,tomato leaf",
                symptoms="Dark brown concentric ring spots (target-board pattern) on older leaves first.",
                organic_remedy="Spray Trichoderma viride based bio-fungicide @ 5g/L; remove infected lower leaves.",
                chemical_treatment="Spray Mancozeb 75% WP @ 2.5g/L at 10-day intervals.",
                preventive_tips="Practice crop rotation; avoid water stress; stake plants for airflow.",
            ),
        ]
        for d in diseases:
            CropDisease.objects.update_or_create(disease_id=d["disease_id"], defaults=d)

    def _seed_fertilizer_profiles(self):
        profiles = [
            dict(
                crop_id="paddy", crop_name="Swarna Paddy (ଧାନ)",
                yield_qtl_per_acre=22, price_per_qtl=2300,
                urea_bags_per_acre=2.0, dap_bags_per_acre=1.0, mop_bags_per_acre=0.8,
                zinc_kg_per_acre=10, fym_tons_per_acre=2,
                basal_note="Apply full DAP + half MOP + 1/4th Urea at planting/transplanting.",
                tillering_note="Top dress 1/2 of remaining Urea at 20-25 DAS (active tillering).",
                flowering_note="Apply remaining Urea + remaining MOP at panicle initiation stage.",
            ),
            dict(
                crop_id="ragi", crop_name="Ragi / Finger Millet (ମାଣ୍ଡିଆ)",
                yield_qtl_per_acre=13, price_per_qtl=3846,
                urea_bags_per_acre=0.9, dap_bags_per_acre=0.5, mop_bags_per_acre=0.4,
                zinc_kg_per_acre=5, fym_tons_per_acre=1.5,
                basal_note="Apply full DAP + full MOP + 1/3rd Urea at sowing.",
                tillering_note="Top dress 1/3rd Urea at 25-30 days after sowing.",
                flowering_note="Apply remaining Urea at panicle initiation (around 45-50 DAS).",
            ),
            dict(
                crop_id="moong", crop_name="Green Gram / Moong Dal (ମୁଗ)",
                yield_qtl_per_acre=5, price_per_qtl=8500,
                urea_bags_per_acre=0.4, dap_bags_per_acre=0.9, mop_bags_per_acre=0.4,
                zinc_kg_per_acre=0, fym_tons_per_acre=1,
                basal_note="Apply full dose of Urea, DAP and MOP at sowing along with Rhizobium seed treatment.",
                tillering_note="No top dressing normally required for short-duration pulses.",
                flowering_note="Foliar spray of 2% DAP solution at flowering can boost pod filling.",
            ),
            dict(
                crop_id="groundnut", crop_name="Groundnut (ଚିନାବାଦାମ)",
                yield_qtl_per_acre=10, price_per_qtl=6000,
                urea_bags_per_acre=0.5, dap_bags_per_acre=1.5, mop_bags_per_acre=0.8,
                zinc_kg_per_acre=8, fym_tons_per_acre=2,
                basal_note="Apply full Urea, DAP, MOP and Gypsum @ 100kg/acre at sowing.",
                tillering_note="Earth-up at 30-35 DAS; apply Gypsum @ 100 kg/acre at flowering (pegging).",
                flowering_note="Ensure adequate soil moisture during pegging and pod development.",
            ),
        ]
        for p in profiles:
            CropFertilizerProfile.objects.update_or_create(crop_id=p["crop_id"], defaults=p)

    def _seed_mandi_prices(self):
        prices = [
            dict(commodity="Paddy (Common / Dhan)", commodity_or="ଧାନ (ସାଧାରଣ)", mandi="Bargarh APMC",
                 district="Bargarh", market_price=2360, msp_rate=2300, price_change=60, trend="up",
                 arrival_qty="1,450 Quintals"),
            dict(commodity="Paddy (Grade A)", commodity_or="ଧାନ (ଗ୍ରେଡ୍ A)", mandi="Cuttack APMC",
                 district="Cuttack", market_price=2340, msp_rate=2320, price_change=-15, trend="down",
                 arrival_qty="980 Quintals"),
            dict(commodity="Green Gram (Moong)", commodity_or="ମୁଗ ଡାଲି", mandi="Bhubaneswar APMC",
                 district="Khordha", market_price=8200, msp_rate=8558, price_change=120, trend="up",
                 arrival_qty="320 Quintals"),
            dict(commodity="Groundnut", commodity_or="ଚିନାବାଦାମ", mandi="Berhampur APMC",
                 district="Ganjam", market_price=6100, msp_rate=6377, price_change=0, trend="flat",
                 arrival_qty="510 Quintals"),
            dict(commodity="Finger Millet (Ragi)", commodity_or="ମାଣ୍ଡିଆ", mandi="Koraput APMC",
                 district="Koraput", market_price=3900, msp_rate=3846, price_change=40, trend="up",
                 arrival_qty="210 Quintals"),
        ]
        for p in prices:
            MandiPrice.objects.update_or_create(
                commodity=p["commodity"], mandi=p["mandi"], defaults=p
            )

    def _seed_schemes(self):
        schemes = [
            dict(
                scheme_id="kalia-scheme", name="KALIA Scheme", name_or="କାଳିଆ ଯୋଜନା",
                gov_type="odisha", category="income-support",
                subsidy_benefit="₹10,000 per year per farm family",
                eligibility="Small and marginal farmers of Odisha\nLandless agricultural laborers",
                documents_needed="Aadhaar Card\nBank Passbook\nLand Patta (RoR)",
                official_url="https://kaliaportal.odisha.gov.in/",
            ),
            dict(
                scheme_id="pm-kisan", name="PM-KISAN", name_or="ପିଏମ୍-କିଷାନ",
                gov_type="central", category="income-support",
                subsidy_benefit="₹6,000 per year in 3 equal instalments",
                eligibility="All landholding farmer families\nSubject to exclusion criteria (income tax payers, govt employees)",
                documents_needed="Aadhaar Card\nBank Passbook\nLand ownership records",
                official_url="https://pmkisan.gov.in/",
            ),
            dict(
                scheme_id="soil-health-card", name="Soil Health Card Scheme", name_or="ମୃତ୍ତିକା ସ୍ୱାସ୍ଥ୍ୟ କାର୍ଡ",
                gov_type="central", category="advisory",
                subsidy_benefit="Free soil testing and crop-wise fertilizer recommendation",
                eligibility="All farmers with cultivable land",
                documents_needed="Aadhaar Card\nLand details",
                official_url="https://soilhealth.dac.gov.in/",
            ),
            dict(
                scheme_id="pmfby", name="Pradhan Mantri Fasal Bima Yojana", name_or="ପ୍ରଧାନମନ୍ତ୍ରୀ ଫସଲ ବୀମା ଯୋଜନା",
                gov_type="central", category="insurance",
                subsidy_benefit="Low-premium crop insurance against natural calamities",
                eligibility="All farmers growing notified crops in notified areas",
                documents_needed="Aadhaar Card\nBank Passbook\nLand records / tenancy agreement",
                official_url="https://pmfby.gov.in/",
            ),
        ]
        for s in schemes:
            Scheme.objects.update_or_create(scheme_id=s["scheme_id"], defaults=s)
