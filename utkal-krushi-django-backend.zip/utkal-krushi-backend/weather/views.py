import requests
from rest_framework.decorators import api_view
from rest_framework.response import Response

# A handful of Odisha districts with approximate coordinates so the frontend
# can request `?district=Bhubaneswar` instead of raw lat/lon.
DISTRICT_COORDS = {
    "bhubaneswar": (20.2961, 85.8245, "Bhubaneswar (Khordha)"),
    "cuttack": (20.4625, 85.8830, "Cuttack"),
    "bargarh": (21.3347, 83.6197, "Bargarh"),
    "puri": (19.8135, 85.8312, "Puri"),
    "sambalpur": (21.4669, 83.9756, "Sambalpur"),
    "berhampur": (19.3149, 84.7941, "Berhampur (Ganjam)"),
    "balasore": (21.4942, 86.9317, "Balasore"),
    "rourkela": (22.2604, 84.8536, "Rourkela (Sundargarh)"),
}


def _spray_advisory(wind_speed, precipitation):
    if precipitation and precipitation > 0.5:
        return {"status": "unsafe", "message": "Avoid spraying - Rain expected/occurring"}
    if wind_speed and wind_speed > 15:
        return {"status": "caution", "message": "Use caution - High wind speed may cause drift"}
    return {"status": "safe", "message": "Safe to spray - Low wind & no rain expected"}


@api_view(["GET"])
def weather_view(request):
    """
    GET /api/weather?district=Bhubaneswar
    GET /api/weather?lat=20.29&lon=85.82
    Proxies Open-Meteo (free, no API key) and reshapes the response to match
    BACKEND_API_GUIDE.md so the React frontend needs no changes.
    """
    district = request.GET.get("district", "").strip().lower()
    lat = request.GET.get("lat")
    lon = request.GET.get("lon")
    location_label = request.GET.get("district", "Bhubaneswar (Khordha)")

    if district in DISTRICT_COORDS:
        lat, lon, location_label = DISTRICT_COORDS[district]
    elif not (lat and lon):
        lat, lon, location_label = DISTRICT_COORDS["bhubaneswar"]

    try:
        resp = requests.get(
            "https://api.open-meteo.com/v1/forecast",
            params={
                "latitude": lat,
                "longitude": lon,
                "current": "temperature_2m,apparent_temperature,relative_humidity_2m,"
                           "precipitation,wind_speed_10m,weather_code",
                "hourly": "temperature_2m,precipitation_probability,weather_code",
                "timezone": "Asia/Kolkata",
                "forecast_days": 1,
            },
            timeout=8,
        )
        resp.raise_for_status()
        data = resp.json()
    except requests.RequestException as exc:
        return Response({"detail": f"Weather provider error: {exc}"}, status=502)

    current = data.get("current", {})
    hourly = data.get("hourly", {})
    times = hourly.get("time", [])
    temps = hourly.get("temperature_2m", [])
    rain_probs = hourly.get("precipitation_probability", [])
    codes = hourly.get("weather_code", [])

    hourly_out = []
    for t, temp, rp, code in list(zip(times, temps, rain_probs, codes))[:8]:
        hourly_out.append({
            "time": t.split("T")[1] if "T" in t else t,
            "temp": temp,
            "rainProb": rp,
            "code": code,
        })

    payload = {
        "location": location_label,
        "temperature": current.get("temperature_2m"),
        "apparentTemperature": current.get("apparent_temperature"),
        "humidity": current.get("relative_humidity_2m"),
        "windSpeed": current.get("wind_speed_10m"),
        "precipitation": current.get("precipitation"),
        "weatherCode": current.get("weather_code"),
        "sprayAdvisory": _spray_advisory(current.get("wind_speed_10m"), current.get("precipitation")),
        "hourly": hourly_out,
    }
    return Response(payload)
