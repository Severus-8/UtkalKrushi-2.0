# Utkal Krushi — Django Backend

A Django + Django REST Framework backend that implements every endpoint listed in the
frontend's `BACKEND_API_GUIDE.md` / `src/config/api.js`, so the React app can be pointed
at it with **zero frontend code changes**.

## Apps → Endpoints

| App          | Endpoint                              | Notes |
|--------------|----------------------------------------|-------|
| `accounts`   | `POST /api/auth/register`, `POST /api/auth/login` | Custom `Farmer` user model, JWT tokens (SimpleJWT) |
| `weather`    | `GET /api/weather?district=..`        | Proxies the free [Open-Meteo](https://open-meteo.com) API — no key needed |
| `cropdoctor` | `POST /api/crop-doctor/diagnose`      | Rule-based keyword match against a `CropDisease` knowledge base |
| `fertilizer` | `POST /api/fertilizer/calculate`      | Per-crop NPK/yield calculator, scaled by land area |
| `mandi`      | `GET /api/mandi/prices?district=..&commodity=..` | `MandiPrice` model, filterable |
| `schemes`    | `GET /api/schemes?category=..`        | `Scheme` model |
| `chatbot`    | `POST /api/chatbot/ask`               | Falls back to a canned multilingual reply; forwards to Gemini if `GEMINI_API_KEY` is set |
| `ledger`     | `GET /api/ledger`, `POST /api/ledger/save` | Farmer expense/profit khata, tied to the logged-in user if a JWT is sent |

## 1. Setup

```bash
cd utkal-krushi-backend
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env            # edit if needed (defaults work for local dev)

python manage.py migrate
python manage.py seed_data      # loads demo diseases, fertilizer profiles, mandi prices, schemes
python manage.py createsuperuser  # optional, to use /admin

python manage.py runserver 0.0.0.0:8000
```

The API is now live at `http://localhost:8000/api/...`, matching the guide's paths exactly
(the frontend's default base URL is `http://localhost:5000/api` — either change
`VITE_API_BASE_URL` in the frontend's `.env` to `http://localhost:8000/api`, or run Django
with `runserver 5000`).

## 2. Connect the React frontend

In the **frontend** project root, create `.env`:
```env
VITE_API_BASE_URL=http://localhost:8000/api
```
Then `npm run dev` as usual. CORS is already open for `http://localhost:5173` in `settings.py`
(`CORS_ALLOWED_ORIGINS`), and wide open whenever `DJANGO_DEBUG=True`.

## 3. Data model choices

- **SQLite** by default (zero setup). Swap `DATABASES` in `config/settings.py` for
  Postgres/MySQL when you deploy — nothing else changes.
- Demo content (diseases, fertilizer profiles, mandi prices, schemes) lives in
  `accounts/management/commands/seed_data.py`. Edit that file, or manage records via
  Django admin at `/admin/`, to add real data.
- `Farmer` (in `accounts`) replaces Django's default `User` and carries phone/district/
  village/preferred language/land area, since the frontend is farmer-facing.

## 4. Plugging in a real AI model (optional)

Two endpoints are currently **rule-based** so the backend works out of the box with no
paid APIs:

- **Crop Doctor** (`cropdoctor/views.py`) matches the farmer's symptom text against
  keyword lists on each `CropDisease` row. For real photo-based diagnosis, swap this for
  a call to a vision model (Gemini Vision, a fine-tuned classifier, etc.) using the
  `imageBase64` field already being sent by the frontend.
- **Chatbot** (`chatbot/views.py`) already calls Gemini automatically if you set
  `GEMINI_API_KEY` in `.env` — get a free key at https://aistudio.google.com/apikey.
  Without a key it returns a friendly fallback message.

## 5. Auth notes

`POST /api/auth/register` and `/login` return `{ access, refresh }` JWTs. Have the
frontend send `Authorization: Bearer <access>` on requests (e.g. to `/api/ledger`) so
entries are tied to the right farmer. Every endpoint currently allows anonymous access
too (`AllowAny`) so the app still works before you wire up a login screen — tighten
`REST_FRAMEWORK["DEFAULT_PERMISSION_CLASSES"]` / add `permission_classes` per-view once
you're ready to require login.

## 6. Tested

Every endpoint was smoke-tested end-to-end during development (`curl` against
`runserver`) except `/api/weather`, which needs outbound internet access to
`api.open-meteo.com` — it will work as soon as it's run somewhere with normal internet
access (it did not have that in the sandbox this was built in).

## 7. Production checklist

- Set a real `DJANGO_SECRET_KEY`, `DJANGO_DEBUG=False`, and explicit `DJANGO_ALLOWED_HOSTS`.
- Point `DATABASES` at Postgres.
- Run behind Gunicorn/Uvicorn + Nginx (not `runserver`).
- Restrict `CORS_ALLOWED_ORIGINS` to your real frontend domain.
