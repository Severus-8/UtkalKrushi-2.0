from decimal import Decimal
from rest_framework.decorators import api_view
from rest_framework.response import Response

from .models import CropFertilizerProfile

ACRE_PER_UNIT = {"acre": Decimal("1"), "hectare": Decimal("2.471"), "bigha": Decimal("0.618")}


@api_view(["POST"])
def calculate_view(request):
    """
    POST /api/fertilizer/calculate
    Body: {"crop": "paddy", "landArea": 2.5, "unit": "acre", "soilType": "alluvial", "soilPh": 6.2}
    """
    data = request.data
    crop_id = (data.get("crop") or "").strip().lower()
    try:
        land_area = Decimal(str(data.get("landArea", 0)))
    except Exception:
        return Response({"detail": "landArea must be a number"}, status=400)
    unit = (data.get("unit") or "acre").lower()
    soil_ph = data.get("soilPh")

    if land_area <= 0:
        return Response({"detail": "landArea must be greater than 0"}, status=400)

    profile = CropFertilizerProfile.objects.filter(crop_id=crop_id).first()
    if profile is None:
        return Response(
            {"detail": f"No fertilizer profile found for crop '{crop_id}'. "
                       f"Run: python manage.py seed_data, or add one in /admin."},
            status=404,
        )

    acres = land_area * ACRE_PER_UNIT.get(unit, Decimal("1"))

    def scaled(field):
        return round(float(getattr(profile, field)) * float(acres), 2)

    expected_yield = scaled("yield_qtl_per_acre")
    revenue = round(expected_yield * float(profile.price_per_qtl), 2)

    ph_advice = "Normal pH. No special liming needed."
    if soil_ph is not None:
        try:
            ph = float(soil_ph)
            if ph < 5.5:
                ph_advice = "Acidic soil. Apply agricultural lime @ 200-400 kg/acre before sowing."
            elif ph > 8.0:
                ph_advice = "Alkaline soil. Apply gypsum @ 200 kg/acre and use acid-forming fertilizers."
        except (TypeError, ValueError):
            pass

    payload = {
        "cropName": profile.crop_name,
        "acres": float(round(acres, 2)),
        "expectedYieldQuintals": expected_yield,
        "estimatedRevenue": revenue,
        "bagsRequired": {
            "urea": scaled("urea_bags_per_acre"),
            "dap": scaled("dap_bags_per_acre"),
            "mop": scaled("mop_bags_per_acre"),
            "zincKg": scaled("zinc_kg_per_acre"),
            "organicFymTons": scaled("fym_tons_per_acre"),
        },
        "schedule": {
            "basal": profile.basal_note,
            "tillering": profile.tillering_note,
            "flowering": profile.flowering_note,
        },
        "soilPhAdvice": ph_advice,
    }
    return Response(payload)
