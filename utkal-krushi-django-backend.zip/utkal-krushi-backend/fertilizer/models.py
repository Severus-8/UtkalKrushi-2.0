from django.db import models


class CropFertilizerProfile(models.Model):
    """Per-crop baseline used by the fertilizer/yield calculator (per acre)."""
    crop_id = models.SlugField(unique=True)          # e.g. "paddy"
    crop_name = models.CharField(max_length=200)       # e.g. "Swarna Paddy (ଧାନ)"
    yield_qtl_per_acre = models.DecimalField(max_digits=6, decimal_places=2)
    price_per_qtl = models.DecimalField(max_digits=8, decimal_places=2)
    urea_bags_per_acre = models.DecimalField(max_digits=5, decimal_places=2)
    dap_bags_per_acre = models.DecimalField(max_digits=5, decimal_places=2)
    mop_bags_per_acre = models.DecimalField(max_digits=5, decimal_places=2)
    zinc_kg_per_acre = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    fym_tons_per_acre = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    basal_note = models.TextField()
    tillering_note = models.TextField()
    flowering_note = models.TextField()

    def __str__(self):
        return self.crop_name
