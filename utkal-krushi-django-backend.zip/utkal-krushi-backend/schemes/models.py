from django.db import models


class Scheme(models.Model):
    scheme_id = models.SlugField(unique=True)
    name = models.CharField(max_length=200)
    name_or = models.CharField("Name (Odia)", max_length=200, blank=True)
    gov_type = models.CharField(max_length=20, choices=[("odisha", "Odisha"), ("central", "Central")])
    category = models.CharField(max_length=100, default="all")
    subsidy_benefit = models.TextField()
    eligibility = models.TextField(help_text="One item per line")
    documents_needed = models.TextField(help_text="One item per line")
    official_url = models.URLField()

    def __str__(self):
        return self.name

    def eligibility_list(self):
        return [x.strip() for x in self.eligibility.splitlines() if x.strip()]

    def documents_list(self):
        return [x.strip() for x in self.documents_needed.splitlines() if x.strip()]
