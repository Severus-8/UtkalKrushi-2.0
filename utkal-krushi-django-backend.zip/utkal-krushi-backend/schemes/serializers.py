from rest_framework import serializers
from .models import Scheme


class SchemeSerializer(serializers.ModelSerializer):
    id = serializers.CharField(source="scheme_id")
    nameOr = serializers.CharField(source="name_or")
    govType = serializers.CharField(source="gov_type")
    subsidyBenefit = serializers.CharField(source="subsidy_benefit")
    eligibility = serializers.SerializerMethodField()
    documentsNeeded = serializers.SerializerMethodField()
    officialUrl = serializers.URLField(source="official_url")

    class Meta:
        model = Scheme
        fields = [
            "id", "name", "nameOr", "govType", "subsidyBenefit",
            "eligibility", "documentsNeeded", "officialUrl",
        ]

    def get_eligibility(self, obj):
        return obj.eligibility_list()

    def get_documentsNeeded(self, obj):
        return obj.documents_list()
