from rest_framework import serializers
from .models import CropDisease


class CropDiseaseResultSerializer(serializers.ModelSerializer):
    diseaseName = serializers.CharField(source="name")
    diseaseNameOr = serializers.CharField(source="name_or")
    severity = serializers.CharField()
    symptoms = serializers.CharField()
    organicRemedy = serializers.CharField(source="organic_remedy")
    chemicalTreatment = serializers.CharField(source="chemical_treatment")
    preventiveTips = serializers.CharField(source="preventive_tips")

    class Meta:
        model = CropDisease
        fields = [
            "diseaseName", "diseaseNameOr", "severity", "symptoms",
            "organicRemedy", "chemicalTreatment", "preventiveTips",
        ]
