from django.db import models


class CropDisease(models.Model):
    """Reference knowledge-base entry used by the rule-based Crop Doctor."""
    disease_id = models.SlugField(unique=True)
    name = models.CharField(max_length=200)
    name_or = models.CharField("Name (Odia)", max_length=200, blank=True)
    crop = models.CharField(max_length=100)
    severity = models.CharField(
        max_length=20,
        choices=[("Low", "Low"), ("Medium", "Medium"), ("High", "High"), ("Critical", "Critical")],
    )
    symptom_keywords = models.TextField(
        help_text="Comma-separated keywords matched against the farmer's symptom description."
    )
    symptoms = models.TextField()
    organic_remedy = models.TextField()
    chemical_treatment = models.TextField()
    preventive_tips = models.TextField()

    def __str__(self):
        return self.name
