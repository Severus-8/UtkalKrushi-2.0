from rest_framework.decorators import api_view
from rest_framework.response import Response

from .models import CropDisease
from .serializers import CropDiseaseResultSerializer


@api_view(["POST"])
def diagnose_view(request):
    """
    POST /api/crop-doctor/diagnose
    Body: {"symptoms": "...", "imageBase64": "...", "lang": "or"}

    Rule-based match against the CropDisease knowledge base using keyword
    overlap with the farmer's free-text symptom description. Swap the body
    of this function for a call to an image/vision model if you want true
    photo-based diagnosis (see README "Plugging in a real AI model").
    """
    symptoms_text = (request.data.get("symptoms") or "").lower()

    if not symptoms_text.strip():
        return Response({"detail": "Please describe the symptoms you observed."}, status=400)

    best_match = None
    best_score = 0
    for disease in CropDisease.objects.all():
        keywords = [k.strip().lower() for k in disease.symptom_keywords.split(",") if k.strip()]
        score = sum(1 for kw in keywords if kw in symptoms_text)
        if score > best_score:
            best_score = score
            best_match = disease

    if best_match is None:
        best_match = CropDisease.objects.first()  # graceful fallback

    if best_match is None:
        return Response(
            {"detail": "No disease knowledge base loaded. Run: python manage.py seed_data"},
            status=503,
        )

    return Response(CropDiseaseResultSerializer(best_match).data)
