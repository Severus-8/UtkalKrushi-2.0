import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import DashboardHero from './components/DashboardHero';
import WeatherSection from './components/WeatherSection';
import CropDoctorSection from './components/CropDoctorSection';
import FertilizerCalculator from './components/FertilizerCalculator';
import MandiPricesSection from './components/MandiPricesSection';
import GovtSchemesSection from './components/GovtSchemesSection';
import KrushiAiChatbot from './components/KrushiAiChatbot';
import CropGuideSection from './components/CropGuideSection';
import FarmLedgerSection from './components/FarmLedgerSection';
import GovtPortalsSection from './components/GovtPortalsSection';
import HelplineModal from './components/HelplineModal';
import Footer from './components/Footer';
import { Bot, PhoneCall, ArrowUp } from 'lucide-react';

export default function App() {
  const [currentLang, setCurrentLang] = useState('or'); // Default to Odia for Odisha farmers
  const [activeTab, setActiveTab] = useState('dashboard');
  const [darkMode, setDarkMode] = useState(false);
  const [helplineModalOpen, setHelplineModalOpen] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);

  // Sync dark mode class on html root
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Scroll to top tracker
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 300) {
        setShowScrollTop(true);
      } else {
        setShowScrollTop(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors duration-200">
      
      {/* Navigation Header */}
      <Header
        currentLang={currentLang}
        setCurrentLang={setCurrentLang}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        onOpenHelpline={() => setHelplineModalOpen(true)}
      />

      {/* Main App Content Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {activeTab === 'dashboard' && (
          <DashboardHero
            currentLang={currentLang}
            setActiveTab={setActiveTab}
            onOpenHelpline={() => setHelplineModalOpen(true)}
          />
        )}

        {activeTab === 'weather' && (
          <WeatherSection currentLang={currentLang} />
        )}

        {activeTab === 'cropdoctor' && (
          <CropDoctorSection currentLang={currentLang} />
        )}

        {activeTab === 'fertilizer' && (
          <FertilizerCalculator currentLang={currentLang} />
        )}

        {activeTab === 'mandi' && (
          <MandiPricesSection currentLang={currentLang} />
        )}

        {activeTab === 'schemes' && (
          <GovtSchemesSection currentLang={currentLang} />
        )}

        {activeTab === 'chatbot' && (
          <KrushiAiChatbot currentLang={currentLang} />
        )}

        {activeTab === 'cropguide' && (
          <CropGuideSection currentLang={currentLang} />
        )}

        {activeTab === 'ledger' && (
          <FarmLedgerSection currentLang={currentLang} />
        )}

        {activeTab === 'portals' && (
          <GovtPortalsSection currentLang={currentLang} />
        )}
      </main>

      {/* Floating Quick Access AI & Helpline Action Buttons */}
      <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-3 pointer-events-auto">
        {/* Scroll To Top Button */}
        {showScrollTop && (
          <button
            onClick={scrollToTop}
            className="p-3 rounded-full bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 shadow-lg border border-slate-200 dark:border-slate-700 hover:scale-105 transition-all"
            title="Scroll to Top"
            aria-label="Scroll to top"
          >
            <ArrowUp className="w-5 h-5" />
          </button>
        )}

        {/* Quick Chatbot Trigger */}
        {activeTab !== 'chatbot' && (
          <button
            onClick={() => setActiveTab('chatbot')}
            className="flex items-center gap-2 px-4 py-3 rounded-full bg-teal-600 hover:bg-teal-700 text-white shadow-xl shadow-teal-600/30 hover:scale-105 transition-all active:scale-95 group font-bold text-xs sm:text-sm"
          >
            <Bot className="w-5 h-5" />
            <span className="hidden sm:inline">
              {currentLang === 'or' ? 'କୃଷି AI ସହାୟକ' : 'Krushi AI Mitra'}
            </span>
          </button>
        )}

        {/* Quick Helpline Dial Button */}
        <button
          onClick={() => setHelplineModalOpen(true)}
          className="flex items-center gap-2 px-4 py-3 rounded-full bg-amber-500 hover:bg-amber-600 text-slate-950 shadow-xl shadow-amber-500/30 hover:scale-105 transition-all active:scale-95 group font-extrabold text-xs sm:text-sm"
        >
          <PhoneCall className="w-5 h-5 animate-pulse" />
          <span>1551</span>
        </button>
      </div>

      {/* Emergency Helpline Modal */}
      <HelplineModal
        isOpen={helplineModalOpen}
        onClose={() => setHelplineModalOpen(false)}
        currentLang={currentLang}
      />

      {/* Footer */}
      <Footer
        currentLang={currentLang}
        setActiveTab={setActiveTab}
        onOpenHelpline={() => setHelplineModalOpen(true)}
      />

    </div>
  );
}
