// Speech Synthesis and Recognition Utilities for Farmer Accessibility

let currentUtterance = null;
let currentAudio = null;

export const speakText = (text, lang = 'en', onStart, onEnd, onError) => {
  if (!text) return;

  // Clean text from Markdown asterisks, hashtags, bullets
  const cleanText = text
    .replace(/[*_#`>~]/g, '')
    .replace(/\s+/g, ' ')
    .trim();

  // Cancel any ongoing speech
  stopSpeaking();

  if ('speechSynthesis' in window) {
    try {
      const utterance = new SpeechSynthesisUtterance(cleanText);
      const voices = window.speechSynthesis.getVoices();

      let targetLang = 'en-IN';
      if (lang === 'hi') targetLang = 'hi-IN';
      else if (lang === 'or') targetLang = 'hi-IN'; // Fallback to Indian accent for Odia if native Odia TTS engine not present

      // Find matching voice
      const matchedVoice = voices.find(v => v.lang.startsWith(targetLang) || (lang === 'en' && v.lang.startsWith('en')));
      if (matchedVoice) {
        utterance.voice = matchedVoice;
      }
      utterance.lang = targetLang;
      utterance.rate = 0.95; // Slightly slower for clarity for farmers
      utterance.pitch = 1.0;

      utterance.onstart = () => {
        if (onStart) onStart();
      };
      utterance.onend = () => {
        currentUtterance = null;
        if (onEnd) onEnd();
      };
      utterance.onerror = (e) => {
        console.warn('Speech synthesis error, trying fallback:', e);
        fallbackTts(cleanText, lang, onStart, onEnd, onError);
      };

      currentUtterance = utterance;
      window.speechSynthesis.speak(utterance);
      return;
    } catch (err) {
      console.warn('Synthesis failed, falling back:', err);
    }
  }

  // Fallback Google Translate TTS
  fallbackTts(cleanText, lang, onStart, onEnd, onError);
};

const fallbackTts = (text, lang, onStart, onEnd, onError) => {
  try {
    const ttsLang = lang === 'hi' ? 'hi' : lang === 'or' ? 'hi' : 'en';
    const truncated = text.slice(0, 200); // TTS limit
    const url = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(truncated)}&tl=${ttsLang}&client=tw-ob`;
    
    currentAudio = new Audio(url);
    if (onStart) onStart();

    currentAudio.onended = () => {
      currentAudio = null;
      if (onEnd) onEnd();
    };
    currentAudio.onerror = (e) => {
      currentAudio = null;
      if (onError) onError(e);
      if (onEnd) onEnd();
    };
    currentAudio.play();
  } catch (err) {
    if (onError) onError(err);
    if (onEnd) onEnd();
  }
};

export const stopSpeaking = () => {
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
  if (currentAudio) {
    currentAudio.pause();
    currentAudio = null;
  }
  currentUtterance = null;
};

// Speech Recognition helper
export const createSpeechRecognizer = (lang = 'en', onResult, onEnd, onError) => {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    return null;
  }

  const recognition = new SpeechRecognition();
  recognition.continuous = false;
  recognition.interimResults = true;

  let recognitionLang = 'en-IN';
  if (lang === 'hi') recognitionLang = 'hi-IN';
  else if (lang === 'or') recognitionLang = 'hi-IN'; // Speech recognition engine fallback

  recognition.lang = recognitionLang;

  recognition.onresult = (event) => {
    let transcript = '';
    for (let i = event.resultIndex; i < event.results.length; i++) {
      transcript += event.results[i][0].transcript;
    }
    if (onResult) onResult(transcript);
  };

  recognition.onend = () => {
    if (onEnd) onEnd();
  };

  recognition.onerror = (e) => {
    if (onError) onError(e);
  };

  return recognition;
};
