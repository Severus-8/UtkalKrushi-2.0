export const odishaCropsData = [
  {
    id: "rice",
    name: "Rice / Paddy (Dhan)",
    nameOr: "ଧାନ (Paddy)",
    nameHi: "धान / चावल",
    category: "Cereals",
    seasons: ["Kharif (June-Nov)", "Rabi / Dalua (Dec-April)"],
    durationDays: "115 - 150 Days",
    varieties: [
      { name: "Swarna (MTU 7029)", duration: "145-150 days", yield: "22-25 Qtl/Acre", type: "Late Kharif, Medium-lowland" },
      { name: "Pooja (CR 629-256)", duration: "145 days", yield: "20-24 Qtl/Acre", type: "Submergence tolerant, lowland" },
      { name: "MTU 1010", duration: "115-120 days", yield: "20-22 Qtl/Acre", type: "Early Kharif / Rabi Dalua" },
      { name: "CR Dhan 800 (Kamala)", duration: "140 days", yield: "22-26 Qtl/Acre", type: "BLB resistant, high yield" },
      { name: "Sahabhagi Dhan", duration: "105-110 days", yield: "15-18 Qtl/Acre", type: "Drought tolerant upland" }
    ],
    seedRate: "16 - 20 kg/Acre (Transplanted) / 30 kg/Acre (Direct Seeded)",
    idealSoil: "Clay loam, heavy alluvial soil with high water retention",
    waterNeed: "High (1200 - 1500 mm), standing water 2-5 cm during tillering",
    fertilizerNpk: "80:40:40 kg N:P2O5:K2O per ha (approx 2 bags Urea, 1 bag DAP, 0.75 bag MOP/acre)",
    keyPests: "Stem Borer, Blast, Leaf Folder, Brown Plant Hopper (BPH), BLB",
    harvestingTips: "Harvest when 80-85% of the panicles turn golden yellow and grain moisture drops to 20-22%."
  },
  {
    id: "ragi",
    name: "Ragi / Finger Millet (Mandia)",
    nameOr: "ମାଣ୍ଡିଆ (Finger Millet)",
    nameHi: "रागी / मड़ुआ",
    category: "Millets",
    seasons: ["Kharif (July-Oct)", "Rabi (Nov-Feb)"],
    durationDays: "100 - 115 Days",
    varieties: [
      { name: "Bhairabi (GPU 28)", duration: "105-110 days", yield: "12-14 Qtl/Acre", type: "High yielding, Blast resistant" },
      { name: "Chilika (OUAT 2)", duration: "110-115 days", yield: "10-12 Qtl/Acre", type: "Suitable for coastal & tribal Odisha" },
      { name: "Arjun (OEB 526)", duration: "100-105 days", yield: "11-13 Qtl/Acre", type: "Early maturing, drought hardy" }
    ],
    seedRate: "2 - 2.5 kg/Acre (Line sowing) / 4 kg/Acre (Broadcasting)",
    idealSoil: "Red sandy loam, laterite, well-drained gravelly soil",
    waterNeed: "Low (350 - 500 mm), excellent drought resistance",
    fertilizerNpk: "40:20:20 kg N:P2O5:K2O per ha",
    keyPests: "Blast disease, stem borer, aphid",
    harvestingTips: "Harvest when ear heads turn chocolate brown and grains become firm and dry."
  },
  {
    id: "moong",
    name: "Green Gram (Moong Dal)",
    nameOr: "ମୁଗ ଡାଲି (Green Gram)",
    nameHi: "मूंग दाल",
    category: "Pulses",
    seasons: ["Rabi (Oct-Jan)", "Summer (Feb-April)", "Kharif (July-Sept)"],
    durationDays: "65 - 75 Days",
    varieties: [
      { name: "IPM 02-03", duration: "65-70 days", yield: "5-6 Qtl/Acre", type: "Yellow Mosaic resistant" },
      { name: "OBGG 52 (Kamadev)", duration: "65 days", yield: "4.5-5.5 Qtl/Acre", type: "Shiny bold grain, OUAT released" },
      { name: "TARM 1", duration: "60-65 days", yield: "4-5 Qtl/Acre", type: "Powdery mildew tolerant" }
    ],
    seedRate: "8 - 10 kg/Acre",
    idealSoil: "Well-drained alluvial loam or medium black soil",
    waterNeed: "Low (200 - 300 mm), 2-3 light irrigations at flowering and pod filling",
    fertilizerNpk: "20:40:20 kg N:P2O5:K2O per ha + Rhizobium seed inoculation",
    keyPests: "Yellow Mosaic Virus (Whitefly), Pod borer, Powdery mildew",
    harvestingTips: "Pick mature black pods when 80% pods turn dark brown/black in morning hours to prevent shattering."
  },
  {
    id: "mustard",
    name: "Mustard & Rapeseed (Sarisha)",
    nameOr: "ସୋରିଷ (Mustard)",
    nameHi: "सरसों",
    category: "Oilseeds",
    seasons: ["Rabi (Oct-Feb)"],
    durationDays: "85 - 105 Days",
    varieties: [
      { name: "Pusa Bold", duration: "105 days", yield: "6-8 Qtl/Acre", type: "Bold grain, high oil content (39%)" },
      { name: "Anuradha (T9)", duration: "85-90 days", yield: "5-6 Qtl/Acre", type: "Early toria variety for rice-fallow" },
      { name: "Pusa Mustard 25", duration: "100 days", yield: "6-7 Qtl/Acre", type: "Aphid tolerant, uniform ripening" }
    ],
    seedRate: "2 - 2.5 kg/Acre",
    idealSoil: "Light to medium loam, well-drained sandy loam",
    waterNeed: "Low to medium (250 - 350 mm), 2 critical irrigations at branching and siliqua formation",
    fertilizerNpk: "60:30:30 kg N:P2O5:K2O + 20 kg Sulphur per ha",
    keyPests: "Mustard Aphid (Mahun), White rust, Alternaria blight",
    harvestingTips: "Harvest when siliquae (pods) turn bright lemon-yellow and seeds rattle inside pods."
  },
  {
    id: "groundnut",
    name: "Groundnut / Peanut (Chinabadam)",
    nameOr: "ଚିନାବାଦାମ (Groundnut)",
    nameHi: "मूंगफली",
    category: "Oilseeds",
    seasons: ["Rabi (Nov-March)", "Kharif (June-Oct)"],
    durationDays: "110 - 125 Days",
    varieties: [
      { name: "Kadiri 6 (K6)", duration: "110-115 days", yield: "10-12 Qtl/Acre", type: "Semi-dwarf bunch, high shelling %" },
      { name: "Smruti (OG 52-1)", duration: "115-120 days", yield: "11-13 Qtl/Acre", type: "OUAT variety, high oil content" },
      { name: "TAG 24", duration: "100-105 days", yield: "9-11 Qtl/Acre", type: "Early maturing bunch type" }
    ],
    seedRate: "45 - 55 kg kernel/Acre",
    idealSoil: "Light sandy loam, well-drained soil with loose surface for easy pegging",
    waterNeed: "Medium (450 - 600 mm), gypsum application at 30 DAS is critical",
    fertilizerNpk: "20:40:40 kg N:P2O5:K2O + 200 kg Gypsum per ha",
    keyPests: "Tikka leaf spot, Spodoptera caterpillar, Collar rot, White grub",
    harvestingTips: "Check inside of pods: inner shell turning brown/black indicates optimum harvest maturity."
  },
  {
    id: "chilli",
    name: "Chilli & Capsicum (Lanka)",
    nameOr: "ଲଙ୍କା (Chilli)",
    nameHi: "मिर्च",
    category: "Spices & Veg",
    seasons: ["Kharif (July-Dec)", "Rabi (Oct-March)"],
    durationDays: "150 - 180 Days (Multiple pickings)",
    varieties: [
      { name: "Utkal Ava", duration: "150 days", yield: "60-80 Qtl/Acre (Green)", type: "OUAT release, high pungency" },
      { name: "Guntur Hope (LCA 206)", duration: "160 days", yield: "15-18 Qtl/Acre (Dry)", type: "Dark red, high capsaicin" }
    ],
    seedRate: "200 - 250 g/Acre (Transplanted)",
    idealSoil: "Deep fertile sandy loam or clay loam with pH 6.0 - 7.0",
    waterNeed: "Moderate, sensitive to waterlogging and severe drought",
    fertilizerNpk: "100:50:50 kg N:P2O5:K2O per ha with split nitrogen",
    keyPests: "Thrips, Mites, Whiteflies, Anthracnose fruit rot, Leaf curl virus",
    harvestingTips: "Harvest green chillies when fully grown and firm; harvest red ripe fruits for drying in bright sun."
  }
];
