export const schemesData = [
  {
    id: "kalia-scheme",
    name: "KALIA Scheme (Krushak Assistance for Livelihood and Income Augmentation)",
    nameOr: "କାଳିଆ ଯୋଜନା (KALIA Scheme)",
    nameHi: "कालिया योजना (ओडिशा)",
    category: "financial",
    govType: "odisha",
    badge: "Odisha State Flagship",
    subsidyBenefit: "₹10,000 per year per farm family (₹4,000 for Kharif + ₹4,000 for Rabi) + ₹12,500 for landless laborers",
    subsidyBenefitOr: "ପ୍ରତି ବର୍ଷ ₹୧୦,୦୦୦ ଆର୍ଥିକ ସହାୟତା (ଖରିଫ୍ ₹୪,୦୦୦ + ରବି ₹୪,୦୦୦) ଏବଂ ଭୂମିହୀନ କୃଷି ଶ୍ରମିକଙ୍କ ପାଇଁ ₹୧୨,୫୦୦",
    subsidyBenefitHi: "₹10,000 प्रति वर्ष सहायता (खरीफ ₹4,000 + रबी ₹4,000) तथा भूमिहीन मजदूरों के लिए ₹12,500",
    description: "Flagship welfare scheme by Government of Odisha for small, marginal farmers and landless agricultural households for crop cultivation, livelihood financing, and life insurance.",
    descriptionOr: "କ୍ଷୁଦ୍ର, ନାମମାତ୍ର ଏବଂ ଭୂମିହୀନ ଚାଷୀ ପରିବାରଙ୍କୁ ବିହନ, ସାର କିଣିବା ଏବଂ ଜୀବିକା ବିକାଶ ପାଇଁ ଓଡ଼ିଶା ସରକାରଙ୍କ ପ୍ରମୁଖ ଯୋଜନା।",
    eligibility: [
      "Small and marginal farmers of Odisha having valid land records (up to 5 acres).",
      "Landless agricultural households dependent on wage labor.",
      "Vulnerable agricultural households (aged/disabled/widow farmers)."
    ],
    documentsNeeded: [
      "Aadhaar Card linked to Mobile",
      "Valid Bank Passbook with IFSC",
      "Land Record / RoR (Khatian / Patta) or Landless certificate",
      "Ration Card / Food Security Card"
    ],
    officialUrl: "https://kaliaportal.odisha.gov.in/",
    helpline: "1800-572-1122 (Toll Free KALIA Helpline)",
    icon: "💰"
  },
  {
    id: "saurajalanidhi-kusum",
    name: "Saurajalanidhi & PM-KUSUM Solar Pump Scheme",
    nameOr: "ସୌରଜଳନିଧି ଏବଂ ପିଏମ-କୁସୁମ ସୌର ପମ୍ପ ଯୋଜନା",
    nameHi: "सौर जलनिधि एवं पीएम-कुसुम सौर पंप",
    category: "irrigation",
    govType: "odisha",
    badge: "Up to 90% Subsidy",
    subsidyBenefit: "90% Subsidy for SC/ST/Small/Marginal Farmers (Farmer pays only 10% of Solar Pump cost, 0.5 HP - 5 HP)",
    subsidyBenefitOr: "SC/ST ଏବଂ କ୍ଷୁଦ୍ର ଚାଷୀଙ୍କ ପାଇଁ ୯୦% ପର୍ଯ୍ୟନ୍ତ ସବସିଡି (ଚାଷୀ ମାତ୍ର ୧୦% ଟଙ୍କା ଦେବେ)",
    subsidyBenefitHi: "छोटे व सीमांत किसानों को 90% तक की भारी सब्सिडी (किसान को केवल 10% देना होगा)",
    description: "Provides solar photovoltaic water pumping systems for irrigation in off-grid and un-electrified agricultural lands across Odisha, reducing diesel/electricity costs.",
    descriptionOr: "ଡିଜେଲ ଏବଂ ବିଦ୍ୟୁତ ଖର୍ଚ୍ଚ ନ କରି ଚାଷ ଜମିରେ ସୌର ଶକ୍ତି ଚାଳିତ ପାଣି ମୋଟର ଲଗାଇବା ପାଇଁ ସରକାରୀ ରିହାତି।",
    eligibility: [
      "Must have at least 0.5 acre of cultivable land.",
      "Land should have an existing dug well, borewell, or perennial water source.",
      "Land must not be electrified previously under agricultural feeder."
    ],
    documentsNeeded: [
      "Land RoR (Patta) copy",
      "Aadhaar Card",
      "Passport size photograph",
      "Bank Account details",
      "Caste Certificate (for SC/ST higher subsidy)"
    ],
    officialUrl: "https://odishasolarpump.nic.in/",
    helpline: "1800-180-1551",
    icon: "☀️"
  },
  {
    id: "odisha-farm-mechanization",
    name: "Farm Mechanization Subsidy (DBT Farm Machinery Odisha)",
    nameOr: "କୃଷି ଯନ୍ତ୍ରପାତି ରିହାତି ଯୋଜନା (Farm Machinery DBT)",
    nameHi: "कृषि यंत्र सब्सिडी पोर्टल (ओडिशा)",
    category: "machinery",
    govType: "odisha",
    badge: "50% to 75% Subsidy",
    subsidyBenefit: "₹70,000 to ₹3,50,000 subsidy on Tractors, Power Tillers, Paddy Transplanters, Combine Harvesters & Solar Dryers",
    subsidyBenefitOr: "ଟ୍ରାକ୍ଟର, ପାୱାର ଟିଲର୍, ରୋଇବା ମେସିନ୍, ଧାନ କଟା ମେସିନ୍ ଉପରେ ୫୦% ରୁ ୭୫% ରିହାତି",
    subsidyBenefitHi: "ट्रैक्टर, पावर टिलर, धान रोपाई मशीन एवं कंबाइन हार्वेस्टर पर 50% से 75% तक की सीधी सब्सिडी",
    description: "Direct Benefit Transfer (DBT) on agricultural machinery to increase farm power, reduce manual drudgery, and ensure timely sowing and harvesting.",
    descriptionOr: "କମ୍ ଖର୍ଚ୍ଚରେ ଉନ୍ନତ କୃଷି ଯନ୍ତ୍ରପାତି କିଣି କ୍ଷେତ କାର୍ଯ୍ୟକୁ ସହଜ ଓ ଲାଭଜନକ କରିବା ପାଇଁ ସିଧାସଳଖ ବ୍ୟାଙ୍କ ଖାତାକୁ ରିହାତି।",
    eligibility: [
      "All registered farmers on Krushak Odisha portal.",
      "Priority given to Women SHGs, SC/ST, and Small/Marginal farmers."
    ],
    documentsNeeded: [
      "Farmer ID (Krushak Odisha Registration)",
      "Land Record (Patta)",
      "Aadhaar Card & Mobile Number",
      "Bank Passbook copy",
      "Quotation from authorized dealer"
    ],
    officialUrl: "https://odishafarmmachinery.nic.in/",
    helpline: "0674-2395532",
    icon: "🚜"
  },
  {
    id: "pm-kisan",
    name: "PM-KISAN (Pradhan Mantri Kisan Samman Nidhi)",
    nameOr: "ପ୍ରଧାନମନ୍ତ୍ରୀ କିଷାନ ସମ୍ମାନ ନିଧି (PM-KISAN)",
    nameHi: "प्रधानमंत्री किसान सम्मान निधि (PM-KISAN)",
    category: "financial",
    govType: "central",
    badge: "₹6,000 / Year Direct to Bank",
    subsidyBenefit: "₹6,000 per year transferred in 3 equal four-monthly installments of ₹2,000 directly via DBT",
    subsidyBenefitOr: "ପ୍ରତି ବର୍ଷ ₹୬,୦୦୦ ଟଙ୍କା (୩ଟି କିସ୍ତିରେ ₹୨,୦୦୦ ଲେଖାଏଁ) ସିଧାସଳଖ ବ୍ୟାଙ୍କ ଖାତାରେ ଜମା",
    subsidyBenefitHi: "₹6,000 प्रति वर्ष 3 समान किस्तों (₹2,000 प्रत्येक) में सीधे बैंक खाते में",
    description: "Central government income support scheme to enable small and marginal landholding farmer families to meet farm input costs and domestic needs.",
    descriptionOr: "କେନ୍ଦ୍ର ସରକାରଙ୍କ ଦ୍ୱାରା ଦେଶର ଚାଷୀମାନଙ୍କୁ ବିହନ ଓ ସାର ଖର୍ଚ୍ଚ ପାଇଁ ବାର୍ଷିକ ଆର୍ଥିକ ସହାୟତା।",
    eligibility: [
      "All landholding farmer families having cultivable land in their names.",
      "Must have completed e-KYC on PM-KISAN portal.",
      "Institutional landholders and high-income tax payees excluded."
    ],
    documentsNeeded: [
      "Aadhaar Number (Biometric e-KYC verified)",
      "Land Record (Khatian / RoR / Bhu-Naksha)",
      "Aadhaar-linked Bank Account"
    ],
    officialUrl: "https://pmkisan.gov.in/",
    helpline: "155261 / 011-24300606",
    icon: "🏦"
  },
  {
    id: "pm-fasal-bima",
    name: "PM Fasal Bima Yojana (PMFBY Crop Insurance)",
    nameOr: "ପ୍ରଧାନମନ୍ତ୍ରୀ ଫସଲ ବୀମା ଯୋଜନା (PMFBY)",
    nameHi: "प्रधानमंत्री फसल बीमा योजना (PMFBY)",
    category: "insurance",
    govType: "central",
    badge: "Full Crop Loss Protection",
    subsidyBenefit: "Comprehensive insurance against natural disasters (cyclone, drought, flood, pest attack) at only 1.5% - 2% premium",
    subsidyBenefitOr: "ବାତ୍ୟା, ମରୁଡ଼ି, ବନ୍ୟା ଓ ରୋଗ ପୋକ ଆକ୍ରମଣରୁ ଫସଲ ନଷ୍ଟ ହେଲେ ସମ୍ପୂର୍ଣ୍ଣ କ୍ଷତିପୂରଣ (ମାତ୍ର ୨% ପ୍ରିମିୟମ୍)",
    subsidyBenefitHi: "बाढ़, सूखा, चक्रवात और कीट से फसल नुकसान पर शत-प्रतिशत बीमा सुरक्षा (मात्र 1.5-2% प्रीमियम)",
    description: "Protection against non-preventable natural risks from pre-sowing to post-harvest stages. State Govt of Odisha pays the remaining share of premium.",
    descriptionOr: "ପ୍ରାକୃତିକ ବିପର୍ଯ୍ୟୟ କାରଣରୁ ଚାଷ ନଷ୍ଟ ହେଲେ ଚାଷୀଙ୍କୁ ବଡ଼ ଆର୍ଥିକ ସୁରକ୍ଷା ଦେବା ପାଇଁ ବିମା ବ୍ୟବସ୍ଥା।",
    eligibility: [
      "All farmers including sharecroppers and tenant farmers growing notified crops in notified areas.",
      "Loanee farmers covered automatically; non-loanee can enroll online or at Mo Seva Kendra / CSC."
    ],
    documentsNeeded: [
      "Land Possession Certificate (LPC) / Patta",
      "Sowing Certificate from Village Agricultural Worker (VAW)",
      "Aadhaar Card & Bank Passbook",
      "Tenancy agreement (for sharecroppers)"
    ],
    officialUrl: "https://pmfby.gov.in/",
    helpline: "1800-180-1111 (PMFBY Toll Free)",
    icon: "🛡️"
  },
  {
    id: "odisha-millet-mission",
    name: "Odisha Millets Mission (OMM Promotion Scheme)",
    nameOr: "ଓଡ଼ିଶା ମିଲେଟ୍ ମିଶନ (ମାଣ୍ଡିଆ ଓ କ୍ଷୁଦ୍ର ଶସ୍ୟ ପ୍ରୋତ୍ସାହନ)",
    nameHi: "ओडिशा मिलेट मिशन (रागी एवं मोटे अनाज)",
    category: "financial",
    govType: "odisha",
    badge: "₹3,000 / Hectare Direct Incentive",
    subsidyBenefit: "Direct cash incentive of ₹3,000 per ha for Millet/Ragi farmers + Guaranteed MSP Procurement @ ₹4,290/Qtl + Free improved seeds",
    subsidyBenefitOr: "ମାଣ୍ଡିଆ ଚାଷୀଙ୍କ ପାଇଁ ହେକ୍ଟର ପିଛା ₹୩,୦୦୦ ନଗଦ ପ୍ରୋତ୍ସାହନ + ମଣ୍ଡିରେ ସରକାରୀ ଦର (MSP) ରେ ସିଧାସଳଖ ଧାନ ଭଳି ବିକ୍ରି",
    subsidyBenefitHi: "मोटा अनाज/रागी उगाने पर ₹3,000 प्रति हेक्टेयर प्रोत्साहन + न्यूनतम समर्थन मूल्य (MSP) पर पक्की खरीद",
    description: "Special state initiative to revive nutritious millets, drought-resistant farming in tribal & rainfed upland districts of Odisha.",
    descriptionOr: "ପୁଷ୍ଟିକର ମାଣ୍ଡିଆ, ସୁଆଁ, କଙ୍ଗୁ ଚାଷକୁ ବୃଦ୍ଧି କରିବା ଏବଂ ଚାଷୀଙ୍କୁ ଉଚିତ ବଜାର ଦର ଦେବା ପାଇଁ ରାଜ୍ୟ ସରକାରଙ୍କ ଯୋଜନା।",
    eligibility: [
      "Farmers growing Ragi (Mandia), Little Millet (Suan), Foxtail Millet in Odisha districts.",
      "Special focus on women SHGs and tribal farmers."
    ],
    documentsNeeded: [
      "Farmer ID / Krushak Odisha card",
      "Aadhaar Card",
      "Bank details",
      "Land details"
    ],
    officialUrl: "https://milletsodisha.com/",
    helpline: "0674-2391325",
    icon: "🌾"
  },
  {
    id: "kisan-credit-card",
    name: "Kisan Credit Card (KCC) Low-Interest Crop Loan",
    nameOr: "କିଷାନ କ୍ରେଡିଟ୍ କାର୍ଡ (KCC ସୁବିଧା ଋଣ)",
    nameHi: "किसान क्रेडिट कार्ड (KCC 4% ब्याज ऋण)",
    category: "financial",
    govType: "central",
    badge: "Low Interest @ 4% p.a.",
    subsidyBenefit: "Short-term crop loan up to ₹3,00,000 at effective interest rate of 4% per annum (with prompt repayment 3% subvention)",
    subsidyBenefitOr: "ବାର୍ଷିକ ମାତ୍ର ୪% ସୁଧ ହାରରେ ₹୩ ଲକ୍ଷ ପର୍ଯ୍ୟନ୍ତ କୃଷି ଋଣ ସୁବିଧା ଏବଂ ସମୟରେ ପରିଶୋଧ କଲେ ୩% ରିହାତି",
    subsidyBenefitHi: "फसल बुवाई व खाद हेतु ₹3 लाख तक का कृषि ऋण मात्र 4% प्रभावी वार्षिक ब्याज दर पर",
    description: "Provides timely and hassle-free banking credit to farmers for purchase of seeds, fertilizers, pesticides, and post-harvest household expenses.",
    descriptionOr: "ମହାଜନ ବା ଦଲାଲଙ୍କ ଉଚ୍ଚ ସୁଧରୁ ବଞ୍ଚି ବ୍ୟାଙ୍କରୁ ସୁଲଭ ସୁଧରେ କୃଷି ଋଣ ପାଇବା ପାଇଁ କିଷାନ କାର୍ଡ।",
    eligibility: [
      "All individual farmers, tenant farmers, oral lessees, and sharecroppers.",
      "Animal husbandry, dairy, and fisheries farmers are also eligible up to ₹2 Lakh."
    ],
    documentsNeeded: [
      "Duly filled KCC application form",
      "Aadhaar Card & Voter ID",
      "Land Record (Patta / RoR)",
      "Two passport size photos"
    ],
    officialUrl: "https://www.myscheme.gov.in/schemes/kcc",
    helpline: "1800-180-1551",
    icon: "💳"
  },
  {
    id: "odisha-seed-subsidy",
    name: "Certified Seed Distribution Subsidy (Odisha Seeds Portal)",
    nameOr: "ପ୍ରମାଣିତ ବିହନ ରିହାତି ଯୋଜନା (Odisha Seeds Portal)",
    nameHi: "प्रमाणित बीज अनुदान योजना (ओडिशा)",
    category: "seeds",
    govType: "odisha",
    badge: "50% Seed Price Subsidy",
    subsidyBenefit: "Direct subsidy of ₹1,000 to ₹2,500 per quintal on high-yielding certified seeds of Paddy, Pulses, Mustard & Groundnut",
    subsidyBenefitOr: "ଉନ୍ନତ ପ୍ରମାଣିତ ଧାନ, ମୁଗ, ବିରି, ସୋରିଷ ଓ ଚିନାବାଦାମ ବିହନ ଉପରେ ୫୦% ପର୍ଯ୍ୟନ୍ତ ସିଧାସଳଖ ରିହାତି",
    subsidyBenefitHi: "प्रमाणित धान, दलहन व तिलहन बीजों पर 50% तक का सीधा सरकारी अनुदान",
    description: "Supply of foundation and certified quality seeds with high germination rate through PACS, LAMPCS, and Odisha State Seeds Corporation (OSSC).",
    descriptionOr: "ଅଧିକ ଫଳନ ଦେଉଥିବା ବିଶୋଧିତ ସରକାରୀ ବିହନ ସୁଲଭ ମୂଲ୍ୟରେ ଚାଷୀଙ୍କ ପାଖରେ ପହଞ୍ଚାଇବା।",
    eligibility: [
      "Registered farmers of Odisha on Krushak Odisha / SAFAL portal.",
      "Issued through local Primary Agricultural Credit Societies (PACS)."
    ],
    documentsNeeded: [
      "Farmer ID",
      "Aadhaar Card",
      "PACS membership / Voter ID"
    ],
    officialUrl: "https://odishaseedsportal.nic.in/",
    helpline: "0674-2391672",
    icon: "🌱"
  }
];
