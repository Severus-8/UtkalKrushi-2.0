export const govtPortals = [
  {
    name: "Department of Agriculture & Farmers' Empowerment (Odisha)",
    nameOr: "କୃଷି ଓ କୃଷକ ସଶକ୍ତିକରଣ ବିଭାଗ, ଓଡ଼ିଶା ସରକାର",
    category: "State Department",
    url: "https://agri.odisha.gov.in/",
    description: "Policy formulation, farmer welfare programs, Krushak Odisha farmer database, and agricultural extension services.",
    icon: "🏛️",
    badge: "Odisha Govt"
  },
  {
    name: "Krushak Odisha / SAFAL Portal",
    nameOr: "କୃଷକ ଓଡ଼ିଶା / ସଫଳ (SAFAL) ପୋର୍ଟାଲ",
    category: "Farmer Registry & Loans",
    url: "https://safal.odisha.gov.in/",
    description: "Simplified application for agricultural loans, DBT subsidies, and single window farmer identity (FID) system.",
    icon: "🌾",
    badge: "Credit & DBT"
  },
  {
    name: "Odisha Farm Machinery Portal (DBT)",
    nameOr: "ଓଡ଼ିଶା କୃଷି ଯନ୍ତ୍ରପାତି ପୋର୍ଟାଲ",
    category: "Machinery Subsidy",
    url: "https://odishafarmmachinery.nic.in/",
    description: "Direct subsidy application for tractors, power tillers, rotavators, sprayers, and combine harvesters.",
    icon: "🚜",
    badge: "Direct Benefit"
  },
  {
    name: "Odisha State Seeds Portal",
    nameOr: "ଓଡ଼ିଶା ରାଜ୍ୟ ବିହନ ପୋର୍ଟାଲ",
    category: "Quality Seeds",
    url: "https://odishaseedsportal.nic.in/",
    description: "Subsidized certified paddy, pulses, and oilseeds distribution tracker across PACS and LAMPCS.",
    icon: "🌱",
    badge: "Seeds DBT"
  },
  {
    name: "e-NAM (National Agriculture Market)",
    nameOr: "ଇ-ନାମ (eNAM ଜାତୀୟ କୃଷି ବଜାର)",
    category: "Mandi Trading",
    url: "https://enam.gov.in/",
    description: "Pan-India electronic trading portal networking existing APMC mandis to create a unified national market.",
    icon: "📈",
    badge: "National APMC"
  },
  {
    name: "ICAR - National Rice Research Institute (NRRI Cuttack)",
    nameOr: "ଜାତୀୟ ଧାନ ଗବେଷଣା ପ୍ରତିଷ୍ଠାନ (NRRI କଟକ)",
    category: "Research & Varieties",
    url: "https://icar-nrri.gov.in/",
    description: "Pioneering rice research, climate-resilient paddy varieties, flood/drought tolerant seeds for eastern India.",
    icon: "🔬",
    badge: "ICAR Institute"
  },
  {
    name: "OUAT (Odisha University of Agriculture & Technology)",
    nameOr: "ଓଡ଼ିଶା କୃଷି ଓ ବୈଷୟିକ ବିଶ୍ୱବିଦ୍ୟାଳୟ (OUAT ଭୁବନେଶ୍ୱର)",
    category: "Education & Advisory",
    url: "http://www.ouat.ac.in/",
    description: "State agricultural university offering Krishi Vigyan Kendra (KVK) advisory, soil testing, and farmer training.",
    icon: "🎓",
    badge: "State Agronomy"
  },
  {
    name: "PM-KISAN Portal",
    nameOr: "ପ୍ରଧାନମନ୍ତ୍ରୀ କିଷାନ ସମ୍ମାନ ନିଧି ପୋର୍ଟାଲ",
    category: "Income Support",
    url: "https://pmkisan.gov.in/",
    description: "Direct beneficiary transfer of ₹6,000/year to landholder farmer families with e-KYC and status check.",
    icon: "💵",
    badge: "Central Govt"
  },
  {
    name: "PM Fasal Bima Yojana (PMFBY)",
    nameOr: "ପ୍ରଧାନମନ୍ତ୍ରୀ ଫସଲ ବୀମା ପୋର୍ଟାଲ",
    category: "Crop Insurance",
    url: "https://pmfby.gov.in/",
    description: "Online insurance application, claim calculation, policy status check, and grievance redressal for crop losses.",
    icon: "🛡️",
    badge: "Crop Insurance"
  },
  {
    name: "Odisha Solar Pump (PM-KUSUM) Portal",
    nameOr: "ଓଡ଼ିଶା ସୌର ପମ୍ପ ଯୋଜନା (ସୌରଜଳନିଧି)",
    category: "Renewable Irrigation",
    url: "https://odishasolarpump.nic.in/",
    description: "Application tracking for 90% subsidized solar photovoltaic water pumping sets for irrigation.",
    icon: "☀️",
    badge: "Solar Irrigation"
  },
  {
    name: "Odisha State Cooperative Bank (OSCB)",
    nameOr: "ଓଡ଼ିଶା ରାଜ୍ୟ ସମବାୟ ବ୍ୟାଙ୍କ",
    category: "Cooperative Credit",
    url: "https://odishascb.com/",
    description: "Agricultural crop loans, Kisan Credit Cards, short-term and medium-term rural development credit.",
    icon: "🏦",
    badge: "Rural Banking"
  },
  {
    name: "Directorate of Economics & Statistics (DES Agriculture)",
    nameOr: "ଅର୍ଥନୀତି ଓ ପରିସଂଖ୍ୟାନ ନିର୍ଦ୍ଦେଶାଳୟ",
    category: "MSP & Crop Statistics",
    url: "https://desagri.gov.in/",
    description: "Official notifications for Minimum Support Prices (MSP), crop area statistics, and agriculture census.",
    icon: "📊",
    badge: "MSP Data"
  }
];
