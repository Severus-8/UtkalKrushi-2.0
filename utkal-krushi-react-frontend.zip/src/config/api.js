// Backend API Configuration
//
// By default the app calls the backend through RELATIVE paths ("/api/..."),
// which the Vite dev server proxies to Django (see vite.config.js). This works
// in dev, in previews, and avoids CORS entirely. For a standalone build that
// talks to a backend on another origin, set VITE_API_BASE_URL, e.g.:
//     VITE_API_BASE_URL=https://api.example.com/api
//
// If the backend is unreachable, every feature degrades gracefully to its
// built-in offline engine (static data / local calculators), so the app stays
// usable on patchy rural connectivity.

export const API_CONFIG = {
  BASE_URL: (import.meta.env.VITE_API_BASE_URL || "/api").replace(/\/+$/, ""),
  ENDPOINTS: {
    // 1. Weather & Agro-Advisory
    WEATHER: "/weather",

    // 2. AI Crop Doctor & Disease Diagnosis
    CROP_DIAGNOSE: "/crop-doctor/diagnose",

    // 3. Fertilizer & Soil Calculator
    FERTILIZER_CALCULATE: "/fertilizer/calculate",

    // 4. Mandi & Market Prices
    MANDI_PRICES: "/mandi/prices",

    // 5. Government Subsidies & Schemes
    SCHEMES: "/schemes",

    // 6. Krushi AI Chatbot
    CHATBOT: "/chatbot/ask",

    // 7. Farmer Farm Ledger (Khata)
    LEDGER: "/ledger",
    LEDGER_SAVE: "/ledger/save",

    // 8. Authentication / Farmer Profile
    AUTH_LOGIN: "/auth/login",
    AUTH_REGISTER: "/auth/register",
  },
};

/**
 * Small JSON fetch helper with a timeout.
 * Resolves with parsed JSON, rejects on network error / non-2xx / timeout.
 */
export async function apiFetch(path, { method = "GET", body, timeoutMs = 8000, headers = {} } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(`${API_CONFIG.BASE_URL}${path}`, {
      method,
      signal: controller.signal,
      headers: { "Content-Type": "application/json", ...headers },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
    if (!res.ok) {
      let detail = `API error ${res.status}`;
      try {
        const err = await res.json();
        if (err?.detail) detail = err.detail;
      } catch { /* ignore body parse errors */ }
      throw new Error(detail);
    }
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}
