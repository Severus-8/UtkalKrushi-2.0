// Backend API Configuration
// When your friend connects their backend server (Node.js, Python, Java, etc.),
// they can simply change BASE_URL or set VITE_API_BASE_URL in a .env file.

export const API_CONFIG = {
  BASE_URL: import.meta.env.VITE_API_BASE_URL || "http://localhost:5000/api",
  ENDPOINTS: {
    // 1. Weather & Agro-Advisory
    WEATHER: "/weather",
    
    // 2. AI Crop Doctor & Disease Diagnosis
    CROP_DIAGNOSE: "/crop-doctor/diagnose",
    
    // 3. Fertilizer & Soil Calculator
    FERTILIZER_CALCULATE: "/fertilizer/calculate",
    
    // 4. Mandi & Market Prices
    MANDI_PRICES: "/mandi/prices",
    
    // 5. Government Subsidies & Schemes
    SCHEMES: "/schemes",
    
    // 6. Krushi AI Chatbot
    CHATBOT: "/chatbot/ask",
    
    // 7. Farmer Farm Ledger (Khata)
    LEDGER: "/ledger",
    
    // 8. Authentication / Farmer Profile
    AUTH_LOGIN: "/auth/login",
    AUTH_REGISTER: "/auth/register",
  }
};
