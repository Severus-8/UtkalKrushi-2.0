import React from 'react';
import { 
  Sprout, 
  PhoneCall, 
  Mail, 
  Heart, 
  ShieldCheck, 
  ExternalLink,
  MapPin
} from 'lucide-react';
import { translations } from '../data/translations';

export default function Footer({ currentLang, setActiveTab, onOpenHelpline }) {
  const t = translations[currentLang] || translations.en;

  return (
    <footer className="mt-16 bg-slate-900 text-slate-300 border-t border-slate-800">
      
      {/* Top Banner with Helpline Action */}
      <div className="bg-gradient-to-r from-farm-800 to-farm-900 py-6 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center font-bold shrink-0">
              <PhoneCall className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-white text-sm sm:text-base">
                {currentLang === 'or' ? 'କୌଣସି କୃଷି ସମସ୍ୟାର ସମାଧାନ ପାଇଁ ମାଗଣା କଲ୍ କରନ୍ତୁ' : 'Need instant agronomy support for your crop?'}
              </h4>
              <p className="text-xs text-farm-200">
                Kisan Call Center: 1551 (6 AM - 10 PM) | Odisha Krushi: 1800-180-1551
              </p>
            </div>
          </div>

          <button
            onClick={onOpenHelpline}
            className="px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold shadow-lg transition-transform active:scale-95 shrink-0"
          >
            Open All Helplines
          </button>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          
          {/* Brand Column */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-farm-600 flex items-center justify-center text-white font-bold shadow-md">
                <Sprout className="w-6 h-6" />
              </div>
              <div>
                <span className="text-xl font-extrabold text-white">
                  {t.appName}
                </span>
                <span className="block text-xs text-slate-400">
                  {t.appTagline}
                </span>
              </div>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed max-w-md">
              {t.footerAbout}
            </p>

            <div className="pt-2 flex items-center gap-2 text-xs text-slate-400">
              <MapPin className="w-4 h-4 text-farm-500" />
              <span>Bhubaneswar, Odisha, India</span>
            </div>
          </div>

          {/* Quick Links Column */}
          <div className="space-y-3">
            <h5 className="font-bold text-xs uppercase tracking-wider text-white">
              {t.quickLinks}
            </h5>
            <ul className="space-y-2 text-xs">
              <li>
                <button 
                  onClick={() => setActiveTab('weather')} 
                  className="hover:text-farm-400 transition-colors"
                >
                  {t.navWeather}
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setActiveTab('cropdoctor')} 
                  className="hover:text-farm-400 transition-colors"
                >
                  {t.navCropDoctor}
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setActiveTab('fertilizer')} 
                  className="hover:text-farm-400 transition-colors"
                >
                  {t.navFertilizer}
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setActiveTab('mandi')} 
                  className="hover:text-farm-400 transition-colors"
                >
                  {t.navMandi}
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setActiveTab('schemes')} 
                  className="hover:text-farm-400 transition-colors"
                >
                  {t.navSchemes}
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setActiveTab('ledger')} 
                  className="hover:text-farm-400 transition-colors"
                >
                  {t.navLedger}
                </button>
              </li>
            </ul>
          </div>

          {/* Government References */}
          <div className="space-y-3">
            <h5 className="font-bold text-xs uppercase tracking-wider text-white">
              Key Govt Portals
            </h5>
            <ul className="space-y-2 text-xs">
              <li>
                <a 
                  href="https://agri.odisha.gov.in" 
                  target="_blank" 
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 hover:text-farm-400 transition-colors"
                >
                  <span>DAFE Odisha</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </li>
              <li>
                <a 
                  href="https://safal.odisha.gov.in" 
                  target="_blank" 
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 hover:text-farm-400 transition-colors"
                >
                  <span>Krushak Odisha / SAFAL</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </li>
              <li>
                <a 
                  href="https://kaliaportal.odisha.gov.in" 
                  target="_blank" 
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 hover:text-farm-400 transition-colors"
                >
                  <span>KALIA Portal</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </li>
              <li>
                <a 
                  href="https://enam.gov.in" 
                  target="_blank" 
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 hover:text-farm-400 transition-colors"
                >
                  <span>e-NAM Mandi Portal</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </li>
              <li>
                <a 
                  href="https://pmfby.gov.in" 
                  target="_blank" 
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 hover:text-farm-400 transition-colors"
                >
                  <span>PM Fasal Bima</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>© {new Date().getFullYear()} Utkal Krushi (ଉତ୍କଳ କୃଷି). Dedicated to Odisha's Farming Community.</p>
          <div className="flex items-center gap-1 text-farm-400 font-semibold">
            <span>{t.madeWithLove}</span>
          </div>
        </div>
      </div>

    </footer>
  );
}
