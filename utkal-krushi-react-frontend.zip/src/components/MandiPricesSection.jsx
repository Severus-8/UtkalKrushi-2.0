import React, { useState } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  Minus, 
  Search, 
  Filter, 
  MapPin, 
  CheckCircle2, 
  AlertCircle, 
  Calendar, 
  Sparkles,
  ArrowUpDown
} from 'lucide-react';
import { translations } from '../data/translations';
import { mandiData, odishaDistricts } from '../data/mandiPrices';

export default function MandiPricesSection({ currentLang }) {
  const t = translations[currentLang] || translations.en;

  const [searchCommodity, setSearchCommodity] = useState("");
  const [selectedDistrict, setSelectedDistrict] = useState("All Districts");
  const [sortBy, setSortBy] = useState("priceHigh"); // priceHigh, priceLow, changeHigh

  const filteredData = mandiData
    .filter((item) => {
      const matchDistrict = selectedDistrict === "All Districts" || item.district === selectedDistrict;
      const matchCommodity = 
        item.commodity.toLowerCase().includes(searchCommodity.toLowerCase()) ||
        item.commodityOr.toLowerCase().includes(searchCommodity.toLowerCase()) ||
        item.variety.toLowerCase().includes(searchCommodity.toLowerCase()) ||
        item.mandi.toLowerCase().includes(searchCommodity.toLowerCase());
      return matchDistrict && matchCommodity;
    })
    .sort((a, b) => {
      if (sortBy === "priceHigh") return b.marketPrice - a.marketPrice;
      if (sortBy === "priceLow") return a.marketPrice - b.marketPrice;
      if (sortBy === "changeHigh") return b.priceChange - a.priceChange;
      return 0;
    });

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      
      {/* Header Banner */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-900 dark:text-amber-300 text-xs font-bold mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>e-NAM & Odisha APMC Mandi Network</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
              <TrendingUp className="w-7 h-7 text-amber-500" />
              <span>{t.mandiTitle}</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
              {t.mandiSubtitle}
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-800 px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700">
            <Calendar className="w-4 h-4 text-farm-600" />
            <span>Updated Today across Odisha APMCs</span>
          </div>
        </div>

        {/* Filter Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-6 mt-6 border-t border-slate-100 dark:border-slate-800">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1">
              <Search className="w-3.5 h-3.5 text-farm-600" />
              <span>{t.filterCommodity}</span>
            </label>
            <input
              type="text"
              placeholder="Search Paddy, Ragi, Moong, Tomato..."
              value={searchCommodity}
              onChange={(e) => setSearchCommodity(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-sm font-semibold text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-farm-600" />
              <span>{t.filterDistrict}</span>
            </label>
            <select
              value={selectedDistrict}
              onChange={(e) => setSelectedDistrict(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-sm font-semibold text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
            >
              {odishaDistricts.map((d) => (
                <option key={d} value={d}>
                  {d}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1">
              <ArrowUpDown className="w-3.5 h-3.5 text-farm-600" />
              <span>Sort By</span>
            </label>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-sm font-semibold text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
            >
              <option value="priceHigh">Highest Price (₹ / Qtl)</option>
              <option value="priceLow">Lowest Price (₹ / Qtl)</option>
              <option value="changeHigh">Highest Price Gain (+₹)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Mandi Cards / Table */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
        {filteredData.map((item) => {
          const isAboveMsp = item.marketPrice >= item.mspRate;
          const diff = item.marketPrice - item.mspRate;

          return (
            <div
              key={item.id}
              className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-farm-600 shrink-0" />
                    <span>{item.mandi}</span>
                  </span>

                  <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                    isAboveMsp 
                      ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300' 
                      : 'bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300'
                  }`}>
                    {isAboveMsp ? `+₹${diff} Above MSP` : 'Near MSP'}
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  {currentLang === 'or' ? item.commodityOr : item.commodity}
                </h3>
                <span className="text-xs text-slate-500 dark:text-slate-400">
                  Variety: {item.variety}
                </span>

                <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 grid grid-cols-2 gap-3">
                  <div>
                    <span className="text-[11px] text-slate-400 font-medium block">
                      {t.marketPrice}
                    </span>
                    <div className="text-xl font-black text-slate-900 dark:text-white mt-0.5">
                      ₹{item.marketPrice.toLocaleString('en-IN')}
                    </div>
                  </div>

                  <div>
                    <span className="text-[11px] text-slate-400 font-medium block">
                      {t.mspRate}
                    </span>
                    <div className="text-base font-bold text-slate-600 dark:text-slate-300 mt-1">
                      ₹{item.mspRate.toLocaleString('en-IN')}
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                <span className="flex items-center gap-1">
                  {item.trend === 'up' ? (
                    <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
                  ) : item.trend === 'down' ? (
                    <TrendingDown className="w-3.5 h-3.5 text-red-600" />
                  ) : (
                    <Minus className="w-3.5 h-3.5 text-slate-400" />
                  )}
                  <span className={item.trend === 'up' ? 'text-emerald-600 font-semibold' : ''}>
                    {item.priceChange > 0 ? `+₹${item.priceChange}` : `₹${item.priceChange}`}
                  </span>
                </span>
                <span>Arrival: {item.arrivalQty}</span>
              </div>
            </div>
          );
        })}
      </div>

      {filteredData.length === 0 && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-12 text-center border border-slate-200 dark:border-slate-800">
          <p className="text-base font-bold text-slate-700 dark:text-slate-300">
            No mandi rates found for your search.
          </p>
          <p className="text-xs text-slate-500 mt-1">
            Try clearing filters or search for another commodity.
          </p>
        </div>
      )}

    </div>
  );
}
