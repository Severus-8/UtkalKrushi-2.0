import React from 'react';
import { 
  CloudSun, 
  Stethoscope, 
  TrendingUp, 
  Landmark, 
  Calculator, 
  Bot, 
  PhoneCall, 
  ChevronRight, 
  ShieldAlert, 
  Sparkles,
  ArrowUpRight,
  Droplets,
  Calendar,
  CheckCircle2
} from 'lucide-react';
import { translations } from '../data/translations';

export default function DashboardHero({ currentLang, setActiveTab, onOpenHelpline }) {
  const t = translations[currentLang] || translations.en;

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return t.greetingMorning;
    if (hour < 17) return t.greetingAfternoon;
    return t.greetingEvening;
  };

  const quickActionCards = [
    {
      id: 'weather',
      title: t.quickActionWeather,
      desc: currentLang === 'or' ? 'ପାଣିପାଗ, ବର୍ଷା ସୂଚନା ଓ ଔଷଧ ସିଞ୍ଚନ ପରାମର୍ଶ' : 'Forecast, rainfall & pesticide spray advisory',
      icon: CloudSun,
      bgColor: 'bg-sky-50 dark:bg-sky-950/40 border-sky-200 dark:border-sky-800/60 text-sky-700 dark:text-sky-300',
      iconBg: 'bg-sky-500 text-white',
      badge: 'Live Forecast',
      badgeColor: 'bg-sky-100 text-sky-800 dark:bg-sky-900/60 dark:text-sky-300',
    },
    {
      id: 'cropdoctor',
      title: t.quickActionDoctor,
      desc: currentLang === 'or' ? 'ପତ୍ରର ଫଟୋ ଉଠାଇ ତୁରନ୍ତ ରୋଗ ନିରୂପଣ ଓ ଔଷଧ ଜାଣନ୍ତୁ' : 'Photo leaf scan & AI prescription with dosage',
      icon: Stethoscope,
      bgColor: 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800/60 text-emerald-700 dark:text-emerald-300',
      iconBg: 'bg-emerald-600 text-white',
      badge: 'AI Doctor',
      badgeColor: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/60 dark:text-emerald-300',
    },
    {
      id: 'mandi',
      title: t.quickActionMandi,
      desc: currentLang === 'or' ? 'ଓଡ଼ିଶା ମଣ୍ଡି ଦର ଓ ସରକାରୀ ଏମଏସପି (MSP) ତୁଳନା' : 'Live APMC market rates vs MSP benchmark',
      icon: TrendingUp,
      bgColor: 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800/60 text-amber-700 dark:text-amber-300',
      iconBg: 'bg-amber-500 text-slate-900',
      badge: 'Daily Rates',
      badgeColor: 'bg-amber-100 text-amber-900 dark:bg-amber-900/60 dark:text-amber-300',
    },
    {
      id: 'schemes',
      title: t.quickActionSchemes,
      desc: currentLang === 'or' ? 'କାଳିଆ, ସୌର ପମ୍ପ (୯୦%), ଟ୍ରାକ୍ଟର ରିହାତି ଓ ବୀମା' : 'KALIA, 90% Solar Pump, Machinery & PM-KISAN',
      icon: Landmark,
      bgColor: 'bg-indigo-50 dark:bg-indigo-950/40 border-indigo-200 dark:border-indigo-800/60 text-indigo-700 dark:text-indigo-300',
      iconBg: 'bg-indigo-600 text-white',
      badge: 'Govt Subsidy',
      badgeColor: 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900/60 dark:text-indigo-300',
    },
    {
      id: 'fertilizer',
      title: t.quickActionCalculator,
      desc: currentLang === 'or' ? 'ଜମି ଅନୁସାରେ ୟୁରିଆ, ଡିଏପି ଓ ପୋଟାଶ ବସ୍ତା ହିସାବ' : 'N-P-K bags & expected crop yield calculator',
      icon: Calculator,
      bgColor: 'bg-lime-50 dark:bg-lime-950/40 border-lime-200 dark:border-lime-800/60 text-lime-800 dark:text-lime-300',
      iconBg: 'bg-lime-600 text-white',
      badge: 'Soil & Yield',
      badgeColor: 'bg-lime-100 text-lime-800 dark:bg-lime-900/60 dark:text-lime-300',
    },
    {
      id: 'chatbot',
      title: t.quickActionAiChat,
      desc: currentLang === 'or' ? 'ଓଡ଼ିଆରେ କଥା ହୁଅନ୍ତୁ ଓ କୃଷି ସମ୍ପର୍କିତ ସମସ୍ତ ଉତ୍ତର ପାଆନ୍ତୁ' : 'Voice-enabled AI agronomist assistant',
      icon: Bot,
      bgColor: 'bg-teal-50 dark:bg-teal-950/40 border-teal-200 dark:border-teal-800/60 text-teal-800 dark:text-teal-300',
      iconBg: 'bg-teal-600 text-white',
      badge: 'Voice Assistant',
      badgeColor: 'bg-teal-100 text-teal-800 dark:bg-teal-900/60 dark:text-teal-300',
    },
  ];

  const featuredCrops = [
    {
      name: currentLang === 'or' ? 'ଧାନ (Paddy)' : 'Paddy / Rice',
      variety: 'Swarna / Pooja / MTU 1010',
      msp: '₹2,300 / Qtl',
      season: 'Kharif / Dalua',
      tag: 'Main Crop',
      img: 'https://images.unsplash.com/photo-1530507629858-e4977d30e9e0?auto=format&fit=crop&w=400&q=80'
    },
    {
      name: currentLang === 'or' ? 'ମାଣ୍ଡିଆ (Ragi)' : 'Ragi / Millets',
      variety: 'Bhairabi / Chilika',
      msp: '₹4,290 / Qtl',
      season: 'Millets Mission',
      tag: 'High MSP',
      img: 'https://images.unsplash.com/photo-1551754655-cd27e38d2076?auto=format&fit=crop&w=400&q=80'
    },
    {
      name: currentLang === 'or' ? 'ମୁଗ ଓ ବିରି' : 'Pulses (Moong/Urad)',
      variety: 'IPM 02-03 / PU 31',
      msp: '₹8,682 / Qtl',
      season: 'Rabi / Summer',
      tag: 'Cash Pulse',
      img: 'https://images.unsplash.com/photo-1586771107445-d3ca888129ff?auto=format&fit=crop&w=400&q=80'
    },
    {
      name: currentLang === 'or' ? 'ସୋରିଷ ଓ ବାଦାମ' : 'Oilseeds (Mustard/Groundnut)',
      variety: 'Pusa Bold / Kadiri 6',
      msp: '₹5,650 / Qtl',
      season: 'Rabi Season',
      tag: 'Oilseed',
      img: 'https://images.unsplash.com/photo-1595855759920-86582396756a?auto=format&fit=crop&w=400&q=80'
    },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      
      {/* Hero Welcome Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-farm-800 via-farm-900 to-slate-900 text-white p-6 sm:p-10 shadow-xl">
        <div className="absolute -right-16 -bottom-16 w-80 h-80 bg-farm-500/20 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute -left-16 -top-16 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 max-w-3xl">
          {/* Greeting Pill */}
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/10 backdrop-blur-md border border-white/15 text-harvest-300 text-xs sm:text-sm font-semibold mb-4">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>{getGreeting()}</span>
          </div>

          <h1 className="text-2xl sm:text-4xl lg:text-5xl font-black tracking-tight leading-tight text-white mb-3">
            {t.heroTitle}
          </h1>

          <p className="text-sm sm:text-base text-slate-200 leading-relaxed mb-6 font-normal">
            {t.heroSubtitle}
          </p>

          {/* Action Button Row */}
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setActiveTab('cropdoctor')}
              className="inline-flex items-center gap-2 px-5 py-3 rounded-2xl bg-gradient-to-r from-farm-500 to-farm-600 hover:from-farm-600 hover:to-farm-700 text-white font-bold text-sm shadow-lg shadow-farm-600/30 transition-transform active:scale-95"
            >
              <Stethoscope className="w-4 h-4" />
              <span>{t.quickActionDoctor}</span>
            </button>

            <button
              onClick={() => setActiveTab('weather')}
              className="inline-flex items-center gap-2 px-5 py-3 rounded-2xl bg-white/15 hover:bg-white/25 backdrop-blur-md text-white font-bold text-sm border border-white/20 transition-all active:scale-95"
            >
              <CloudSun className="w-4 h-4 text-sky-300" />
              <span>{t.quickActionWeather}</span>
            </button>

            <button
              onClick={onOpenHelpline}
              className="inline-flex items-center gap-2 px-4 py-3 rounded-2xl bg-amber-500 hover:bg-amber-600 text-slate-900 font-bold text-sm transition-all"
            >
              <PhoneCall className="w-4 h-4" />
              <span>1551 Helpline</span>
            </button>
          </div>
        </div>

        {/* Live Weather & MSP Stats Strip */}
        <div className="mt-8 pt-6 border-t border-white/10 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs sm:text-sm">
          <div className="bg-white/5 rounded-xl p-3 border border-white/10">
            <span className="text-slate-400 block text-[11px] font-medium">Odisha Paddy MSP</span>
            <span className="text-base sm:text-lg font-bold text-harvest-300">₹2,300 / Qtl</span>
          </div>
          <div className="bg-white/5 rounded-xl p-3 border border-white/10">
            <span className="text-slate-400 block text-[11px] font-medium">Ragi (Millets) MSP</span>
            <span className="text-base sm:text-lg font-bold text-emerald-400">₹4,290 / Qtl</span>
          </div>
          <div className="bg-white/5 rounded-xl p-3 border border-white/10">
            <span className="text-slate-400 block text-[11px] font-medium">Solar Pump Subsidy</span>
            <span className="text-base sm:text-lg font-bold text-sky-300">Up to 90%</span>
          </div>
          <div className="bg-white/5 rounded-xl p-3 border border-white/10">
            <span className="text-slate-400 block text-[11px] font-medium">Kisan Call Center</span>
            <span className="text-base sm:text-lg font-bold text-amber-300">1551 (Toll Free)</span>
          </div>
        </div>
      </div>

      {/* Main Feature Cards Grid */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <span>🌾</span>
            <span>{currentLang === 'or' ? 'ମୁଖ୍ୟ କୃଷି ସେବା ସମୂହ' : 'Key Agricultural Services'}</span>
          </h2>
          <span className="text-xs text-slate-500 dark:text-slate-400 font-medium hidden sm:inline">
            {currentLang === 'or' ? 'କ୍ଲିକ୍ କରି ସେବା ବ୍ୟବହାର କରନ୍ତୁ' : 'Click any service to start'}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {quickActionCards.map((card) => {
            const Icon = card.icon;
            return (
              <div
                key={card.id}
                onClick={() => setActiveTab(card.id)}
                className={`group cursor-pointer rounded-2xl border p-5 sm:p-6 transition-all duration-200 hover:shadow-lg hover:-translate-y-1 ${card.bgColor}`}
              >
                <div className="flex items-start justify-between gap-3 mb-4">
                  <div className={`w-12 h-12 rounded-2xl ${card.iconBg} flex items-center justify-center shadow-md group-hover:scale-110 transition-transform`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <span className={`text-[11px] font-bold px-2.5 py-1 rounded-full ${card.badgeColor}`}>
                    {card.badge}
                  </span>
                </div>

                <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white group-hover:text-farm-600 dark:group-hover:text-farm-400 transition-colors flex items-center justify-between">
                  <span>{card.title}</span>
                  <ArrowUpRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                </h3>

                <p className="mt-1.5 text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed line-clamp-2">
                  {card.desc}
                </p>

                <div className="mt-4 pt-3 border-t border-slate-200/60 dark:border-slate-800/60 flex items-center text-xs font-bold text-farm-700 dark:text-farm-300 group-hover:gap-2 transition-all">
                  <span>{currentLang === 'or' ? 'ଖୋଲନ୍ତୁ' : 'Open Feature'}</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Featured Crops of Odisha */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
              <span>🌱</span>
              <span>{currentLang === 'or' ? 'ଓଡ଼ିଶାର ପ୍ରମୁଖ ଫସଲ' : 'Featured Major Crops of Odisha'}</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
              {currentLang === 'or' ? 'ଉନ୍ନତ କିସମ, ସରକାରୀ ଦର (MSP) ଏବଂ ଚାଷ ପଦ୍ଧତି' : 'Recommended high-yield varieties and MSP benchmarks'}
            </p>
          </div>
          <button
            onClick={() => setActiveTab('cropguide')}
            className="inline-flex items-center gap-1 text-xs font-bold text-farm-600 dark:text-farm-400 hover:underline"
          >
            <span>{currentLang === 'or' ? 'ସମସ୍ତ ଫସଲ ଗାଇଡ୍ ଦେଖନ୍ତୁ' : 'View Full Crop Cultivation Guide'}</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {featuredCrops.map((crop, idx) => (
            <div
              key={idx}
              onClick={() => setActiveTab('cropguide')}
              className="cursor-pointer group rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 hover:shadow-md hover:border-farm-400 transition-all"
            >
              <div className="h-36 relative overflow-hidden bg-slate-200">
                <img
                  src={crop.img}
                  alt={crop.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  loading="lazy"
                />
                <span className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded-md bg-black/60 backdrop-blur-md text-white text-[10px] font-bold">
                  {crop.tag}
                </span>
              </div>
              <div className="p-4">
                <h4 className="font-bold text-sm sm:text-base text-slate-900 dark:text-white line-clamp-1">
                  {crop.name}
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-1">
                  {crop.variety}
                </p>
                <div className="mt-3 pt-2.5 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between text-xs">
                  <span className="text-slate-500 dark:text-slate-400">{crop.season}</span>
                  <span className="font-bold text-farm-600 dark:text-farm-400">{crop.msp}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
