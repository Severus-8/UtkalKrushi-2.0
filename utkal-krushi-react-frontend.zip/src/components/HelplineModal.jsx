import React from 'react';
import { 
  PhoneCall, 
  X, 
  ShieldCheck, 
  Clock, 
  Sparkles,
  ExternalLink
} from 'lucide-react';
import { translations } from '../data/translations';

export default function HelplineModal({ isOpen, onClose, currentLang }) {
  if (!isOpen) return null;
  const t = translations[currentLang] || translations.en;

  const helplines = [
    {
      title: "Kisan Call Center (National)",
      titleOr: "କିଷାନ କଲ୍ ସେଣ୍ଟର (ଜାତୀୟ)",
      number: "1551",
      tel: "tel:1551",
      desc: "Toll-free agricultural technical support 6 AM to 10 PM daily in all regional languages.",
      badge: "Toll-Free 24x7",
      color: "bg-emerald-500"
    },
    {
      title: "Odisha Krushi Helpline (DAFE)",
      titleOr: "ଓଡ଼ିଶା କୃଷି ସହାୟତା ହେଲ୍ପଲାଇନ",
      number: "1800-180-1551",
      tel: "tel:18001801551",
      desc: "Dedicated Odisha state government agricultural advisor & disease reporting helpline.",
      badge: "Odisha Govt",
      color: "bg-farm-600"
    },
    {
      title: "KALIA Scheme Support",
      titleOr: "କାଳିଆ ଯୋଜନା ସହାୟତା",
      number: "1800-572-1122",
      tel: "tel:18005721122",
      desc: "Direct beneficiary assistance for KALIA installment status and DBT grievance.",
      badge: "KALIA Help",
      color: "bg-indigo-600"
    },
    {
      title: "PM Fasal Bima (Crop Insurance)",
      titleOr: "ପ୍ରଧାନମନ୍ତ୍ରୀ ଫସଲ ବୀମା ହେଲ୍ପଲାଇନ",
      number: "1800-180-1111",
      tel: "tel:18001801111",
      desc: "Report localized crop damage (flood/cyclone) within 72 hours for immediate compensation.",
      badge: "Crop Insurance",
      color: "bg-amber-500"
    },
    {
      title: "Animal Husbandry & Veterinary",
      titleOr: "ପ୍ରାଣୀ ସମ୍ପଦ ଓ ଚିକିତ୍ସା ସେବା",
      number: "1962",
      tel: "tel:1962",
      desc: "Emergency mobile veterinary clinic (Mukhyamantri Prani Kalyan) for livestock & cattle.",
      badge: "Veterinary",
      color: "bg-blue-600"
    },
    {
      title: "State Disaster Management (OSDMA)",
      titleOr: "ରାଜ୍ୟ ବିପର୍ଯ୍ୟୟ ପରିଚାଳନା (ବାତ୍ୟା / ବନ୍ୟା)",
      number: "1070",
      tel: "tel:1070",
      desc: "Cyclone, heavy rain, flood emergency support and relief information.",
      badge: "Disaster Alert",
      color: "bg-red-600"
    }
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-xl w-full p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-6 animate-in zoom-in-95 duration-150 max-h-[90vh] overflow-y-auto">
        
        {/* Header */}
        <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500 text-slate-900 flex items-center justify-center font-bold">
              <PhoneCall className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-black text-slate-900 dark:text-white">
                {t.emergencyHelplinesTitle}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Direct Toll-Free Dialers for Farmers of Odisha
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Helplines List */}
        <div className="space-y-3">
          {helplines.map((h, idx) => (
            <div
              key={idx}
              className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:border-farm-400 transition-colors"
            >
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-bold text-sm text-slate-900 dark:text-white">
                    {currentLang === 'or' ? h.titleOr : h.title}
                  </span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-600">
                    {h.badge}
                  </span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {h.desc}
                </p>
              </div>

              <a
                href={h.tel}
                className="shrink-0 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-farm-600 hover:bg-farm-700 text-white text-xs font-bold shadow-sm transition-all"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>Call {h.number}</span>
              </a>
            </div>
          ))}
        </div>

        {/* Close */}
        <div className="pt-2 text-center">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-200"
          >
            Close Helplines
          </button>
        </div>

      </div>
    </div>
  );
}
