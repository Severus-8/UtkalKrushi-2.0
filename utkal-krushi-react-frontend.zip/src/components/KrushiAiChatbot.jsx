import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, 
  Send, 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  User, 
  RefreshCw, 
  HelpCircle,
  PhoneCall
} from 'lucide-react';
import { translations } from '../data/translations';
import { callGeminiApi } from '../utils/geminiApi';
import { speakText, stopSpeaking, createSpeechRecognizer } from '../utils/speechUtils';

export default function KrushiAiChatbot({ currentLang }) {
  const t = translations[currentLang] || translations.en;

  const initialGreeting = {
    id: 1,
    sender: 'bot',
    text: t.chatGreeting,
    time: 'Just now'
  };

  const [messages, setMessages] = useState([initialGreeting]);
  const [inputText, setInputText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [activeSpeakingId, setActiveSpeakingId] = useState(null);
  const chatBottomRef = useRef(null);
  const speechRecognizerRef = useRef(null);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const quickQuestions = [
    {
      label: currentLang === 'or' ? '🌾 ସ୍ୱର୍ଣ୍ଣ ଧାନ ପାଇଁ ସାର ପ୍ରୟୋଗ ସୂଚୀ?' : '🌾 Best fertilizer schedule for Swarna paddy?',
      query: 'What is the recommended fertilizer schedule for Swarna paddy per acre in Odisha?'
    },
    {
      label: currentLang === 'or' ? '☀️ ସୌର ପମ୍ପରେ ୯୦% ସବସିଡି କିପରି ପାଇବି?' : '☀️ How to get 90% subsidy on Solar Water Pump in Odisha?',
      query: 'Explain how to apply for Saurajalanidhi solar pump subsidy in Odisha and what documents are needed.'
    },
    {
      label: currentLang === 'or' ? '🌶️ ଲଙ୍କା କୁଞ୍ଚିଆ ରୋଗର ତୁରନ୍ତ ଉପଚାର କ\'ଣ?' : '🌶️ Immediate treatment for Chilli Leaf Curl virus?',
      query: 'What is the best chemical and organic remedy for chilli leaf curl virus and whitefly control?'
    },
    {
      label: currentLang === 'or' ? '💰 କାଳିଆ ଯୋଜନା ଟଙ୍କା କିପରି ଚେକ୍ କରିବି?' : '💰 How to check KALIA scheme DBT status?',
      query: 'How to check KALIA scheme installment status and helpline number in Odisha?'
    },
    {
      label: currentLang === 'or' ? '🐛 ଧାନରେ କାଣ୍ଡ ବିନ୍ଧା ପୋକ ନିୟନ୍ତ୍ରଣ କିପରି?' : '🐛 How to control Yellow Stem Borer in rice?',
      query: 'How to control stem borer dead hearts in rice field?'
    }
  ];

  const handleSend = async (customQuery) => {
    const textToSend = (customQuery || inputText).trim();
    if (!textToSend || isLoading) return;

    const userMsg = {
      id: Date.now(),
      sender: 'user',
      text: textToSend,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText("");
    setIsLoading(true);

    try {
      const reply = await callGeminiApi(
        textToSend,
        "You are Krushi Mitra, a dedicated agronomist assistant for Odisha farmers. Provide accurate, practical farming advice with step-by-step points.",
        currentLang
      );

      const botMsg = {
        id: Date.now() + 1,
        sender: 'bot',
        text: reply,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages((prev) => [...prev, botMsg]);

      // Automatically speak reply
      handleSpeakMessage(botMsg.id, reply);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleVoiceInput = () => {
    if (isListening) {
      if (speechRecognizerRef.current) speechRecognizerRef.current.stop();
      setIsListening(false);
      return;
    }

    const recognizer = createSpeechRecognizer(
      currentLang,
      (transcript) => {
        setInputText(transcript);
      },
      () => {
        setIsListening(false);
      },
      (err) => {
        console.warn(err);
        setIsListening(false);
      }
    );

    if (recognizer) {
      speechRecognizerRef.current = recognizer;
      setIsListening(true);
      recognizer.start();
    } else {
      alert("Microphone voice input is not supported in this browser.");
    }
  };

  const handleSpeakMessage = (id, text) => {
    if (activeSpeakingId === id) {
      stopSpeaking();
      setActiveSpeakingId(null);
      return;
    }

    stopSpeaking();
    setActiveSpeakingId(id);
    speakText(
      text,
      currentLang,
      () => setActiveSpeakingId(id),
      () => setActiveSpeakingId(null),
      () => setActiveSpeakingId(null)
    );
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Header Banner */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-100 dark:bg-teal-950/60 text-teal-800 dark:text-teal-300 text-xs font-bold mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Powered Agronomist</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <Bot className="w-7 h-7 text-teal-600 dark:text-teal-400" />
            <span>{t.chatTitle}</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            {t.chatSubtitle}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setMessages([initialGreeting]);
              stopSpeaking();
              setActiveSpeakingId(null);
            }}
            className="px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-xs font-bold text-slate-600 dark:text-slate-300 transition-colors"
          >
            Clear Chat
          </button>
        </div>
      </div>

      {/* Main Chat Container */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-md flex flex-col h-[550px] overflow-hidden">
        
        {/* Chat Messages Log */}
        <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4">
          {messages.map((msg) => {
            const isBot = msg.sender === 'bot';
            return (
              <div
                key={msg.id}
                className={`flex gap-3 max-w-2xl ${isBot ? 'mr-auto' : 'ml-auto flex-row-reverse'}`}
              >
                {/* Avatar */}
                <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 text-white shadow-sm ${
                  isBot ? 'bg-teal-600' : 'bg-farm-600'
                }`}>
                  {isBot ? <Bot className="w-4 h-4" /> : <User className="w-4 h-4" />}
                </div>

                {/* Message Bubble */}
                <div className={`rounded-2xl p-4 text-xs sm:text-sm leading-relaxed ${
                  isBot
                    ? 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-100 border border-slate-200/80 dark:border-slate-700'
                    : 'bg-farm-600 text-white font-medium'
                }`}>
                  <div className="whitespace-pre-line font-sans">
                    {msg.text}
                  </div>

                  <div className={`mt-2 pt-2 border-t flex items-center justify-between text-[10px] ${
                    isBot ? 'border-slate-200 dark:border-slate-700 text-slate-400' : 'border-farm-500/50 text-farm-100'
                  }`}>
                    <span>{msg.time}</span>
                    {isBot && (
                      <button
                        onClick={() => handleSpeakMessage(msg.id, msg.text)}
                        className={`inline-flex items-center gap-1 font-bold ${
                          activeSpeakingId === msg.id ? 'text-red-500 animate-pulse' : 'text-teal-600 dark:text-teal-400 hover:underline'
                        }`}
                      >
                        {activeSpeakingId === msg.id ? <VolumeX className="w-3 h-3" /> : <Volume2 className="w-3 h-3" />}
                        <span>{activeSpeakingId === msg.id ? 'Stop' : 'Listen'}</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}

          {isLoading && (
            <div className="flex gap-3 max-w-xl mr-auto">
              <div className="w-8 h-8 rounded-xl bg-teal-600 flex items-center justify-center text-white shrink-0">
                <Bot className="w-4 h-4" />
              </div>
              <div className="bg-slate-100 dark:bg-slate-800 rounded-2xl p-4 text-xs text-slate-600 dark:text-slate-300 flex items-center gap-2">
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-teal-600" />
                <span>Krushi Mitra is thinking...</span>
              </div>
            </div>
          )}

          <div ref={chatBottomRef} />
        </div>

        {/* Quick Question Prompts */}
        <div className="p-3 bg-slate-50 dark:bg-slate-800/60 border-t border-slate-100 dark:border-slate-800 flex gap-2 overflow-x-auto scrollbar-none">
          {quickQuestions.map((q, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(q.query)}
              className="shrink-0 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 hover:bg-farm-50 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 transition-colors"
            >
              {q.label}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-3 sm:p-4 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex items-center gap-2">
          
          {/* Voice Microphone */}
          <button
            onClick={handleVoiceInput}
            className={`p-3 rounded-2xl transition-all ${
              isListening
                ? 'bg-red-500 text-white animate-bounce'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
            }`}
            title="Speak Question"
          >
            {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          <input
            type="text"
            placeholder={t.chatPlaceholder}
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleSend();
            }}
            className="flex-1 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-2xl px-4 py-3 text-sm text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-teal-500 focus:outline-none"
          />

          <button
            onClick={() => handleSend()}
            disabled={!inputText.trim() || isLoading}
            className="p-3 rounded-2xl bg-teal-600 hover:bg-teal-700 text-white transition-colors disabled:opacity-40"
            title="Send"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>

      </div>

    </div>
  );
}
