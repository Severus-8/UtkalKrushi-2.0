import React, { useState } from 'react';
import { 
  Sprout, 
  CloudSun, 
  Stethoscope, 
  Calculator, 
  TrendingUp, 
  Landmark, 
  Bot, 
  BookOpen, 
  ReceiptText, 
  ExternalLink, 
  Moon, 
  Sun, 
  Globe, 
  PhoneCall, 
  Menu, 
  X,
  ShieldCheck
} from 'lucide-react';
import { translations } from '../data/translations';

export default function Header({ 
  currentLang, 
  setCurrentLang, 
  activeTab, 
  setActiveTab, 
  darkMode, 
  setDarkMode,
  onOpenHelpline
}) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const t = translations[currentLang] || translations.en;

  const navItems = [
    { id: 'dashboard', label: t.navDashboard, icon: Sprout },
    { id: 'weather', label: t.navWeather, icon: CloudSun },
    { id: 'cropdoctor', label: t.navCropDoctor, icon: Stethoscope },
    { id: 'fertilizer', label: t.navFertilizer, icon: Calculator },
    { id: 'mandi', label: t.navMandi, icon: TrendingUp },
    { id: 'schemes', label: t.navSchemes, icon: Landmark },
    { id: 'chatbot', label: t.navChatbot, icon: Bot },
    { id: 'cropguide', label: t.navCropGuide, icon: BookOpen },
    { id: 'ledger', label: t.navLedger, icon: ReceiptText },
    { id: 'portals', label: t.navPortals, icon: ExternalLink },
  ];

  return (
    <header className="sticky top-0 z-50 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-farm-200 dark:border-slate-800 shadow-sm transition-colors duration-200">
      {/* Top Banner - Emergency & Helplines */}
      <div className="bg-gradient-to-r from-farm-700 via-farm-800 to-farm-900 text-white text-xs sm:text-sm py-1.5 px-3 sm:px-6">
        <div className="max-w-7xl mx-auto flex flex-wrap justify-between items-center gap-2">
          <div className="flex items-center gap-2 font-medium truncate">
            <span className="inline-flex items-center justify-center p-0.5 px-1.5 rounded bg-harvest-500 text-slate-900 text-[10px] font-bold uppercase tracking-wider animate-pulse">
              Free Helpline
            </span>
            <span className="hidden sm:inline">🌾</span>
            <span className="truncate">{t.emergencyHelp}</span>
          </div>
          <div className="flex items-center gap-3">
            <a 
              href="tel:1551" 
              className="inline-flex items-center gap-1 text-harvest-300 hover:text-white font-semibold underline text-xs"
            >
              <PhoneCall className="w-3 h-3" /> Call 1551
            </a>
            <span className="text-farm-400">|</span>
            <a 
              href="tel:18001801551" 
              className="hidden md:inline-flex items-center gap-1 text-harvest-300 hover:text-white font-semibold underline text-xs"
            >
              Odisha Krushi 1800-180-1551
            </a>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2.5">
        <div className="flex items-center justify-between gap-4">
          
          {/* Logo & Branding */}
          <button 
            onClick={() => { setActiveTab('dashboard'); setMobileMenuOpen(false); }}
            className="flex items-center gap-3 group text-left focus:outline-none"
          >
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-gradient-to-tr from-farm-600 to-farm-400 flex items-center justify-center text-white shadow-md shadow-farm-500/20 group-hover:scale-105 transition-transform duration-200">
              <Sprout className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xl sm:text-2xl font-extrabold tracking-tight text-farm-800 dark:text-farm-400 font-sans">
                  {t.appName}
                </span>
                <span className="hidden sm:inline-block px-1.5 py-0.5 rounded text-[10px] font-bold bg-farm-100 dark:bg-farm-900/60 text-farm-700 dark:text-farm-300 border border-farm-200 dark:border-farm-800">
                  Odisha
                </span>
              </div>
              <p className="text-[11px] sm:text-xs text-slate-500 dark:text-slate-400 font-medium line-clamp-1">
                {t.appTagline}
              </p>
            </div>
          </button>

          {/* Desktop Navigation Links */}
          <nav className="hidden xl:flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-150 ${
                    isActive 
                      ? 'bg-farm-600 text-white shadow-sm shadow-farm-600/30 font-bold' 
                      : 'text-slate-600 dark:text-slate-300 hover:text-farm-700 dark:hover:text-farm-400 hover:bg-farm-50 dark:hover:bg-slate-800'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-white' : 'text-slate-400 group-hover:text-farm-600'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Right Controls: Language, Theme, Call Button & Mobile Menu Toggle */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Language Selector Dropdown */}
            <div className="relative flex items-center bg-farm-50 dark:bg-slate-800 border border-farm-200 dark:border-slate-700 rounded-xl px-2.5 py-1.5">
              <Globe className="w-4 h-4 text-farm-600 dark:text-farm-400 mr-1.5 shrink-0" />
              <select
                value={currentLang}
                onChange={(e) => setCurrentLang(e.target.value)}
                aria-label="Select Language"
                className="bg-transparent text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-200 focus:outline-none cursor-pointer pr-1"
              >
                <option value="en" className="dark:bg-slate-800">English</option>
                <option value="or" className="dark:bg-slate-800">ଓଡ଼ିଆ (Odia)</option>
                <option value="hi" className="dark:bg-slate-800">हिंदी (Hindi)</option>
              </select>
            </div>

            {/* Dark Mode Toggle */}
            <button
              onClick={() => setDarkMode(!darkMode)}
              className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors focus:outline-none"
              title={darkMode ? t.lightMode : t.darkMode}
              aria-label="Toggle Theme"
            >
              {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-600" />}
            </button>

            {/* Helpline Quick Modal Trigger */}
            <button
              onClick={onOpenHelpline}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-900 rounded-xl font-bold text-xs shadow-sm transition-colors"
            >
              <PhoneCall className="w-3.5 h-3.5" />
              <span>{t.helpline}</span>
            </button>

            {/* Mobile Menu Hamburger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="xl:hidden p-2 rounded-xl bg-farm-50 dark:bg-slate-800 text-farm-700 dark:text-farm-300 border border-farm-200 dark:border-slate-700 focus:outline-none"
              aria-label="Toggle Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-white dark:bg-slate-900 border-b border-farm-200 dark:border-slate-800 px-4 pt-2 pb-4 animate-in slide-in-from-top duration-200 shadow-xl">
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 py-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`flex items-center gap-2.5 p-3 rounded-xl text-left text-xs font-semibold transition-all ${
                    isActive 
                      ? 'bg-farm-600 text-white font-bold shadow-md shadow-farm-600/20' 
                      : 'bg-slate-50 dark:bg-slate-800/80 text-slate-700 dark:text-slate-200 hover:bg-farm-50 dark:hover:bg-slate-800'
                  }`}
                >
                  <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-farm-600 dark:text-farm-400'}`} />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </div>

          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <button
              onClick={() => {
                onOpenHelpline();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-center gap-2 py-2.5 bg-amber-500 hover:bg-amber-600 text-slate-900 font-bold rounded-xl text-xs"
            >
              <PhoneCall className="w-4 h-4" />
              <span>{t.helpline} (1551 / 1800-180-1551)</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
