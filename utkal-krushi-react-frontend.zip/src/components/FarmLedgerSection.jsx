import React, { useState } from 'react';
import { 
  ReceiptText, 
  Coins, 
  TrendingUp, 
  TrendingDown, 
  Sparkles, 
  Printer, 
  RotateCcw,
  PlusCircle,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { translations } from '../data/translations';

export default function FarmLedgerSection({ currentLang }) {
  const t = translations[currentLang] || translations.en;

  const [cropName, setCropName] = useState("Swarna Paddy (ଧାନ)");
  const [landSize, setLandSize] = useState(2); // Acres
  const [seedCost, setSeedCost] = useState(1600);
  const [fertilizerCost, setFertilizerCost] = useState(4800);
  const [laborCost, setLaborCost] = useState(7000);
  const [machineryCost, setMachineryCost] = useState(3500);
  const [irrigationCost, setIrrigationCost] = useState(1200);
  const [otherCost, setOtherCost] = useState(800);
  const [expectedYield, setExpectedYield] = useState(42); // Quintals total
  const [sellingPrice, setSellingPrice] = useState(2300); // ₹ per Quintal

  const acres = parseFloat(landSize) || 1;
  const totalExpenses = (
    (parseFloat(seedCost) || 0) +
    (parseFloat(fertilizerCost) || 0) +
    (parseFloat(laborCost) || 0) +
    (parseFloat(machineryCost) || 0) +
    (parseFloat(irrigationCost) || 0) +
    (parseFloat(otherCost) || 0)
  );

  const totalRevenue = (parseFloat(expectedYield) || 0) * (parseFloat(sellingPrice) || 0);
  const netProfit = totalRevenue - totalExpenses;
  const costPerAcre = totalExpenses / acres;
  const profitPerAcre = netProfit / acres;
  const profitMargin = totalRevenue > 0 ? ((netProfit / totalRevenue) * 100).toFixed(1) : 0;

  const resetValues = () => {
    setCropName("Swarna Paddy (ଧାନ)");
    setLandSize(1);
    setSeedCost(800);
    setFertilizerCost(2400);
    setLaborCost(3500);
    setMachineryCost(1800);
    setIrrigationCost(600);
    setOtherCost(400);
    setExpectedYield(21);
    setSellingPrice(2300);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      
      {/* Header Banner */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-900 dark:text-amber-300 text-xs font-bold mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Smart Farm Accounting & Profit Tracker</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
              <ReceiptText className="w-7 h-7 text-amber-600 dark:text-amber-400" />
              <span>{t.ledgerTitle}</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
              {t.ledgerSubtitle}
            </p>
          </div>

          <button
            onClick={resetValues}
            className="self-start md:self-auto inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Khata</span>
          </button>
        </div>
      </div>

      {/* Main Ledger Form & Live Profit Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Inputs */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider pb-2 border-b border-slate-100 dark:border-slate-800">
            1. Crop & Field Details
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t.cropName}
              </label>
              <input
                type="text"
                value={cropName}
                onChange={(e) => setCropName(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2 text-sm font-semibold text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t.landSize}
              </label>
              <input
                type="number"
                step="0.5"
                min="0.1"
                value={landSize}
                onChange={(e) => setLandSize(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2 text-sm font-semibold text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
              />
            </div>
          </div>

          <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider pt-3 pb-2 border-b border-slate-100 dark:border-slate-800">
            2. Cultivation Expenses (ଖର୍ଚ୍ଚ ତାଲିକା)
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t.seedCost}
              </label>
              <input
                type="number"
                value={seedCost}
                onChange={(e) => setSeedCost(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t.fertilizerCost}
              </label>
              <input
                type="number"
                value={fertilizerCost}
                onChange={(e) => setFertilizerCost(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t.laborCost}
              </label>
              <input
                type="number"
                value={laborCost}
                onChange={(e) => setLaborCost(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t.machineryCost}
              </label>
              <input
                type="number"
                value={machineryCost}
                onChange={(e) => setMachineryCost(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t.irrigationCost}
              </label>
              <input
                type="number"
                value={irrigationCost}
                onChange={(e) => setIrrigationCost(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t.otherCost}
              </label>
              <input
                type="number"
                value={otherCost}
                onChange={(e) => setOtherCost(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
              />
            </div>
          </div>

          <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider pt-3 pb-2 border-b border-slate-100 dark:border-slate-800">
            3. Harvest & Market Sale Price
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t.harvestYield}
              </label>
              <input
                type="number"
                value={expectedYield}
                onChange={(e) => setExpectedYield(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2 text-sm font-semibold text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t.sellingPrice}
              </label>
              <input
                type="number"
                value={sellingPrice}
                onChange={(e) => setSellingPrice(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2 text-sm font-semibold text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Right Financial Balance Card */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border-2 border-farm-500 dark:border-farm-600 shadow-xl space-y-6">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h4 className="font-black text-base text-slate-900 dark:text-white">
                Farm Profit & Loss Summary
              </h4>
              <button
                onClick={() => window.print()}
                className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200"
                title="Print Khata"
              >
                <Printer className="w-4 h-4" />
              </button>
            </div>

            {/* Net Profit Hero Card */}
            <div className={`p-5 rounded-2xl border ${
              netProfit >= 0 
                ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-100' 
                : 'bg-red-50 dark:bg-red-950/40 border-red-200 dark:border-red-800 text-red-900 dark:text-red-100'
            }`}>
              <div className="flex items-center justify-between text-xs font-bold">
                <span>{t.netProfit} (ଶୁଦ୍ଧ ଲାଭ)</span>
                {netProfit >= 0 ? <TrendingUp className="w-4 h-4 text-emerald-600" /> : <TrendingDown className="w-4 h-4 text-red-600" />}
              </div>
              <div className="text-3xl sm:text-4xl font-black mt-1">
                ₹{netProfit.toLocaleString('en-IN')}
              </div>
              <div className="text-xs mt-1 opacity-90 font-medium">
                {profitMargin}% Profit Margin ({acres} Acres)
              </div>
            </div>

            {/* Income & Expense Breakdown */}
            <div className="space-y-3 text-xs sm:text-sm">
              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                <span className="text-slate-600 dark:text-slate-400">{t.totalRevenue}</span>
                <span className="font-bold text-slate-900 dark:text-white">₹{totalRevenue.toLocaleString('en-IN')}</span>
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                <span className="text-slate-600 dark:text-slate-400">{t.totalExpenses}</span>
                <span className="font-bold text-red-600 dark:text-red-400">- ₹{totalExpenses.toLocaleString('en-IN')}</span>
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                <span className="text-slate-600 dark:text-slate-400">{t.costPerAcre}</span>
                <span className="font-bold text-slate-900 dark:text-white">₹{costPerAcre.toFixed(0).toLocaleString('en-IN')} / Acre</span>
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                <span className="text-slate-600 dark:text-slate-400">Net Profit Per Acre</span>
                <span className="font-bold text-emerald-600 dark:text-emerald-400">₹{profitPerAcre.toFixed(0).toLocaleString('en-IN')} / Acre</span>
              </div>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
}
