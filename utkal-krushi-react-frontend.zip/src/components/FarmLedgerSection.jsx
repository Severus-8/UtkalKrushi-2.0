import React, { useState, useEffect } from 'react';
import { 
  ReceiptText, 
  Coins, 
  TrendingUp, 
  TrendingDown, 
  Sparkles, 
  Printer, 
  RotateCcw,
  PlusCircle,
  CheckCircle2,
  AlertCircle,
  Save,
  Trash2,
  History
} from 'lucide-react';
import { translations } from '../data/translations';
import { API_CONFIG, apiFetch } from '../config/api';

const LEDGER_STORAGE_KEY = 'utkalKrushiLedgerEntries';

const readLocalEntries = () => {
  try {
    const rows = JSON.parse(localStorage.getItem(LEDGER_STORAGE_KEY) || '[]');
    return Array.isArray(rows) ? rows : [];
  } catch {
    return [];
  }
};

const writeLocalEntries = (rows) => {
  try {
    localStorage.setItem(LEDGER_STORAGE_KEY, JSON.stringify(rows.slice(0, 50)));
  } catch { /* storage full / unavailable */ }
};

export default function FarmLedgerSection({ currentLang }) {
  const t = translations[currentLang] || translations.en;

  const [cropName, setCropName] = useState("Swarna Paddy (ଧାନ)");
  const [landSize, setLandSize] = useState(2); // Acres
  const [seedCost, setSeedCost] = useState(1600);
  const [fertilizerCost, setFertilizerCost] = useState(4800);
  const [laborCost, setLaborCost] = useState(7000);
  const [machineryCost, setMachineryCost] = useState(3500);
  const [irrigationCost, setIrrigationCost] = useState(1200);
  const [otherCost, setOtherCost] = useState(800);
  const [expectedYield, setExpectedYield] = useState(42); // Quintals total
  const [sellingPrice, setSellingPrice] = useState(2300); // ₹ per Quintal

  const acres = parseFloat(landSize) || 1;
  const totalExpenses = (
    (parseFloat(seedCost) || 0) +
    (parseFloat(fertilizerCost) || 0) +
    (parseFloat(laborCost) || 0) +
    (parseFloat(machineryCost) || 0) +
    (parseFloat(irrigationCost) || 0) +
    (parseFloat(otherCost) || 0)
  );

  const totalRevenue = (parseFloat(expectedYield) || 0) * (parseFloat(sellingPrice) || 0);
  const netProfit = totalRevenue - totalExpenses;
  const costPerAcre = totalExpenses / acres;
  const profitPerAcre = netProfit / acres;
  const profitMargin = totalRevenue > 0 ? ((netProfit / totalRevenue) * 100).toFixed(1) : 0;

  const resetValues = () => {
    setCropName("Swarna Paddy (ଧାନ)");
    setLandSize(1);
    setSeedCost(800);
    setFertilizerCost(2400);
    setLaborCost(3500);
    setMachineryCost(1800);
    setIrrigationCost(600);
    setOtherCost(400);
    setExpectedYield(21);
    setSellingPrice(2300);
  };

  // ---- Khata persistence: backend first, on-device localStorage always ----
  const [history, setHistory] = useState([]);
  const [storageMode, setStorageMode] = useState('local'); // 'backend' | 'local'
  const [saving, setSaving] = useState(false);
  const [saveNotice, setSaveNotice] = useState(null);

  useEffect(() => {
    // Instantly show anything saved on this device...
    setHistory(readLocalEntries());
    // ...then upgrade to the server-side khata when reachable.
    apiFetch(API_CONFIG.ENDPOINTS.LEDGER)
      .then((data) => {
        if (Array.isArray(data)) {
          const rows = data.map((e) => ({ ...e, source: 'backend' }));
          setHistory(rows);
          setStorageMode('backend');
          writeLocalEntries(rows);
        }
      })
      .catch((err) => console.warn('Ledger backend unavailable, using on-device storage:', err));
  }, []);

  const handleSaveEntry = async () => {
    if (saving) return;
    setSaving(true);
    setSaveNotice(null);

    const entry = {
      crop: (cropName || 'Untitled Crop').trim(),
      landArea: acres,
      expenses: {
        seed: parseFloat(seedCost) || 0,
        fertilizer: parseFloat(fertilizerCost) || 0,
        labor: parseFloat(laborCost) || 0,
        machinery: parseFloat(machineryCost) || 0,
        irrigation: parseFloat(irrigationCost) || 0,
        other: parseFloat(otherCost) || 0,
      },
      expectedYield: parseFloat(expectedYield) || 0,
      sellingPrice: parseFloat(sellingPrice) || 0,
    };

    let saved;
    try {
      const data = await apiFetch(API_CONFIG.ENDPOINTS.LEDGER_SAVE, { method: 'POST', body: entry });
      saved = { ...data, source: 'backend' };
      setSaveNotice({ ok: true, text: 'Saved to your server khata ✓' });
    } catch (err) {
      saved = {
        id: `local-${Date.now()}`,
        ...entry,
        totalExpenses: totalExpenses,
        netProfit: netProfit,
        created_at: new Date().toISOString(),
        source: 'local',
      };
      setSaveNotice({ ok: true, text: 'Saved on this device (backend offline)' });
    }

    const rows = [saved, ...history].slice(0, 50);
    setHistory(rows);
    writeLocalEntries(rows);
    setSaving(false);
    setTimeout(() => setSaveNotice(null), 3500);
  };

  const handleDeleteEntry = async (row) => {
    const rows = history.filter((r) => r.id !== row.id);
    setHistory(rows);
    writeLocalEntries(rows);
    if (row.source === 'backend' && !String(row.id).startsWith('local-')) {
      try {
        await apiFetch(`${API_CONFIG.ENDPOINTS.LEDGER}?id=${row.id}`, { method: 'DELETE' });
      } catch { /* keep local removal even if server delete fails */ }
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      
      {/* Header Banner */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-900 dark:text-amber-300 text-xs font-bold mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Smart Farm Accounting & Profit Tracker</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
              <ReceiptText className="w-7 h-7 text-amber-600 dark:text-amber-400" />
              <span>{t.ledgerTitle}</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
              {t.ledgerSubtitle}
            </p>
          </div>

          <div className="self-start md:self-auto flex flex-col items-stretch gap-2">
            {saveNotice && (
              <span className={`text-[11px] font-bold px-2 py-1 rounded-lg text-center ${
                saveNotice.ok
                  ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300'
                  : 'bg-red-50 dark:bg-red-950/60 text-red-700 dark:text-red-300'
              }`}>
                {saveNotice.text}
              </span>
            )}
            <div className="flex gap-2">
              <button
                onClick={handleSaveEntry}
                disabled={saving}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-farm-600 hover:bg-farm-700 disabled:opacity-50 text-white text-xs font-bold shadow-sm transition-colors"
              >
                <Save className="w-3.5 h-3.5" />
                <span>{saving ? 'Saving…' : 'Save Khata'}</span>
              </button>
              <button
                onClick={resetValues}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Khata</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Ledger Form & Live Profit Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Inputs */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider pb-2 border-b border-slate-100 dark:border-slate-800">
            1. Crop & Field Details
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t.cropName}
              </label>
              <input
                type="text"
                value={cropName}
                onChange={(e) => setCropName(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2 text-sm font-semibold text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t.landSize}
              </label>
              <input
                type="number"
                step="0.5"
                min="0.1"
                value={landSize}
                onChange={(e) => setLandSize(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2 text-sm font-semibold text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
              />
            </div>
          </div>

          <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider pt-3 pb-2 border-b border-slate-100 dark:border-slate-800">
            2. Cultivation Expenses (ଖର୍ଚ୍ଚ ତାଲିକା)
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t.seedCost}
              </label>
              <input
                type="number"
                value={seedCost}
                onChange={(e) => setSeedCost(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t.fertilizerCost}
              </label>
              <input
                type="number"
                value={fertilizerCost}
                onChange={(e) => setFertilizerCost(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t.laborCost}
              </label>
              <input
                type="number"
                value={laborCost}
                onChange={(e) => setLaborCost(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t.machineryCost}
              </label>
              <input
                type="number"
                value={machineryCost}
                onChange={(e) => setMachineryCost(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t.irrigationCost}
              </label>
              <input
                type="number"
                value={irrigationCost}
                onChange={(e) => setIrrigationCost(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t.otherCost}
              </label>
              <input
                type="number"
                value={otherCost}
                onChange={(e) => setOtherCost(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
              />
            </div>
          </div>

          <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider pt-3 pb-2 border-b border-slate-100 dark:border-slate-800">
            3. Harvest & Market Sale Price
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t.harvestYield}
              </label>
              <input
                type="number"
                value={expectedYield}
                onChange={(e) => setExpectedYield(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2 text-sm font-semibold text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t.sellingPrice}
              </label>
              <input
                type="number"
                value={sellingPrice}
                onChange={(e) => setSellingPrice(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2 text-sm font-semibold text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Right Financial Balance Card */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border-2 border-farm-500 dark:border-farm-600 shadow-xl space-y-6">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h4 className="font-black text-base text-slate-900 dark:text-white">
                Farm Profit & Loss Summary
              </h4>
              <button
                onClick={() => window.print()}
                className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200"
                title="Print Khata"
              >
                <Printer className="w-4 h-4" />
              </button>
            </div>

            {/* Net Profit Hero Card */}
            <div className={`p-5 rounded-2xl border ${
              netProfit >= 0 
                ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-100' 
                : 'bg-red-50 dark:bg-red-950/40 border-red-200 dark:border-red-800 text-red-900 dark:text-red-100'
            }`}>
              <div className="flex items-center justify-between text-xs font-bold">
                <span>{t.netProfit} (ଶୁଦ୍ଧ ଲାଭ)</span>
                {netProfit >= 0 ? <TrendingUp className="w-4 h-4 text-emerald-600" /> : <TrendingDown className="w-4 h-4 text-red-600" />}
              </div>
              <div className="text-3xl sm:text-4xl font-black mt-1">
                ₹{netProfit.toLocaleString('en-IN')}
              </div>
              <div className="text-xs mt-1 opacity-90 font-medium">
                {profitMargin}% Profit Margin ({acres} Acres)
              </div>
            </div>

            {/* Income & Expense Breakdown */}
            <div className="space-y-3 text-xs sm:text-sm">
              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                <span className="text-slate-600 dark:text-slate-400">{t.totalRevenue}</span>
                <span className="font-bold text-slate-900 dark:text-white">₹{totalRevenue.toLocaleString('en-IN')}</span>
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                <span className="text-slate-600 dark:text-slate-400">{t.totalExpenses}</span>
                <span className="font-bold text-red-600 dark:text-red-400">- ₹{totalExpenses.toLocaleString('en-IN')}</span>
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                <span className="text-slate-600 dark:text-slate-400">{t.costPerAcre}</span>
                <span className="font-bold text-slate-900 dark:text-white">₹{costPerAcre.toFixed(0).toLocaleString('en-IN')} / Acre</span>
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                <span className="text-slate-600 dark:text-slate-400">Net Profit Per Acre</span>
                <span className="font-bold text-emerald-600 dark:text-emerald-400">₹{profitPerAcre.toFixed(0).toLocaleString('en-IN')} / Acre</span>
              </div>
            </div>

          </div>
        </div>

      </div>

      {/* Saved Khata History */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
            <History className="w-4 h-4 text-amber-600 dark:text-amber-400" />
            <span>Saved Khata Entries ({history.length})</span>
          </h3>
          <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-bold border ${
            storageMode === 'backend'
              ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700'
          }`}>
            {storageMode === 'backend'
              ? <><CheckCircle2 className="w-3 h-3" /> Server + Device Storage</>
              : <><AlertCircle className="w-3 h-3" /> On-Device Storage (backend offline)</>}
          </span>
        </div>

        {history.length === 0 ? (
          <div className="py-10 text-center">
            <ReceiptText className="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto mb-3" />
            <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto">
              No saved entries yet. Fill the khata above and press <strong>Save Khata</strong> — entries
              are stored on the server when available, and always on this device as backup.
            </p>
          </div>
        ) : (
          <div className="pt-4 space-y-2.5">
            {history.map((row) => (
              <div
                key={row.id}
                className="flex flex-wrap items-center gap-3 p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700"
              >
                <div className="flex-1 min-w-[180px]">
                  <div className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                    <Coins className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                    <span className="truncate">{row.crop}</span>
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                    {Number(row.landArea).toFixed ? Number(row.landArea).toFixed(2) : row.landArea} acres •{' '}
                    {row.created_at ? new Date(row.created_at).toLocaleDateString([], { day: 'numeric', month: 'short', year: 'numeric' }) : '—'}
                    {row.source === 'backend' ? ' • 🖥️ server' : ' • 📱 device'}
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-[10px] uppercase font-bold text-slate-400">Expenses</div>
                  <div className="text-xs font-bold text-red-600 dark:text-red-400">
                    ₹{(parseFloat(row.totalExpenses) || 0).toLocaleString('en-IN')}
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-[10px] uppercase font-bold text-slate-400">Net Profit</div>
                  <div className={`text-xs font-black ${(parseFloat(row.netProfit) || 0) >= 0
                    ? 'text-emerald-600 dark:text-emerald-400'
                    : 'text-red-600 dark:text-red-400'}`}
                  >
                    ₹{(parseFloat(row.netProfit) || 0).toLocaleString('en-IN')}
                  </div>
                </div>

                <button
                  onClick={() => handleDeleteEntry(row)}
                  className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-400 hover:text-red-600 hover:border-red-300 transition-colors"
                  title="Delete entry"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
}
