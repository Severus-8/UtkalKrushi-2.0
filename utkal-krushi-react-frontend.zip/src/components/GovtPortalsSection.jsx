import React, { useState } from 'react';
import { 
  ExternalLink, 
  Search, 
  Landmark, 
  ShieldCheck, 
  Sparkles,
  Globe
} from 'lucide-react';
import { translations } from '../data/translations';
import { govtPortals } from '../data/govtPortals';

export default function GovtPortalsSection({ currentLang }) {
  const t = translations[currentLang] || translations.en;
  const [search, setSearch] = useState("");

  const filteredPortals = govtPortals.filter(p => 
    p.name.toLowerCase().includes(search.toLowerCase()) ||
    p.nameOr.toLowerCase().includes(search.toLowerCase()) ||
    p.category.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      
      {/* Header Banner */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-farm-100 dark:bg-farm-950/60 text-farm-800 dark:text-farm-300 text-xs font-bold mb-2">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Verified Government Links & Services</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Landmark className="w-7 h-7 text-farm-600" />
              <span>{t.portalsTitle}</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
              {t.portalsSubtitle}
            </p>
          </div>

          <div className="w-full sm:w-72">
            <input
              type="text"
              placeholder="Search DAFE, NRRI, OUAT, eNAM..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-sm font-semibold text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
            />
          </div>
        </div>
      </div>

      {/* Portals Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredPortals.map((portal, idx) => (
          <div
            key={idx}
            className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-all flex flex-col justify-between group"
          >
            <div>
              <div className="flex items-start justify-between gap-2 mb-3">
                <span className="text-3xl">{portal.icon}</span>
                <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-farm-50 dark:bg-farm-950/60 text-farm-700 dark:text-farm-300 border border-farm-200 dark:border-farm-800">
                  {portal.badge}
                </span>
              </div>

              <h3 className="font-bold text-base text-slate-900 dark:text-white group-hover:text-farm-600 dark:group-hover:text-farm-400 transition-colors">
                {currentLang === 'or' ? portal.nameOr : portal.name}
              </h3>
              
              <span className="text-xs font-semibold text-slate-400 block mt-0.5">
                {portal.category}
              </span>

              <p className="mt-3 text-xs text-slate-600 dark:text-slate-300 line-clamp-3 leading-relaxed">
                {portal.description}
              </p>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800">
              <a
                href={portal.url}
                target="_blank"
                rel="noreferrer"
                className="w-full inline-flex items-center justify-center gap-2 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 hover:bg-farm-600 hover:text-white dark:hover:bg-farm-600 text-slate-700 dark:text-slate-200 text-xs font-bold transition-all border border-slate-200 dark:border-slate-700 hover:border-farm-600"
              >
                <span>{t.visitPortal}</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
}
