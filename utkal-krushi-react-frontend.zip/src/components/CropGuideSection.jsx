import React, { useState } from 'react';
import { 
  BookOpen, 
  Calendar, 
  Clock, 
  Droplets, 
  Layers, 
  Sparkles, 
  ChevronRight, 
  CheckCircle2, 
  Bug,
  Search
} from 'lucide-react';
import { translations } from '../data/translations';
import { odishaCropsData } from '../data/crops';

export default function CropGuideSection({ currentLang }) {
  const t = translations[currentLang] || translations.en;

  const [selectedCrop, setSelectedCrop] = useState(odishaCropsData[0]);
  const [searchQuery, setSearchQuery] = useState("");

  const filteredCrops = odishaCropsData.filter(c => 
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.nameOr.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      
      {/* Header Banner */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-farm-100 dark:bg-farm-950/60 text-farm-800 dark:text-farm-300 text-xs font-bold mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Odisha Agronomy Repository</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
              <BookOpen className="w-7 h-7 text-farm-600" />
              <span>{t.cropGuideTitle}</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
              {t.cropGuideSubtitle}
            </p>
          </div>

          <div className="w-full sm:w-64">
            <input
              type="text"
              placeholder="Search Paddy, Ragi, Moong..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-sm font-semibold text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
            />
          </div>
        </div>

        {/* Crop Selection Strip */}
        <div className="flex gap-2 overflow-x-auto pb-1 mt-6 pt-6 border-t border-slate-100 dark:border-slate-800 scrollbar-none">
          {filteredCrops.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedCrop(c)}
              className={`shrink-0 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                selectedCrop.id === c.id
                  ? 'bg-farm-600 text-white shadow-sm shadow-farm-600/30'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
              }`}
            >
              {currentLang === 'or' ? c.nameOr : c.name}
            </button>
          ))}
        </div>
      </div>

      {/* Selected Crop Deep-Dive Guide */}
      {selectedCrop && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200 dark:border-slate-800">
            <div>
              <span className="text-xs font-bold px-2.5 py-0.5 rounded-md bg-farm-100 dark:bg-farm-900/60 text-farm-800 dark:text-farm-300">
                {selectedCrop.category}
              </span>
              <h3 className="text-2xl font-black text-slate-900 dark:text-white mt-1">
                {currentLang === 'or' ? selectedCrop.nameOr : selectedCrop.name}
              </h3>
            </div>

            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600 dark:text-slate-300">
              <span className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-xl">
                <Clock className="w-3.5 h-3.5 text-farm-600" />
                <span>{selectedCrop.durationDays}</span>
              </span>
              <span className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-xl">
                <Calendar className="w-3.5 h-3.5 text-sky-600" />
                <span>{selectedCrop.seasons.join(" / ")}</span>
              </span>
            </div>
          </div>

          {/* Key Agronomy Metrics Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
              <span className="text-xs font-bold text-slate-500 dark:text-slate-400 block mb-1">
                {t.seedRate}
              </span>
              <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                {selectedCrop.seedRate}
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
              <span className="text-xs font-bold text-slate-500 dark:text-slate-400 block mb-1">
                {t.soilSuitability}
              </span>
              <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                {selectedCrop.idealSoil}
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
              <span className="text-xs font-bold text-slate-500 dark:text-slate-400 block mb-1">
                Water & Irrigation
              </span>
              <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                {selectedCrop.waterNeed}
              </p>
            </div>
          </div>

          {/* High Yield Varieties Recommended in Odisha */}
          <div>
            <h4 className="text-sm font-bold text-slate-900 dark:text-white mb-3">
              {t.recommendedVarieties}
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {selectedCrop.varieties.map((v, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-2xl bg-farm-50/50 dark:bg-farm-950/20 border border-farm-200/80 dark:border-farm-900/60"
                >
                  <div className="font-bold text-sm text-farm-900 dark:text-farm-200">
                    {v.name}
                  </div>
                  <div className="text-xs text-slate-600 dark:text-slate-300 mt-1">
                    Duration: {v.duration}
                  </div>
                  <div className="text-xs font-semibold text-farm-700 dark:text-farm-400 mt-0.5">
                    Yield: {v.yield}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-1">
                    {v.type}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Harvesting & Pest Management */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
            <div className="p-4 rounded-2xl bg-amber-50/60 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40">
              <h5 className="font-bold text-xs text-amber-900 dark:text-amber-200 flex items-center gap-1.5 mb-1.5">
                <Bug className="w-4 h-4 text-amber-600" />
                <span>Key Pests & Disease Risks</span>
              </h5>
              <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                {selectedCrop.keyPests}
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-emerald-50/60 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/40">
              <h5 className="font-bold text-xs text-emerald-900 dark:text-emerald-200 flex items-center gap-1.5 mb-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Harvesting & Maturity Indicators</span>
              </h5>
              <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                {selectedCrop.harvestingTips}
              </p>
            </div>
          </div>

        </div>
      )}

    </div>
  );
}
