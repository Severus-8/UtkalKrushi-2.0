import React, { useState, useRef } from 'react';
import { 
  Stethoscope, 
  UploadCloud, 
  Camera, 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  AlertCircle, 
  CheckCircle2, 
  Sparkles, 
  Leaf, 
  FlaskConical, 
  ShieldCheck, 
  RefreshCw,
  X,
  FileImage,
  AlertTriangle
} from 'lucide-react';
import { translations } from '../data/translations';
import { sampleCropDiseases } from '../data/cropDiseases';
import { diagnoseCropIssue } from '../utils/geminiApi';
import { speakText, stopSpeaking, createSpeechRecognizer } from '../utils/speechUtils';

export default function CropDoctorSection({ currentLang }) {
  const t = translations[currentLang] || translations.en;
  
  const [selectedImage, setSelectedImage] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [symptomsText, setSymptomsText] = useState("");
  const [isDiagnosing, setIsDiagnosing] = useState(false);
  const [diagnosisResult, setDiagnosisResult] = useState(null);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const fileInputRef = useRef(null);
  const speechRecognizerRef = useRef(null);

  const handleImageChange = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      const reader = new FileReader();
      reader.onload = () => {
        setImagePreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSelectSample = (disease) => {
    setImagePreview(disease.imageUrl);
    setSelectedImage(null);
    setSymptomsText(currentLang === 'or' ? disease.symptomsOr : currentLang === 'hi' ? disease.symptomsHi : disease.symptoms);
    
    // Auto populate structured diagnosis
    setDiagnosisResult({
      name: currentLang === 'or' ? disease.nameOr : currentLang === 'hi' ? disease.nameHi : disease.name,
      crop: disease.crop,
      severity: disease.severity,
      severityColor: disease.severityColor,
      symptoms: currentLang === 'or' ? disease.symptomsOr : currentLang === 'hi' ? disease.symptomsHi : disease.symptoms,
      organic: currentLang === 'or' ? disease.organicRemedyOr : disease.organicRemedy,
      chemical: currentLang === 'or' ? disease.chemicalTreatmentOr : disease.chemicalTreatment,
      preventive: currentLang === 'or' ? disease.preventiveTipsOr : disease.preventiveTips,
      rawText: null
    });
  };

  const handleVoiceInput = () => {
    if (isListening) {
      if (speechRecognizerRef.current) speechRecognizerRef.current.stop();
      setIsListening(false);
      return;
    }

    const recognizer = createSpeechRecognizer(
      currentLang,
      (transcript) => {
        setSymptomsText(transcript);
      },
      () => {
        setIsListening(false);
      },
      (err) => {
        console.warn('Speech rec error:', err);
        setIsListening(false);
      }
    );

    if (recognizer) {
      speechRecognizerRef.current = recognizer;
      setIsListening(true);
      recognizer.start();
    } else {
      alert("Speech recognition is not supported in this browser. Please type the symptoms.");
    }
  };

  const handleDiagnose = async () => {
    if (!selectedImage && !imagePreview && !symptomsText.trim()) {
      alert("Please upload a photo of the crop or enter/speak the symptoms.");
      return;
    }

    setIsDiagnosing(true);
    setDiagnosisResult(null);

    let base64Data = null;
    if (selectedImage) {
      try {
        base64Data = await new Promise((resolve) => {
          const reader = new FileReader();
          reader.onloadend = () => {
            const res = reader.result;
            resolve(res.split(',')[1]);
          };
          reader.readAsDataURL(selectedImage);
        });
      } catch (e) {
        console.error("Base64 conversion failed", e);
      }
    }

    try {
      const resultText = await diagnoseCropIssue(symptomsText, base64Data, currentLang);
      
      setDiagnosisResult({
        name: currentLang === 'or' ? 'AI ଫସଲ ରୋଗ ନିରୂପଣ ରିପୋର୍ଟ' : 'AI Crop Doctor Diagnosis',
        crop: 'Field Crop',
        severity: 'Moderate to High',
        severityColor: 'text-amber-800 bg-amber-50 border-amber-200',
        rawText: resultText,
        symptoms: symptomsText || "Analyzed from uploaded leaf image",
        organic: null,
        chemical: null,
        preventive: null
      });

      // Automatically speak prescription for farmer convenience
      handleVoiceReadout(resultText);
    } catch (err) {
      console.error(err);
      alert("Diagnosis failed. Please check internet connection.");
    } finally {
      setIsDiagnosing(false);
    }
  };

  const handleVoiceReadout = (customText) => {
    if (isSpeaking) {
      stopSpeaking();
      setIsSpeaking(false);
      return;
    }

    let textToSpeak = customText;
    if (!textToSpeak && diagnosisResult) {
      if (diagnosisResult.rawText) {
        textToSpeak = diagnosisResult.rawText;
      } else {
        textToSpeak = `${diagnosisResult.name}. ${diagnosisResult.organic}. ${diagnosisResult.chemical}`;
      }
    }

    if (!textToSpeak) return;

    setIsSpeaking(true);
    speakText(
      textToSpeak,
      currentLang,
      () => setIsSpeaking(true),
      () => setIsSpeaking(false),
      () => setIsSpeaking(false)
    );
  };

  const clearForm = () => {
    setSelectedImage(null);
    setImagePreview(null);
    setSymptomsText("");
    setDiagnosisResult(null);
    stopSpeaking();
    setIsSpeaking(false);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      
      {/* Top Banner */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 text-xs font-bold mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>AI Crop Pathology Engine</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Stethoscope className="w-7 h-7 text-farm-600" />
              <span>{t.doctorTitle}</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
              {t.doctorSubtitle}
            </p>
          </div>

          <button
            onClick={clearForm}
            className="self-start md:self-auto px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-bold text-slate-600 dark:text-slate-300 transition-colors"
          >
            Reset / New Scan
          </button>
        </div>
      </div>

      {/* Main Diagnosis Input Box */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Left Column: Image Upload & Camera */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white flex items-center gap-2 mb-3">
              <Camera className="w-4 h-4 text-farm-600" />
              <span>{t.uploadPhoto}</span>
            </h3>

            <input
              type="file"
              ref={fileInputRef}
              onChange={handleImageChange}
              accept="image/*"
              className="hidden"
            />

            {imagePreview ? (
              <div className="relative rounded-2xl overflow-hidden border-2 border-farm-400 bg-slate-950 aspect-video flex items-center justify-center group">
                <img
                  src={imagePreview}
                  alt="Crop Leaf Diagnosis"
                  className="w-full h-full object-contain"
                />
                <button
                  onClick={() => { setSelectedImage(null); setImagePreview(null); }}
                  className="absolute top-3 right-3 p-2 rounded-full bg-black/70 hover:bg-black text-white transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="cursor-pointer border-2 border-dashed border-farm-300 dark:border-slate-700 hover:border-farm-500 rounded-2xl p-8 text-center bg-farm-50/50 dark:bg-slate-800/40 transition-colors flex flex-col items-center justify-center gap-3 aspect-video"
              >
                <div className="w-14 h-14 rounded-2xl bg-farm-100 dark:bg-farm-900/60 text-farm-700 dark:text-farm-300 flex items-center justify-center shadow-sm">
                  <UploadCloud className="w-7 h-7" />
                </div>
                <div>
                  <p className="text-sm font-bold text-slate-800 dark:text-slate-200">
                    {t.takePhoto}
                  </p>
                  <p className="text-xs text-slate-500 mt-1">
                    Supports JPG, PNG, WEBP from Mobile Camera or Gallery
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Preset Samples to try */}
          <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800">
            <span className="text-xs font-bold text-slate-600 dark:text-slate-400 block mb-2.5">
              {t.trySamplePhotos}
            </span>
            <div className="grid grid-cols-3 gap-2">
              {sampleCropDiseases.slice(0, 3).map((sample) => (
                <button
                  key={sample.id}
                  onClick={() => handleSelectSample(sample)}
                  className="text-left p-2 rounded-xl bg-slate-50 dark:bg-slate-800/80 hover:bg-farm-50 dark:hover:bg-farm-950/40 border border-slate-200 dark:border-slate-700 transition-all text-[11px]"
                >
                  <img
                    src={sample.imageUrl}
                    alt={sample.name}
                    className="w-full h-14 object-cover rounded-lg mb-1.5"
                  />
                  <span className="font-bold text-slate-800 dark:text-slate-200 block truncate">
                    {currentLang === 'or' ? sample.nameOr : sample.name}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Symptoms Text & Voice Mic */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Leaf className="w-4 h-4 text-farm-600" />
                <span>{t.orDescribeSymptoms}</span>
              </h3>

              {/* Voice Microphone Input */}
              <button
                type="button"
                onClick={handleVoiceInput}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  isListening
                    ? 'bg-red-500 text-white animate-bounce'
                    : 'bg-farm-100 dark:bg-farm-950/60 text-farm-800 dark:text-farm-300 border border-farm-200 dark:border-farm-800 hover:bg-farm-200'
                }`}
              >
                {isListening ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5 text-farm-600 dark:text-farm-400" />}
                <span>{isListening ? t.listening : t.micSpeak}</span>
              </button>
            </div>

            <textarea
              rows={6}
              value={symptomsText}
              onChange={(e) => setSymptomsText(e.target.value)}
              placeholder={t.symptomsPlaceholder}
              className="w-full p-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none resize-none leading-relaxed"
            />
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              onClick={handleDiagnose}
              disabled={isDiagnosing}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-farm-600 to-farm-700 hover:from-farm-700 hover:to-farm-800 text-white font-bold text-sm shadow-md shadow-farm-600/20 transition-all flex items-center justify-center gap-2 active:scale-98 disabled:opacity-50"
            >
              {isDiagnosing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Analyzing Plant Pathology & Formulating Treatment...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>{t.diagnoseBtn}</span>
                </>
              )}
            </button>
          </div>
        </div>

      </div>

      {/* Diagnosis Report Card */}
      {diagnosisResult && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border-2 border-farm-400 dark:border-farm-600 shadow-xl animate-in zoom-in-95 duration-200 space-y-6">
          
          {/* Header of Prescription */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
            <div>
              <div className="inline-flex items-center gap-1.5 text-xs font-bold text-farm-600 dark:text-farm-400 mb-1">
                <ShieldCheck className="w-4 h-4" />
                <span>Verified Agricultural Advisory</span>
              </div>
              <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
                {diagnosisResult.name}
              </h3>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs font-bold px-3 py-1.5 rounded-full bg-red-100 dark:bg-red-950/60 text-red-800 dark:text-red-300 border border-red-200 dark:border-red-800">
                {diagnosisResult.severity}
              </span>

              <button
                onClick={() => handleVoiceReadout()}
                className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold shadow-sm transition-all ${
                  isSpeaking
                    ? 'bg-red-500 text-white animate-pulse'
                    : 'bg-farm-600 hover:bg-farm-700 text-white'
                }`}
              >
                {isSpeaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                <span>{isSpeaking ? 'Stop Voice' : t.listenPrescription}</span>
              </button>
            </div>
          </div>

          {/* If Gemini Raw Result */}
          {diagnosisResult.rawText ? (
            <div className="prose dark:prose-invert max-w-none text-sm text-slate-800 dark:text-slate-200 bg-slate-50 dark:bg-slate-800/60 p-6 rounded-2xl border border-slate-200 dark:border-slate-700 whitespace-pre-line leading-relaxed font-sans">
              {diagnosisResult.rawText}
            </div>
          ) : (
            /* Structured Prescription Grid */
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
              
              {/* Organic Remedy */}
              <div className="bg-emerald-50/80 dark:bg-emerald-950/30 rounded-2xl p-5 border border-emerald-200 dark:border-emerald-800/60">
                <div className="flex items-center gap-2 text-emerald-800 dark:text-emerald-300 font-bold text-sm mb-2">
                  <Leaf className="w-4 h-4 text-emerald-600" />
                  <span>{t.organicRemedy}</span>
                </div>
                <p className="text-xs sm:text-sm text-emerald-950 dark:text-emerald-100 leading-relaxed">
                  {diagnosisResult.organic}
                </p>
              </div>

              {/* Chemical Spray */}
              <div className="bg-amber-50/80 dark:bg-amber-950/30 rounded-2xl p-5 border border-amber-200 dark:border-amber-800/60">
                <div className="flex items-center gap-2 text-amber-800 dark:text-amber-300 font-bold text-sm mb-2">
                  <FlaskConical className="w-4 h-4 text-amber-600" />
                  <span>{t.chemicalTreatment}</span>
                </div>
                <p className="text-xs sm:text-sm text-amber-950 dark:text-amber-100 leading-relaxed font-medium">
                  {diagnosisResult.chemical}
                </p>
              </div>

              {/* Preventive Practices */}
              <div className="md:col-span-2 bg-slate-50 dark:bg-slate-800/60 rounded-2xl p-5 border border-slate-200 dark:border-slate-700">
                <div className="flex items-center gap-2 text-slate-800 dark:text-slate-200 font-bold text-sm mb-2">
                  <ShieldCheck className="w-4 h-4 text-farm-600" />
                  <span>{t.preventiveTips}</span>
                </div>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                  {diagnosisResult.preventive}
                </p>
              </div>

            </div>
          )}

          {/* Expert Disclaimer */}
          <div className="pt-2 text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-2">
            <AlertCircle className="w-3.5 h-3.5 text-amber-500 shrink-0" />
            <span>
              Disclaimer: Always wear protective gear when spraying chemicals. Consult local Krishi Vigyan Kendra (KVK) or call 1551 for acute outbreaks.
            </span>
          </div>

        </div>
      )}

    </div>
  );
}
