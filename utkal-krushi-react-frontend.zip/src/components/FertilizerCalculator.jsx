import React, { useState } from 'react';
import { 
  Calculator, 
  Sprout, 
  TrendingUp, 
  Layers, 
  Droplets, 
  Sparkles, 
  CheckCircle2, 
  Printer, 
  HelpCircle,
  Clock,
  FlaskConical,
  Coins
} from 'lucide-react';
import { translations } from '../data/translations';

export default function FertilizerCalculator({ currentLang }) {
  const t = translations[currentLang] || translations.en;

  const [crop, setCrop] = useState("paddy");
  const [landArea, setLandArea] = useState(1);
  const [unit, setUnit] = useState("acre"); // acre, guntha, hectare, decimal
  const [soilType, setSoilType] = useState("alluvial");
  const [irrigation, setIrrigation] = useState("canal");
  const [soilPh, setSoilPh] = useState("6.5");
  const [result, setResult] = useState(null);

  // Crop Nutrient Standards per Acre
  const cropNutrients = {
    paddy: {
      name: currentLang === 'or' ? 'ଧାନ (Paddy)' : 'Paddy / Rice',
      ureaBags: 2.0, // 45 kg bags
      dapBags: 1.0,  // 50 kg bags
      mopBags: 0.8,  // 50 kg bags
      zincKg: 10,
      fymTons: 2,
      expectedYieldPerAcre: 22, // Quintals
      mspPrice: 2300, // ₹ per Qtl
      basalRatio: { urea: 0.25, dap: 1.0, mop: 0.5, zinc: 1.0 },
      tilleringRatio: { urea: 0.45, dap: 0, mop: 0, zinc: 0 },
      floweringRatio: { urea: 0.30, dap: 0, mop: 0.5, zinc: 0 },
    },
    ragi: {
      name: currentLang === 'or' ? 'ମାଣ୍ଡିଆ (Ragi)' : 'Ragi / Millets',
      ureaBags: 1.0,
      dapBags: 0.6,
      mopBags: 0.4,
      zincKg: 5,
      fymTons: 1.5,
      expectedYieldPerAcre: 12,
      mspPrice: 4290,
      basalRatio: { urea: 0.5, dap: 1.0, mop: 1.0, zinc: 1.0 },
      tilleringRatio: { urea: 0.5, dap: 0, mop: 0, zinc: 0 },
      floweringRatio: { urea: 0, dap: 0, mop: 0, zinc: 0 },
    },
    moong: {
      name: currentLang === 'or' ? 'ମୁଗ / ବିରି (Pulses)' : 'Green Gram (Moong)',
      ureaBags: 0.4,
      dapBags: 0.8,
      mopBags: 0.4,
      zincKg: 5,
      fymTons: 1,
      expectedYieldPerAcre: 5.5,
      mspPrice: 8682,
      basalRatio: { urea: 1.0, dap: 1.0, mop: 1.0, zinc: 1.0 },
      tilleringRatio: { urea: 0, dap: 0, mop: 0, zinc: 0 },
      floweringRatio: { urea: 0, dap: 0, mop: 0, zinc: 0 },
    },
    mustard: {
      name: currentLang === 'or' ? 'ସୋରିଷ (Mustard)' : 'Mustard / Rapeseed',
      ureaBags: 1.4,
      dapBags: 0.8,
      mopBags: 0.5,
      zincKg: 8,
      fymTons: 1.5,
      expectedYieldPerAcre: 7,
      mspPrice: 5650,
      basalRatio: { urea: 0.5, dap: 1.0, mop: 1.0, zinc: 1.0 },
      tilleringRatio: { urea: 0.5, dap: 0, mop: 0, zinc: 0 },
      floweringRatio: { urea: 0, dap: 0, mop: 0, zinc: 0 },
    },
    groundnut: {
      name: currentLang === 'or' ? 'ଚିନାବାଦାମ (Groundnut)' : 'Groundnut',
      ureaBags: 0.6,
      dapBags: 1.0,
      mopBags: 0.8,
      zincKg: 10,
      fymTons: 2,
      expectedYieldPerAcre: 11,
      mspPrice: 6783,
      basalRatio: { urea: 1.0, dap: 1.0, mop: 1.0, zinc: 1.0 },
      tilleringRatio: { urea: 0, dap: 0, mop: 0, zinc: 0 },
      floweringRatio: { urea: 0, dap: 0, mop: 0, zinc: 0 },
    },
    chilli: {
      name: currentLang === 'or' ? 'ଲଙ୍କା (Chilli)' : 'Chilli / Capsicum',
      ureaBags: 2.5,
      dapBags: 1.2,
      mopBags: 1.0,
      zincKg: 10,
      fymTons: 3,
      expectedYieldPerAcre: 55, // green quintals
      mspPrice: 4200,
      basalRatio: { urea: 0.3, dap: 1.0, mop: 0.5, zinc: 1.0 },
      tilleringRatio: { urea: 0.4, dap: 0, mop: 0, zinc: 0 },
      floweringRatio: { urea: 0.3, dap: 0, mop: 0.5, zinc: 0 },
    },
    maize: {
      name: currentLang === 'or' ? 'ମକା (Maize)' : 'Maize / Corn',
      ureaBags: 2.2,
      dapBags: 1.0,
      mopBags: 0.8,
      zincKg: 10,
      fymTons: 2,
      expectedYieldPerAcre: 24,
      mspPrice: 2225,
      basalRatio: { urea: 0.3, dap: 1.0, mop: 0.5, zinc: 1.0 },
      tilleringRatio: { urea: 0.4, dap: 0, mop: 0, zinc: 0 },
      floweringRatio: { urea: 0.3, dap: 0, mop: 0.5, zinc: 0 },
    }
  };

  const handleCalculate = (e) => {
    e.preventDefault();
    const areaNum = parseFloat(landArea) || 1;
    
    // Normalize to Acres
    let acres = areaNum;
    if (unit === "guntha") acres = areaNum / 40; // 1 Acre = 40 Guntha
    else if (unit === "decimal") acres = areaNum / 100; // 1 Acre = 100 Decimal
    else if (unit === "hectare") acres = areaNum * 2.471; // 1 Hectare = 2.471 Acres
    else if (unit === "bigha") acres = areaNum * 0.33; // Approx 1 Bigha = 0.33 Acre in Odisha

    const cropData = cropNutrients[crop] || cropNutrients.paddy;

    // Soil type adjustments
    let soilMultiplier = 1.0;
    if (soilType === "laterite") soilMultiplier = 1.15; // Laterite soils in Odisha need slightly higher phosphorus and potash
    if (soilType === "sandy") soilMultiplier = 1.1;

    const totalUrea = (cropData.ureaBags * acres * soilMultiplier).toFixed(1);
    const totalDap = (cropData.dapBags * acres * soilMultiplier).toFixed(1);
    const totalMop = (cropData.mopBags * acres * soilMultiplier).toFixed(1);
    const totalZinc = (cropData.zincKg * acres).toFixed(1);
    const totalFym = (cropData.fymTons * acres).toFixed(1);

    const yieldQty = (cropData.expectedYieldPerAcre * acres).toFixed(1);
    const estimatedRev = (cropData.expectedYieldPerAcre * acres * cropData.mspPrice).toLocaleString('en-IN');

    // Lime advice for acidic Odisha soils
    const phVal = parseFloat(soilPh) || 6.5;
    let limingAdvice = "Soil pH is in normal range (6.0 - 7.5). No special amendment required.";
    if (phVal < 5.5) {
      limingAdvice = `Soil is strongly acidic (pH ${phVal}). Apply 200 - 300 kg Agricultural Lime (Chuna) or Dolomite per acre 15 days before sowing to correct soil acidity and enhance phosphorus uptake.`;
      if (currentLang === 'or') {
        limingAdvice = `ମାଟି ଅତ୍ୟଧିକ ଅମ୍ଳୀୟ (pH ${phVal}) ଅଟେ। ବୁଣିବାର ୧୫ ଦିନ ପୂର୍ବରୁ ଏକର ପିଛା ୨୦୦ ରୁ ୩୦୦ କେଜି କୃଷି ଚୂନ (Lime) ଜମିରେ ପ୍ରୟୋଗ କରନ୍ତୁ।`;
      }
    } else if (phVal > 7.8) {
      limingAdvice = `Soil is alkaline/saline (pH ${phVal}). Apply 100 kg Gypsum per acre and ensure adequate organic matter.`;
    }

    setResult({
      cropName: cropData.name,
      acres: acres.toFixed(2),
      totalUrea,
      totalDap,
      totalMop,
      totalZinc,
      totalFym,
      yieldQty,
      estimatedRev,
      mspPrice: cropData.mspPrice,
      limingAdvice,
      basalUrea: (parseFloat(totalUrea) * cropData.basalRatio.urea).toFixed(1),
      basalDap: totalDap,
      basalMop: (parseFloat(totalMop) * cropData.basalRatio.mop).toFixed(1),
      tilleringUrea: (parseFloat(totalUrea) * cropData.tilleringRatio.urea).toFixed(1),
      floweringUrea: (parseFloat(totalUrea) * cropData.floweringRatio.urea).toFixed(1),
      floweringMop: (parseFloat(totalMop) * cropData.floweringRatio.mop).toFixed(1),
    });
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      
      {/* Header Banner */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-lime-100 dark:bg-lime-950/60 text-lime-800 dark:text-lime-300 text-xs font-bold mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>OUAT & ICAR Agronomy Guidelines</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Calculator className="w-7 h-7 text-lime-600 dark:text-lime-400" />
              <span>{t.calculatorTitle}</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
              {t.calculatorSubtitle}
            </p>
          </div>
        </div>
      </div>

      {/* Main Calculation Form & Results Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Form Inputs */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm">
          <form onSubmit={handleCalculate} className="space-y-4">
            
            {/* Select Crop */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1">
                <Sprout className="w-3.5 h-3.5 text-farm-600" />
                <span>{t.selectCrop}</span>
              </label>
              <select
                value={crop}
                onChange={(e) => setCrop(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-sm font-semibold text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
              >
                <option value="paddy">🌾 Paddy / Rice (ଧାନ)</option>
                <option value="ragi">🥣 Ragi / Millets (ମାଣ୍ଡିଆ)</option>
                <option value="moong">🌱 Green Gram (ମୁଗ / ବିରି)</option>
                <option value="mustard">🌻 Mustard / Rapeseed (ସୋରିଷ)</option>
                <option value="groundnut">🥜 Groundnut (ଚିନାବାଦାମ)</option>
                <option value="chilli">🌶️ Chilli (ଲଙ୍କା)</option>
                <option value="maize">🌽 Maize / Corn (ମକା)</option>
              </select>
            </div>

            {/* Land Area & Unit */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  {t.landArea}
                </label>
                <input
                  type="number"
                  step="0.1"
                  min="0.1"
                  value={landArea}
                  onChange={(e) => setLandArea(e.target.value)}
                  required
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-sm font-semibold text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  {t.areaUnit}
                </label>
                <select
                  value={unit}
                  onChange={(e) => setUnit(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-sm font-semibold text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
                >
                  <option value="acre">Acre (ଏକର)</option>
                  <option value="guntha">Guntha (ଗୁଣ୍ଠ - 1/40 Acre)</option>
                  <option value="decimal">Decimal / Cent (ଡେସିମିଲ୍)</option>
                  <option value="hectare">Hectare (ହେକ୍ଟର)</option>
                  <option value="bigha">Bigha (ବିଘା)</option>
                </select>
              </div>
            </div>

            {/* Soil Type */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1">
                <Layers className="w-3.5 h-3.5 text-earth-600" />
                <span>{t.soilType}</span>
              </label>
              <select
                value={soilType}
                onChange={(e) => setSoilType(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-sm font-semibold text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
              >
                <option value="alluvial">Alluvial Loam / Mati (ନଦୀ କୂଳିଆ ପଟୁ ମାଟି)</option>
                <option value="red">Red Loamy Soil (ଲାଲ୍ ମାଟି)</option>
                <option value="laterite">Laterite Soil (ମାଙ୍କଡ଼ା ପଥୁରିଆ ମାଟି)</option>
                <option value="black">Black Cotton Soil (କଳା ମାଟି)</option>
                <option value="sandy">Sandy Loam / Coastal (ବାଲିଆ ମାଟି)</option>
              </select>
            </div>

            {/* Irrigation & Soil pH */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1">
                  <Droplets className="w-3.5 h-3.5 text-sky-500" />
                  <span>{t.irrigationType}</span>
                </label>
                <select
                  value={irrigation}
                  onChange={(e) => setIrrigation(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-sm font-semibold text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
                >
                  <option value="canal">Canal / River lift (କେନାଲ)</option>
                  <option value="borewell">Borewell / Solar pump (ବୋରୱେଲ)</option>
                  <option value="rainfed">Rainfed / Non-irrigated (ବର୍ଷା ଆଶ୍ରିତ)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1">
                  <FlaskConical className="w-3.5 h-3.5 text-teal-600" />
                  <span>{t.soilPh}</span>
                </label>
                <input
                  type="number"
                  step="0.1"
                  min="4.0"
                  max="9.5"
                  value={soilPh}
                  onChange={(e) => setSoilPh(e.target.value)}
                  placeholder="e.g. 6.2"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-sm font-semibold text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Calculate Button */}
            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-farm-600 to-farm-700 hover:from-farm-700 hover:to-farm-800 text-white font-bold text-sm shadow-md shadow-farm-600/20 transition-all flex items-center justify-center gap-2"
              >
                <Calculator className="w-4 h-4" />
                <span>{t.calculateBtn}</span>
              </button>
            </div>

          </form>
        </div>

        {/* Results Panel */}
        <div className="lg:col-span-7">
          {result ? (
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border-2 border-farm-400 dark:border-farm-600 shadow-lg space-y-6 animate-in zoom-in-95 duration-200">
              
              {/* Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-200 dark:border-slate-800">
                <div>
                  <h3 className="text-xl font-black text-slate-900 dark:text-white">
                    {result.cropName} ({result.acres} Acres)
                  </h3>
                  <span className="text-xs text-slate-500 dark:text-slate-400">
                    Calculated for optimal Odisha agro-climatic conditions
                  </span>
                </div>
                
                <button
                  onClick={() => window.print()}
                  className="self-start sm:self-auto inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 transition-colors"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Report</span>
                </button>
              </div>

              {/* Yield and Income Banner */}
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gradient-to-br from-farm-50 to-emerald-50 dark:from-farm-950/40 dark:to-emerald-950/40 border border-farm-200 dark:border-farm-800 rounded-2xl p-4">
                  <span className="text-xs font-semibold text-farm-800 dark:text-farm-300 block">
                    {t.expectedYield}
                  </span>
                  <div className="text-2xl sm:text-3xl font-black text-farm-700 dark:text-farm-400 mt-1">
                    {result.yieldQty} <span className="text-xs font-normal text-slate-500">Quintals</span>
                  </div>
                </div>

                <div className="bg-gradient-to-br from-amber-50 to-orange-50 dark:from-amber-950/40 dark:to-orange-950/40 border border-amber-200 dark:border-amber-800 rounded-2xl p-4">
                  <span className="text-xs font-semibold text-amber-800 dark:text-amber-300 block">
                    {t.estimatedIncome} (@ MSP)
                  </span>
                  <div className="text-2xl sm:text-3xl font-black text-amber-700 dark:text-amber-400 mt-1">
                    ₹{result.estimatedRev}
                  </div>
                </div>
              </div>

              {/* Fertilizer Bag Requirements */}
              <div>
                <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-3">
                  Required Nutrient Bags
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  <div className="bg-slate-50 dark:bg-slate-800/60 rounded-xl p-3 border border-slate-200 dark:border-slate-700">
                    <span className="text-xs text-slate-500 dark:text-slate-400 block">{t.ureaReq}</span>
                    <span className="text-lg font-black text-slate-900 dark:text-white mt-1 block">
                      {result.totalUrea} Bags
                    </span>
                  </div>

                  <div className="bg-slate-50 dark:bg-slate-800/60 rounded-xl p-3 border border-slate-200 dark:border-slate-700">
                    <span className="text-xs text-slate-500 dark:text-slate-400 block">{t.dapReq}</span>
                    <span className="text-lg font-black text-slate-900 dark:text-white mt-1 block">
                      {result.totalDap} Bags
                    </span>
                  </div>

                  <div className="bg-slate-50 dark:bg-slate-800/60 rounded-xl p-3 border border-slate-200 dark:border-slate-700">
                    <span className="text-xs text-slate-500 dark:text-slate-400 block">{t.mopReq}</span>
                    <span className="text-lg font-black text-slate-900 dark:text-white mt-1 block">
                      {result.totalMop} Bags
                    </span>
                  </div>

                  <div className="bg-slate-50 dark:bg-slate-800/60 rounded-xl p-3 border border-slate-200 dark:border-slate-700">
                    <span className="text-xs text-slate-500 dark:text-slate-400 block">{t.zincReq}</span>
                    <span className="text-lg font-black text-slate-900 dark:text-white mt-1 block">
                      {result.totalZinc} kg
                    </span>
                  </div>

                  <div className="col-span-2 bg-slate-50 dark:bg-slate-800/60 rounded-xl p-3 border border-slate-200 dark:border-slate-700">
                    <span className="text-xs text-slate-500 dark:text-slate-400 block">{t.organicReq}</span>
                    <span className="text-lg font-black text-slate-900 dark:text-white mt-1 block">
                      {result.totalFym} Tons (FYM / Vermicompost)
                    </span>
                  </div>
                </div>
              </div>

              {/* 3-Phase Schedule */}
              <div className="space-y-2.5">
                <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                  {t.applicationSchedule}
                </h4>

                <div className="bg-slate-50 dark:bg-slate-800/60 rounded-xl p-3.5 border border-slate-200 dark:border-slate-700 text-xs leading-relaxed">
                  <strong className="text-farm-700 dark:text-farm-400 block mb-1">
                    {t.basalDose}
                  </strong>
                  Apply <strong>{result.basalDap} bags DAP</strong> + <strong>{result.basalMop} bags MOP</strong> + <strong>{result.basalUrea} bags Urea</strong> + <strong>{result.totalZinc} kg Zinc</strong> at land preparation/transplanting.
                </div>

                <div className="bg-slate-50 dark:bg-slate-800/60 rounded-xl p-3.5 border border-slate-200 dark:border-slate-700 text-xs leading-relaxed">
                  <strong className="text-farm-700 dark:text-farm-400 block mb-1">
                    {t.tilleringDose} (20-25 Days)
                  </strong>
                  Top dress <strong>{result.tilleringUrea} bags Urea</strong> mixed with neem oil/cake after weeding in moist soil.
                </div>

                <div className="bg-slate-50 dark:bg-slate-800/60 rounded-xl p-3.5 border border-slate-200 dark:border-slate-700 text-xs leading-relaxed">
                  <strong className="text-farm-700 dark:text-farm-400 block mb-1">
                    {t.floweringDose} (40-45 Days)
                  </strong>
                  Apply final top dressing of <strong>{result.floweringUrea} bags Urea</strong> + <strong>{result.floweringMop} bags MOP</strong>.
                </div>
              </div>

              {/* Liming / Soil pH Advice */}
              <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-2xl p-4 text-xs text-amber-900 dark:text-amber-200">
                <div className="font-bold flex items-center gap-1.5 mb-1">
                  <HelpCircle className="w-4 h-4 text-amber-600" />
                  <span>{t.soilHealthTip}</span>
                </div>
                <p>{result.limingAdvice}</p>
              </div>

            </div>
          ) : (
            <div className="h-full bg-white dark:bg-slate-900 rounded-3xl p-8 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col items-center justify-center text-center">
              <div className="w-16 h-16 rounded-2xl bg-farm-50 dark:bg-slate-800 text-farm-600 flex items-center justify-center mb-4">
                <Calculator className="w-8 h-8" />
              </div>
              <h3 className="text-base font-bold text-slate-800 dark:text-slate-200">
                Ready to Calculate
              </h3>
              <p className="text-xs text-slate-500 max-w-sm mt-1">
                Enter your land area and select your crop to generate exact fertilizer bag counts, application timeline, and expected harvest yield.
              </p>
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
