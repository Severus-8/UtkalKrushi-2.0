import React, { useState, useEffect } from 'react';
import { 
  CloudSun, 
  Droplets, 
  Wind, 
  CloudRain, 
  Sun, 
  MapPin, 
  Search, 
  Volume2, 
  VolumeX, 
  AlertTriangle, 
  CheckCircle, 
  XCircle, 
  RefreshCw,
  Compass,
  Calendar,
  Clock
} from 'lucide-react';
import { translations } from '../data/translations';
import { API_CONFIG, apiFetch } from '../config/api';
import { odishaDistricts } from '../data/mandiPrices';
import { speakText, stopSpeaking } from '../utils/speechUtils';

// Coordinates for Odisha districts for fast, reliable zero-latency lookup
const districtCoordinates = {
  "Bhubaneswar": { lat: 20.2961, lon: 85.8245, name: "Bhubaneswar (Khordha)" },
  "Khordha (Bhubaneswar)": { lat: 20.2961, lon: 85.8245, name: "Bhubaneswar (Khordha)" },
  "Cuttack": { lat: 20.4625, lon: 85.8828, name: "Cuttack" },
  "Sambalpur": { lat: 21.4669, lon: 83.9812, name: "Sambalpur" },
  "Bargarh": { lat: 21.3333, lon: 83.6167, name: "Bargarh" },
  "Balasore": { lat: 21.4934, lon: 86.9135, name: "Balasore" },
  "Ganjam": { lat: 19.3149, lon: 84.7941, name: "Berhampur (Ganjam)" },
  "Puri": { lat: 19.8135, lon: 85.8312, name: "Puri" },
  "Koraput": { lat: 18.8120, lon: 82.7108, name: "Koraput" },
  "Mayurbhanj": { lat: 21.9333, lon: 86.7333, name: "Baripada (Mayurbhanj)" },
  "Kalahandi": { lat: 19.9137, lon: 83.1649, name: "Bhawanipatna (Kalahandi)" },
  "Kendujhar (Keonjhar)": { lat: 21.6288, lon: 85.5817, name: "Keonjhar" },
  "Angul": { lat: 20.8398, lon: 85.1013, name: "Angul" },
  "Balangir": { lat: 20.7082, lon: 83.4854, name: "Balangir" },
  "Bhadrak": { lat: 21.0543, lon: 86.4975, name: "Bhadrak" },
  "Boudh": { lat: 20.8354, lon: 84.3262, name: "Boudh" },
  "Deogarh": { lat: 21.5333, lon: 84.7333, name: "Deogarh" },
  "Dhenkanal": { lat: 20.6667, lon: 85.6000, name: "Dhenkanal" },
  "Gajapati": { lat: 18.8167, lon: 84.1667, name: "Paralakhemundi (Gajapati)" },
  "Jagatsinghpur": { lat: 20.2581, lon: 86.1681, name: "Jagatsinghpur" },
  "Jajpur": { lat: 20.8500, lon: 86.3333, name: "Jajpur" },
  "Jharsuguda": { lat: 21.8549, lon: 84.0084, name: "Jharsuguda" },
  "Kandhamal": { lat: 20.4700, lon: 84.2300, name: "Phulbani (Kandhamal)" },
  "Kendrapara": { lat: 20.5000, lon: 86.4200, name: "Kendrapara" },
  "Malkangiri": { lat: 18.3500, lon: 81.9000, name: "Malkangiri" },
  "Nabarangpur": { lat: 19.2300, lon: 82.5500, name: "Nabarangpur" },
  "Nayagarh": { lat: 20.1300, lon: 85.1100, name: "Nayagarh" },
  "Nuapada": { lat: 20.8300, lon: 82.5200, name: "Nuapada" },
  "Rayagada": { lat: 19.1700, lon: 83.4200, name: "Rayagada" },
  "Subarnapur (Sonepur)": { lat: 20.8300, lon: 83.9200, name: "Sonepur" },
  "Sundargarh": { lat: 22.1200, lon: 84.0300, name: "Rourkela / Sundargarh" }
};

export default function WeatherSection({ currentLang }) {
  const t = translations[currentLang] || translations.en;
  
  const [selectedDistrict, setSelectedDistrict] = useState("Khordha (Bhubaneswar)");
  const [searchQuery, setSearchQuery] = useState("");
  const [weatherData, setWeatherData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [locationName, setLocationName] = useState("Bhubaneswar (Khordha)");
  const [isSpeaking, setIsSpeaking] = useState(false);

  const getWeatherIcon = (code) => {
    if (code === 0) return { icon: '☀️', label: 'Clear Sky' };
    if (code === 1 || code === 2) return { icon: '🌤️', label: 'Partly Cloudy' };
    if (code === 3) return { icon: '☁️', label: 'Overcast' };
    if (code >= 45 && code <= 48) return { icon: '🌫️', label: 'Foggy' };
    if (code >= 51 && code <= 55) return { icon: '🌦️', label: 'Light Drizzle' };
    if (code >= 61 && code <= 65) return { icon: '🌧️', label: 'Rain' };
    if (code >= 80 && code <= 82) return { icon: '🌧️', label: 'Rain Showers' };
    if (code >= 95) return { icon: '⛈️', label: 'Thunderstorm' };
    return { icon: '🌤️', label: 'Pleasant' };
  };

  const fetchWeather = async (lat, lon, placeName) => {
    setLoading(true);
    setError(null);
    try {
      // 1) Preferred: our Django backend (proxied, adds location label + spray advisory).
      try {
        const data = await apiFetch(
          `${API_CONFIG.ENDPOINTS.WEATHER}?lat=${lat}&lon=${lon}&district=${encodeURIComponent(placeName)}`,
          { timeoutMs: 9000 }
        );
        if (data?.current && data?.hourly) {
          setWeatherData(data);
          setLocationName(data.location || placeName);
          return;
        }
      } catch (backendErr) {
        console.warn("Backend weather unavailable, falling back to Open-Meteo direct:", backendErr);
      }

      // 2) Fallback: direct Open-Meteo call so weather still works without a backend.
      const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,rain,weather_code,wind_speed_10m,wind_direction_10m,cloud_cover&hourly=temperature_2m,precipitation_probability,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max&timezone=Asia%2FKolkata`;
      
      const res = await fetch(url);
      if (!res.ok) throw new Error("Could not fetch weather data");
      const data = await res.json();
      setWeatherData(data);
      setLocationName(placeName);
    } catch (err) {
      console.error(err);
      setError("Failed to load weather data. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const coords = districtCoordinates[selectedDistrict] || districtCoordinates["Bhubaneswar"];
    fetchWeather(coords.lat, coords.lon, coords.name);
  }, [selectedDistrict]);

  const handleCustomSearch = async (e) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    setLoading(true);
    try {
      const geoUrl = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(searchQuery)}&count=1&language=en&format=json`;
      const res = await fetch(geoUrl);
      const data = await res.json();
      if (data.results && data.results.length > 0) {
        const place = data.results[0];
        fetchWeather(place.latitude, place.longitude, `${place.name}, ${place.admin1 || place.country}`);
      } else {
        setError(`Location "${searchQuery}" not found. Please try another city.`);
        setLoading(false);
      }
    } catch (err) {
      setError("Geocoding failed. Please check internet connection.");
      setLoading(false);
    }
  };

  const handleGeoLocation = () => {
    if (!navigator.geolocation) {
      alert("Geolocation is not supported by your browser.");
      return;
    }
    setLoading(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        fetchWeather(pos.coords.latitude, pos.coords.longitude, "Your Current Location");
      },
      (err) => {
        alert("Location access denied. Please select your district manually.");
        setLoading(false);
      }
    );
  };

  // Spray and Agro Advisory Evaluation
  const current = weatherData?.current;
  const windSpeed = current?.wind_speed_10m || 0;
  const rain = current?.precipitation || 0;
  const temp = current?.temperature_2m || 0;
  const humidity = current?.relative_humidity_2m || 0;

  let sprayStatus = 'safe';
  let sprayText = t.spraySafe;
  if (rain > 0.5 || windSpeed > 18) {
    sprayStatus = 'unsafe';
    sprayText = t.sprayUnsafe;
  } else if (windSpeed > 12 || rain > 0) {
    sprayStatus = 'caution';
    sprayText = t.sprayCaution;
  }

  // Voice Weather Readout
  const handleVoiceReadout = () => {
    if (isSpeaking) {
      stopSpeaking();
      setIsSpeaking(false);
      return;
    }

    let speechText = "";
    if (currentLang === 'or') {
      speechText = `${locationName} ରେ ବର୍ତ୍ତମାନର ତାପମାତ୍ରା ${temp.toFixed(1)} ଡିଗ୍ରୀ ସେଲସିୟସ। ଆର୍ଦ୍ରତା ${humidity} ପ୍ରତିଶତ ଏବଂ ପବନର ବେଗ ${windSpeed.toFixed(1)} କିଲୋମିଟର ପ୍ରତି ଘଣ୍ଟା। ଔଷଧ ସିଞ୍ଚନ ପାଇଁ ପରାମର୍ଶ: ${sprayText}।`;
    } else if (currentLang === 'hi') {
      speechText = `${locationName} में वर्तमान तापमान ${temp.toFixed(1)} डिग्री सेल्सियस है। आर्द्रता ${humidity} प्रतिशत और हवा की गति ${windSpeed.toFixed(1)} किलोमीटर प्रति घंटा है। कीटनाशक छिड़काव सलाह: ${sprayText}।`;
    } else {
      speechText = `Current weather in ${locationName}: Temperature is ${temp.toFixed(1)} degrees Celsius, humidity is ${humidity} percent, wind speed is ${windSpeed.toFixed(1)} km per hour. Spray advisory: ${sprayText}.`;
    }

    setIsSpeaking(true);
    speakText(
      speechText,
      currentLang,
      () => setIsSpeaking(true),
      () => setIsSpeaking(false),
      () => setIsSpeaking(false)
    );
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Header & Location Selectors */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
              <CloudSun className="w-7 h-7 text-sky-500" />
              <span>{t.weatherTitle}</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
              {t.weatherSubtitle}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={handleVoiceReadout}
              className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all ${
                isSpeaking 
                  ? 'bg-red-500 text-white animate-pulse' 
                  : 'bg-farm-100 dark:bg-farm-950/60 text-farm-800 dark:text-farm-300 border border-farm-200 dark:border-farm-800 hover:bg-farm-200'
              }`}
            >
              {isSpeaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-farm-600 dark:text-farm-400" />}
              <span>{isSpeaking ? 'Stop Voice' : t.speakWeather}</span>
            </button>

            <button
              onClick={handleGeoLocation}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold transition-all"
              title="Detect GPS location"
            >
              <Compass className="w-4 h-4 text-sky-500" />
              <span>Auto GPS</span>
            </button>
          </div>
        </div>

        {/* District Selector & Custom Search Controls */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-5">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-farm-600" />
              <span>{t.selectDistrict}</span>
            </label>
            <select
              value={selectedDistrict}
              onChange={(e) => setSelectedDistrict(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-sm font-semibold text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
            >
              {Object.keys(districtCoordinates).map((dist) => (
                <option key={dist} value={dist}>
                  {dist}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              {t.orSearchCity}
            </label>
            <form onSubmit={handleCustomSearch} className="flex gap-2">
              <input
                type="text"
                placeholder="E.g. Jeypore, Kendrapara, Rourkela..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-farm-500 focus:outline-none"
              />
              <button
                type="submit"
                className="px-4 py-2.5 bg-farm-600 hover:bg-farm-700 text-white rounded-xl text-xs font-bold flex items-center gap-1 shadow-sm shrink-0"
              >
                <Search className="w-3.5 h-3.5" />
                <span>{t.searchBtn}</span>
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* Weather State Handling */}
      {loading && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-12 text-center border border-slate-200 dark:border-slate-800">
          <RefreshCw className="w-8 h-8 text-farm-500 animate-spin mx-auto mb-3" />
          <p className="text-sm font-semibold text-slate-600 dark:text-slate-300">
            Fetching accurate micro-climate weather for {locationName}...
          </p>
        </div>
      )}

      {error && !loading && (
        <div className="bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 rounded-2xl p-4 text-sm text-red-700 dark:text-red-300 flex items-center gap-3">
          <AlertTriangle className="w-5 h-5 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {weatherData && !loading && (
        <div className="space-y-6">
          
          {/* Main Weather Metrics Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Primary Current Temp Card */}
            <div className="lg:col-span-1 rounded-3xl bg-gradient-to-br from-sky-500 via-sky-600 to-blue-700 text-white p-6 sm:p-8 shadow-lg flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between text-xs font-semibold text-sky-100 mb-4">
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-sky-200" />
                    <span className="text-sm font-bold text-white">{locationName}</span>
                  </span>
                  <span>Live Weather</span>
                </div>

                <div className="flex items-center gap-4 my-2">
                  <span className="text-5xl sm:text-6xl">
                    {getWeatherIcon(current?.weather_code).icon}
                  </span>
                  <div>
                    <div className="text-4xl sm:text-5xl font-black tracking-tight">
                      {current?.temperature_2m?.toFixed(1)}°C
                    </div>
                    <div className="text-xs sm:text-sm text-sky-100 font-medium">
                      {getWeatherIcon(current?.weather_code).label}
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-sky-400/40 flex items-center justify-between text-xs text-sky-100">
                <span>{t.feelsLike}: <strong>{current?.apparent_temperature?.toFixed(1)}°C</strong></span>
                <span>Cloud: <strong>{current?.cloud_cover || 0}%</strong></span>
              </div>
            </div>

            {/* Micro-climate Metrics Tiles */}
            <div className="lg:col-span-2 grid grid-cols-2 sm:grid-cols-3 gap-4">
              
              <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-5 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
                <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-semibold">
                  <span>{t.humidity}</span>
                  <Droplets className="w-4 h-4 text-sky-500" />
                </div>
                <div className="mt-2 text-2xl sm:text-3xl font-black text-slate-800 dark:text-slate-100">
                  {current?.relative_humidity_2m}%
                </div>
                <span className="text-[11px] text-slate-500 mt-1">
                  {current?.relative_humidity_2m > 75 ? 'High moisture' : 'Optimal for field'}
                </span>
              </div>

              <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-5 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
                <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-semibold">
                  <span>{t.windSpeed}</span>
                  <Wind className="w-4 h-4 text-teal-500" />
                </div>
                <div className="mt-2 text-2xl sm:text-3xl font-black text-slate-800 dark:text-slate-100">
                  {current?.wind_speed_10m?.toFixed(1)} <span className="text-xs font-normal text-slate-500">km/h</span>
                </div>
                <span className="text-[11px] text-slate-500 mt-1">
                  {windSpeed > 15 ? 'Breezy conditions' : 'Calm / Gentle'}
                </span>
              </div>

              <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-5 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
                <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-semibold">
                  <span>{t.precipitation}</span>
                  <CloudRain className="w-4 h-4 text-blue-500" />
                </div>
                <div className="mt-2 text-2xl sm:text-3xl font-black text-slate-800 dark:text-slate-100">
                  {current?.precipitation?.toFixed(1)} <span className="text-xs font-normal text-slate-500">mm</span>
                </div>
                <span className="text-[11px] text-slate-500 mt-1">
                  {rain > 0 ? 'Rainfall active' : 'No rain right now'}
                </span>
              </div>

              {/* Pesticide Spray Farm Advisory Banner Tile */}
              <div className={`col-span-2 sm:col-span-3 rounded-2xl p-4 border flex items-start gap-3.5 ${
                sprayStatus === 'safe' 
                  ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200' 
                  : sprayStatus === 'caution'
                  ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-200'
                  : 'bg-red-50 dark:bg-red-950/40 border-red-200 dark:border-red-800 text-red-900 dark:text-red-200'
              }`}>
                {sprayStatus === 'safe' ? (
                  <CheckCircle className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
                ) : sprayStatus === 'caution' ? (
                  <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                ) : (
                  <XCircle className="w-5 h-5 text-red-600 dark:text-red-400 shrink-0 mt-0.5" />
                )}
                <div>
                  <h4 className="font-bold text-xs sm:text-sm">{t.sprayCondition}</h4>
                  <p className="text-xs mt-0.5 opacity-90">{sprayText}</p>
                </div>
              </div>

            </div>

          </div>

          {/* Hourly Weather (Next 24 Hours) */}
          {weatherData.hourly && (
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm">
              <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white flex items-center gap-2 mb-4">
                <Clock className="w-4 h-4 text-farm-600" />
                <span>{t.nextHours}</span>
              </h3>

              <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-thin">
                {weatherData.hourly.time.slice(0, 12).map((timeStr, idx) => {
                  const date = new Date(timeStr);
                  const timeFormatted = date.toLocaleTimeString([], { hour: 'numeric', hour12: true });
                  const tempVal = weatherData.hourly.temperature_2m[idx];
                  const rainProb = weatherData.hourly.precipitation_probability[idx] || 0;
                  const code = weatherData.hourly.weather_code[idx];

                  return (
                    <div
                      key={idx}
                      className="shrink-0 w-24 bg-slate-50 dark:bg-slate-800/60 rounded-2xl p-3 text-center border border-slate-200/60 dark:border-slate-700/60 flex flex-col items-center justify-between"
                    >
                      <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                        {timeFormatted}
                      </span>
                      <span className="text-2xl my-1.5">
                        {getWeatherIcon(code).icon}
                      </span>
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-100">
                        {tempVal.toFixed(0)}°C
                      </span>
                      <span className="text-[10px] text-sky-600 dark:text-sky-400 font-medium mt-1">
                        💧 {rainProb}%
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* 7-Day Agricultural Forecast Outlook */}
          {weatherData.daily && (
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm">
              <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white flex items-center gap-2 mb-4">
                <Calendar className="w-4 h-4 text-farm-600" />
                <span>{t.sevenDayForecast}</span>
              </h3>

              <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
                {weatherData.daily.time.map((dStr, idx) => {
                  const d = new Date(dStr);
                  const dayName = d.toLocaleDateString('en-US', { weekday: 'short' });
                  const dateFormatted = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
                  const maxT = weatherData.daily.temperature_2m_max[idx];
                  const minT = weatherData.daily.temperature_2m_min[idx];
                  const rainMax = weatherData.daily.precipitation_probability_max[idx] || 0;
                  const code = weatherData.daily.weather_code[idx];

                  return (
                    <div
                      key={idx}
                      className="bg-slate-50 dark:bg-slate-800/60 rounded-2xl p-3 text-center border border-slate-200/60 dark:border-slate-700/60"
                    >
                      <div className="text-xs font-bold text-slate-800 dark:text-slate-100">{dayName}</div>
                      <div className="text-[10px] text-slate-500 dark:text-slate-400">{dateFormatted}</div>
                      <div className="text-3xl my-2">{getWeatherIcon(code).icon}</div>
                      <div className="text-xs font-bold text-slate-900 dark:text-white">
                        {maxT.toFixed(0)}° / <span className="text-slate-500">{minT.toFixed(0)}°</span>
                      </div>
                      <div className="mt-1.5 inline-block text-[10px] font-semibold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 px-2 py-0.5 rounded-full">
                        Rain: {rainMax}%
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

        </div>
      )}

    </div>
  );
}
