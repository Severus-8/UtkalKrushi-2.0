# Utkal Krushi (ଉତ୍କଳ କୃଷି) - Smart Agriculture Portal for Farmers

A simple, clean, accessible, and multilingual React frontend built specifically for the farming community of Odisha and India.

## 🌾 Key Features

1. **Multilingual & High-Accessibility Design**
   - Seamless switching between **Odia (ଓଡ଼ିଆ)**, **Hindi (हिंदी)**, and **English**.
   - Large touch targets, high-contrast earth/harvest palette, simple agricultural terms.
   - Text-to-Speech (TTS) voice narration 🔊 and Voice Input (Speech-to-Text) 🎙️ for farmers with varying literacy levels.

2. **Live Micro-Climate Weather & Agricultural Advisory**
   - Real-time weather forecasting for all 30 districts of Odisha with Open-Meteo API.
   - GPS auto-location detection and nationwide search.
   - **Actionable Spray Advisory**: Wind & rain safety indicators for pesticide application.
   - 24-Hour hourly forecast and 7-day agricultural outlook.

3. **AI Crop Doctor & Disease Scanner (କୃଷି ଡାକ୍ତର)**
   - Upload leaf/crop photo or select from pre-loaded common Odisha crop diseases (Rice Blast, Bacterial Leaf Blight, Yellow Stem Borer, Chilli Leaf Curl, Tomato Early Blight, Maize Armyworm).
   - Voice microphone input for describing symptoms.
   - Prescriptions include Severity rating, Organic/Biological remedies (Neem, Trichoderma, Cow urine), Chemical treatment with exact dosage per liter of water, and preventive cultural practices.
   - Powered by Gemini 2.5 API with intelligent offline expert agronomist fallback.

4. **Smart Land-Based Fertilizer & Yield Calculator**
   - Customized calculation based on land units (Acres, Guntha, Decimal, Hectare, Bigha), crop type, soil type, and soil pH.
   - Gives exact commercial bag count (Urea 45kg bags, DAP 50kg bags, MOP 50kg bags, Zinc Sulphate, Farmyard manure).
   - Step-by-step 3-phase application schedule (Basal at sowing, 1st Top Dressing at tillering, 2nd Top Dressing at flowering).
   - Soil health and liming advice for acidic Odisha soils.

5. **Live Odisha Mandi Prices & MSP Tracker**
   - Daily APMC market rates across Odisha districts (Bargarh, Sambalpur, Cuttack, Koraput, Balasore, etc.).
   - Comparison against Government Minimum Support Price (MSP) with price trend indicators.

6. **Government Subsidies & Schemes Directory**
   - Odisha State Schemes: KALIA, Saurajalanidhi (90% Solar Pump), Odisha Millets Mission, Seed Subsidy, Farm Machinery DBT.
   - Central Schemes: PM-KISAN, PM Fasal Bima (PMFBY), Kisan Credit Card (KCC 4%), SMAM.
   - Complete eligibility rules, required documents checklist, and direct official apply links.

7. **Krushi Mitra AI Conversational Assistant (କୃଷି ମିତ୍ର)**
   - Interactive chat in Odia, Hindi, or English.
   - Voice input and voice readout.
   - Fast suggestion chips for frequent farming inquiries.

8. **Odisha Crop Cultivation Guide & Agricultural Calendar**
   - Detailed seasonal guides for Kharif, Rabi, and Summer/Zaid crops in Odisha.

9. **Farmer Khata - Farm Expense & Profit Calculator**
   - Track seed, fertilizer, labor, and machinery costs to calculate true net profit and profit margin per acre.
   - **Save & history**: entries persist to the backend ledger when reachable, and always to on-device localStorage as backup.

10. **Emergency Kisan Helplines (1-Click Dial)**
    - Kisan Call Center (1551), Odisha Krushi Helpline (1800-180-1551), PMFBY (1800-180-1111), Veterinary Clinic (1962).

---

## 🔌 Backend: Optional but Recommended

Every feature works fully offline, and gets *better* with the Django backend connected:

| Feature | With backend | Without backend (automatic fallback) |
|---|---|---|
| Weather | Django proxy + location label + spray advisory | Direct Open-Meteo call from the browser |
| Crop Doctor | Server-side Gemini vision (API key stays on server) + trilingual knowledge base | Offline keyword matcher + agronomy templates |
| Fertilizer Calculator | Server-side OUAT/ICAR agronomy engine | Identical client-side calculation |
| Mandi Prices & Schemes | Live seeded feed (badge: "Live Backend Feed") | Bundled sample data (badge shown) |
| Krushi AI Chatbot | Server-side Gemini replies | Offline expert engine |
| Farm Khata | Server ledger + device backup | localStorage only |

See **BACKEND_API_GUIDE.md** for the full API contract. Local dev needs zero configuration — the Vite dev server proxies `/api/*` to `http://127.0.0.1:8000`.

> 🔒 **Security note:** this repo previously contained a hardcoded Gemini API key in `src/utils/geminiApi.js`. That key has been **removed** — AI calls now run server-side. If you deployed earlier builds, revoke that key in Google AI Studio.

---
*Built with React 18, Vite, Tailwind CSS, Lucide Icons, and Web Speech API.*
