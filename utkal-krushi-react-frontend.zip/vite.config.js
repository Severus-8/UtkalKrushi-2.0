import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// In dev/preview the frontend calls the backend via relative "/api/..." paths,
// which this proxy forwards to the Django server. Override the target with
// VITE_PROXY_TARGET if your API runs elsewhere.
const proxyTarget = process.env.VITE_PROXY_TARGET || 'http://127.0.0.1:8000';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    host: '0.0.0.0',
    port: 5173,
    allowedHosts: true,
    proxy: {
      '/api': {
        target: proxyTarget,
        changeOrigin: true,
      },
    },
  }
})
