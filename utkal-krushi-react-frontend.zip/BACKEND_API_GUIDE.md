# Backend Integration Guide for Utkal Krushi (ଉତ୍କଳ କୃଷି)

Hi Backend Developer! 👋
This frontend is built with **React 18 + Vite + Tailwind CSS**. Every feature now talks to the backend **first** and falls back to its built-in offline engine (bundled data / client-side calculators) when the API is unreachable — so the app works everywhere, and the backend makes it *better* (live data, persistence, server-side AI).

The reference Django implementation of this exact contract ships in `utkal-krushi-django-backend.zip`.

---

## ⚙️ 1. Connecting Your Backend

**Local development (nothing to configure):** the Vite dev server proxies relative `/api/*` requests to `http://127.0.0.1:8000` (see `vite.config.js`, override target with `VITE_PROXY_TARGET`).

**Pointing at another origin** — create a `.env` file in the frontend root:
```env
VITE_API_BASE_URL=https://api.your-domain.com/api
```
Or edit `src/config/api.js`. Enable CORS for the frontend origin on your backend in that case.

---

## 📡 2. API Contract (all paths under the base URL, no trailing slashes)

### A. 🌦️ Weather & Agro-Advisory — `GET /api/weather?district=Bargarh` or `?lat=20.29&lon=85.82`

Response contains **raw Open-Meteo-shaped blocks** (the component consumes them directly) plus friendly extras:

```json
{
  "current":   { "temperature_2m": 29.5, "relative_humidity_2m": 78, "apparent_temperature": 32.1,
                 "precipitation": 0.0, "rain": 0.0, "weather_code": 1,
                 "wind_speed_10m": 11.2, "wind_direction_10m": 245, "cloud_cover": 40 },
  "hourly":    { "time": ["2026-09-01T10:00", "..."], "temperature_2m": [30.1],
                 "precipitation_probability": [10], "weather_code": [1] },
  "daily":     { "time": ["2026-09-01"], "weather_code": [1], "temperature_2m_max": [33.2],
                 "temperature_2m_min": [26.1], "precipitation_sum": [0.0],
                 "precipitation_probability_max": [15] },
  "location": "Bargarh",
  "sprayAdvisory": { "status": "safe", "message": "Safe to spray - Low wind & no rain expected" }
}
```
Frontend fallback: calls Open-Meteo directly from the browser.

### B. 🌿 AI Crop Doctor — `POST /api/crop-doctor/diagnose`

```json
// Request
{ "symptoms": "yellow spots on paddy leaf", "imageBase64": "<raw base64 or data URI or null>", "lang": "or" }

// Response
{ "source": "ai" | "knowledge-base" | "none",
  "reply": "<markdown report in the requested language>",
  "match": { "diseaseName": "...", "diseaseNameOr": "...", "severity": "High", "organicRemedy": "...", "...": "..." } | null,
  "matchScore": 2 }
```
- With `GEMINI_API_KEY` set on the **server**, images get a real Gemini vision diagnosis (the key never reaches the browser).
- `source: "none"` means *no confident match* — the reply advises contacting KVK / Kisan Call Centre 1551. **Never guess a disease.**
- Frontend fallback: offline keyword matcher + agronomy templates (all 3 languages).

### C. 🧮 Fertilizer Calculator — `POST /api/fertilizer/calculate`

```json
// Request
{ "crop": "paddy", "landArea": 2, "unit": "acre", "soilType": "laterite",
  "irrigation": "canal", "soilPh": 5.2, "lang": "or" }
// unit ∈ acre | guntha (÷40) | decimal (÷100) | hectare (×2.471) | bigha (×0.33)
// soilType ∈ alluvial | red | laterite (×1.15 boost) | black | sandy (×1.10 boost)

// Response (shape == the frontend's local result object)
{ "cropName": "ଧାନ (Paddy)", "acres": 2.0,
  "totalUrea": 4.6, "totalDap": 2.3, "totalMop": 1.8, "totalZinc": 20.0, "totalFym": 4.0,
  "yieldQty": 44.0, "estimatedRev": 101200.0, "mspPrice": 2300.0,
  "limingAdvice": "ମାଟି ଅତ୍ୟଧିକ ଅମ୍ଳୀୟ (pH 5.2)...",
  "basalUrea": 1.2, "basalDap": 2.3, "basalMop": 0.9,
  "tilleringUrea": 2.1, "floweringUrea": 1.4, "floweringMop": 0.9,
  "notes": { "basal": "...", "tillering": "...", "flowering": "..." } }
```
Frontend fallback: identical client-side calculation (keep the crop ratios in sync — they are seeded from `seed_json/`).

### D. 🏷️ Mandi Prices — `GET /api/mandi/prices?district=Bargarh&commodity=Paddy`

Array of entries shaped exactly like the bundled `src/data/mandiPrices.js` sample:
```json
{ "id": 1, "commodity": "Paddy (Common / Dhan)", "commodityOr": "ଧାନ (ସାଧାରଣ)", "commodityHi": "धान (सामान्य)",
  "variety": "Common Grade", "mandi": "Bargarh APMC", "district": "Bargarh",
  "marketPrice": 2360, "mspRate": 2300, "priceChange": 60, "trend": "up",
  "arrivalQty": "1,450 Quintals", "lastUpdated": "Today, 10:30 AM" }
```
Frontend fallback: bundled sample data (badge shows "Offline Sample Data").

### E. 🏛️ Government Schemes — `GET /api/schemes?category=financial`

Array shaped exactly like `src/data/schemes.js` entries (trilingual name/benefit/description, `eligibility` + `documentsNeeded` arrays, `badge`, `icon`, `helpline`, `officialUrl`). Frontend fallback: bundled data.

### F. 🤖 Krushi AI Chatbot — `POST /api/chatbot/ask`
```json
// Request                              // Response
{ "message": "...", "lang": "or",       { "reply": "...", "source": "ai" | "fallback" }
  "system": "optional persona text" }
```
Server-side Gemini (`GEMINI_API_KEY` in the backend `.env`); multilingual fallback reply when unset. Frontend fallback: offline agronomy engine.

### G. 📒 Farmer Ledger (Khata)
- `GET /api/ledger` → array of entries:
```json
{ "id": 1, "farmerId": "FID-00001" | null, "crop": "Swarna Paddy", "landArea": 2,
  "expenses": { "seed": 1600, "fertilizer": 4800, "labor": 7000, "machinery": 3500, "irrigation": 1200, "other": 800 },
  "totalExpenses": 18900, "expectedYield": 42, "sellingPrice": 2300,
  "grossRevenue": 96600, "netProfit": 77700, "created_at": "2026-09-01T10:00:00Z" }
```
- `POST /api/ledger/save` with `{ crop, landArea, expenses{...}, expectedYield, sellingPrice }` → created entry (201)
- `DELETE /api/ledger?id=1` → `{ "detail": "Deleted" }`

Frontend fallback: entries are always mirrored to `localStorage`, so nothing is lost when offline.

### H. 🔐 Auth (JWT)
- `POST /api/auth/register` `{username, password, phone, district?, village?, preferred_lang?}` → `{farmer, access, refresh}`
- `POST /api/auth/login` `{username, password}` → `{farmer, access, refresh}`
- Send `Authorization: Bearer <access>` on any endpoint to scope ledger reads/writes to the farmer.

---

## 🔑 3. Security Notes (important)

- **Never** put a Gemini/API key in frontend code — it ships to every visitor's browser. AI keys belong in the backend `.env` only.
- The ledger endpoints are open (`AllowAny`) for frictionless demos. For production, set `DEFAULT_PERMISSION_CLASSES` to `IsAuthenticated` (JWT endpoints are already implemented).
- Production checklist: `DJANGO_DEBUG=False`, real `DJANGO_SECRET_KEY`, explicit `DJANGO_ALLOWED_HOSTS`, and CORS pinned to your frontend origin.
