# Backend Integration Guide for Utkal Krushi (ଉତ୍କଳ କୃଷି)

Hi Backend Developer! 👋 
This frontend is built with **React 18 + Vite + Tailwind CSS**. All UI components, state handling, multilingual switching (Odia/Hindi/English), voice narration, and client-side calculators are already implemented and working.

You can connect your backend API (built with Node.js/Express, Python/FastAPI/Flask, Java/Spring Boot, PHP/Laravel, Go, etc.) to power the endpoints below.

---

## ⚙️ 1. Connecting Your Backend Server

In the frontend root directory, create a `.env` file (or edit `src/config/api.js`):
```env
VITE_API_BASE_URL=http://localhost:5000/api
```

---

## 📡 2. Expected API Endpoints & Payloads

### A. 🌦️ Weather & Agro-Advisory
- **Endpoint**: `GET /api/weather?district=Bhubaneswar` or `GET /api/weather?lat=20.29&lon=85.82`
- **Response Format**:
```json
{
  "location": "Bhubaneswar (Khordha)",
  "temperature": 29.5,
  "apparentTemperature": 32.1,
  "humidity": 78,
  "windSpeed": 11.2,
  "precipitation": 0.0,
  "weatherCode": 1,
  "sprayAdvisory": {
    "status": "safe",
    "message": "Safe to spray - Low wind & no rain expected"
  },
  "hourly": [
    { "time": "2:00 PM", "temp": 30.1, "rainProb": 10, "code": 1 },
    { "time": "3:00 PM", "temp": 29.8, "rainProb": 15, "code": 2 }
  ]
}
```

---

### B. 🌿 AI Crop Doctor & Diagnosis
- **Endpoint**: `POST /api/crop-doctor/diagnose`
- **Request (Multipart/Form-Data or JSON)**:
```json
{
  "symptoms": "Yellow spots on paddy leaf with brown borders",
  "imageBase64": "data:image/jpeg;base64,...",
  "lang": "or"
}
```
- **Response Format**:
```json
{
  "diseaseName": "Rice Blast (Pyricularia oryzae)",
  "diseaseNameOr": "ଧାନ ବ୍ଲାଷ୍ଟ ରୋଗ (ପତ୍ର ପୋଡ଼ା)",
  "severity": "High",
  "symptoms": "Spindle-shaped lesions with grey center and dark brown margins.",
  "organicRemedy": "Spray 10% cow urine + Neem seed kernel extract (5%).",
  "chemicalTreatment": "Spray Tricyclazole 75% WP @ 0.6g/L of water.",
  "preventiveTips": "Avoid excess urea; treat seeds before sowing."
}
```

---

### C. 🧮 Fertilizer & Yield Calculator
- **Endpoint**: `POST /api/fertilizer/calculate`
- **Request**:
```json
{
  "crop": "paddy",
  "landArea": 2.5,
  "unit": "acre",
  "soilType": "alluvial",
  "soilPh": 6.2
}
```
- **Response Format**:
```json
{
  "cropName": "Swarna Paddy (ଧାନ)",
  "acres": 2.5,
  "expectedYieldQuintals": 55,
  "estimatedRevenue": 126500,
  "bagsRequired": {
    "urea": 5.0,
    "dap": 2.5,
    "mop": 2.0,
    "zincKg": 25,
    "organicFymTons": 5
  },
  "schedule": {
    "basal": "Apply 2.5 bags DAP + 1 bag MOP + 1.25 bags Urea at planting.",
    "tillering": "Top dress 2.25 bags Urea at 25 DAS.",
    "flowering": "Top dress 1.5 bags Urea + 1 bag MOP at panicle initiation."
  },
  "soilPhAdvice": "Normal pH. No special liming needed."
}
```

---

### D. 📈 Mandi Market Rates & MSP
- **Endpoint**: `GET /api/mandi/prices?district=Bargarh&commodity=Paddy`
- **Response Format**:
```json
[
  {
    "id": 1,
    "commodity": "Paddy (Common / Dhan)",
    "commodityOr": "ଧାନ (ସାଧାରଣ)",
    "mandi": "Bargarh APMC",
    "district": "Bargarh",
    "marketPrice": 2360,
    "mspRate": 2300,
    "priceChange": 60,
    "trend": "up",
    "arrivalQty": "1,450 Quintals"
  }
]
```

---

### E. 🏛️ Government Schemes & Subsidies
- **Endpoint**: `GET /api/schemes?category=all`
- **Response Format**:
```json
[
  {
    "id": "kalia-scheme",
    "name": "KALIA Scheme",
    "nameOr": "କାଳିଆ ଯୋଜନା",
    "govType": "odisha",
    "subsidyBenefit": "₹10,000 per year per farm family",
    "eligibility": ["Small and marginal farmers of Odisha", "Landless laborers"],
    "documentsNeeded": ["Aadhaar Card", "Bank Passbook", "Land Patta (RoR)"],
    "officialUrl": "https://kaliaportal.odisha.gov.in/"
  }
]
```

---

### F. 🤖 Krushi AI Chatbot
- **Endpoint**: `POST /api/chatbot/ask`
- **Request**:
```json
{
  "message": "What is the best pesticide for stem borer in paddy?",
  "lang": "or"
}
```
- **Response Format**:
```json
{
  "reply": "ଧାନରେ କାଣ୍ଡ ବିନ୍ଧା ପୋକ ନିୟନ୍ତ୍ରଣ ପାଇଁ କ୍ଲୋରାନଟ୍ରାନିଲିପ୍ରୋଲ୍ (Ferterra) ୪ କେଜି ପ୍ରତି ଏକର ଜମିରେ ପ୍ରୟୋଗ କରନ୍ତୁ।"
}
```

---

### G. 🧾 Farmer Ledger (Khata) Records
- **Endpoint**: `POST /api/ledger/save` & `GET /api/ledger`
- **Request**:
```json
{
  "farmerId": "FID-10293",
  "crop": "Swarna Paddy",
  "landArea": 2.0,
  "expenses": {
    "seed": 1600,
    "fertilizer": 4800,
    "labor": 7000,
    "machinery": 3500,
    "irrigation": 1200,
    "other": 800
  },
  "totalExpenses": 18900,
  "expectedYield": 42,
  "sellingPrice": 2300,
  "grossRevenue": 96600,
  "netProfit": 77700
}
```

---

## 🛠️ How to Run the Frontend Locally

1. Install dependencies:
   ```bash
   npm install
   ```
2. Start the Vite development server:
   ```bash
   npm run dev
   ```
3. Build for production:
   ```bash
   npm run build
   ```
   The production-ready static assets will be output in the `dist/` directory.
