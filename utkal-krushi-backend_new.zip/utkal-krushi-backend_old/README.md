# Utkal Krushi — Django Backend

A Django + Django REST Framework backend that implements every endpoint listed in the
frontend's `BACKEND_API_GUIDE.md` / `src/config/api.js`, so the React app can be pointed
at it with **zero frontend code changes**.

## Apps → Endpoints

| App          | Endpoint                              | Notes |
|--------------|----------------------------------------|-------|
| `accounts`   | `POST /api/auth/register`, `POST /api/auth/login` | Custom `Farmer` user model, JWT tokens (SimpleJWT) |
| `weather`    | `GET /api/weather?district=..`        | Proxies the free [Open-Meteo](https://open-meteo.com) API — no key needed |
| `cropdoctor` | `POST /api/crop-doctor/diagnose`      | Server-side Gemini **vision** when `GEMINI_API_KEY` is set, else trilingual rule-based match on the `CropDisease` knowledge base; honest "no confident match" advisory instead of guessing |
| `fertilizer` | `POST /api/fertilizer/calculate`      | Per-crop NPK/yield calculator, scaled by land area |
| `mandi`      | `GET /api/mandi/prices?district=..&commodity=..` | `MandiPrice` model, filterable |
| `schemes`    | `GET /api/schemes?category=..`        | `Scheme` model |
| `chatbot`    | `POST /api/chatbot/ask`               | Falls back to a canned multilingual reply; forwards to Gemini if `GEMINI_API_KEY` is set |
| `ledger`     | `GET /api/ledger`, `POST /api/ledger/save`, `DELETE /api/ledger?id=..` | Farmer expense/profit khata, tied to the logged-in user if a JWT is sent |

## 1. Setup

```bash
cd utkal-krushi-backend
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env            # edit if needed (defaults work for local dev)

python manage.py migrate
python manage.py seed_data      # loads demo diseases, fertilizer profiles, mandi prices, schemes
python manage.py createsuperuser  # optional, to use /admin

python manage.py runserver 0.0.0.0:8000
```

The API is now live at `http://localhost:8000/api/...`. The React app needs **no extra
configuration**: its dev server proxies `/api/*` to this port automatically (see the
frontend's `vite.config.js`).

## 2. Connect the React frontend

Then `npm run dev` in the frontend as usual — no `.env` needed for local development
(relative `/api` paths are proxied). If you host frontend and API on different origins,
set `VITE_API_BASE_URL` in the frontend `.env` and pin `CORS_ALLOWED_ORIGINS` here.

## 3. Data model choices

- **SQLite** by default (zero setup). Swap `DATABASES` in `config/settings.py` for
  Postgres/MySQL when you deploy — nothing else changes.
- Canonical demo content (7 trilingual diseases + powdery mildew, 7 fertilizer crops,
  14 mandi entries, 8 schemes) lives in **`seed_json/*.json`** — ported 1:1 from the
  frontend's bundled data files so API responses and offline fallbacks never drift.
  `seed_data.py` merges the JSON with backend-only extras; manage records via Django
  admin at `/admin/` to add real data.
- `Farmer` (in `accounts`) replaces Django's default `User` and carries phone/district/
  village/preferred language/land area, since the frontend is farmer-facing.

## 4. Plugging in a real AI model (optional)

Both AI endpoints already call **Gemini server-side** when you set `GEMINI_API_KEY`
in `.env` (free key: https://aistudio.google.com/apikey) — get real photo-based crop
diagnosis and chatbot answers, and the API key never reaches the browser:

- **Crop Doctor** (`cropdoctor/views.py`): with a key, attached photos go to Gemini
  vision (`GEMINI_MODEL`, default `gemini-2.5-flash`). Without a key (or if the call
  fails), it falls back to the rule-based trilingual keyword match — and if nothing
  matches confidently it returns an honest KVK / Kisan-1551 advisory instead of a
  guessed disease.
- **Chatbot** (`chatbot/views.py`): forwards messages to Gemini with an Odisha-agriculture
  system prompt; without a key it returns a friendly fallback message.

## 5. Auth notes

`POST /api/auth/register` and `/login` return `{ access, refresh }` JWTs. Have the
frontend send `Authorization: Bearer <access>` on requests (e.g. to `/api/ledger`) so
entries are tied to the right farmer. Every endpoint currently allows anonymous access
too (`AllowAny`) so the app still works before you wire up a login screen — tighten
`REST_FRAMEWORK["DEFAULT_PERMISSION_CLASSES"]` / add `permission_classes` per-view once
you're ready to require login.

## 6. Tested

All endpoints were smoke-tested end-to-end with `curl` against `runserver`, including
the live Open-Meteo weather proxy, the fertilizer math for every land unit
(acre/guntha/decimal/hectare/bigha), Odia keyword diagnosis, ledger save/list/delete,
and JWT registration.

## 7. Production checklist

- Set a real `DJANGO_SECRET_KEY`, `DJANGO_DEBUG=False`, and explicit `DJANGO_ALLOWED_HOSTS`.
- Point `DATABASES` at Postgres.
- Run behind Gunicorn/Uvicorn + Nginx (not `runserver`).
- Restrict `CORS_ALLOWED_ORIGINS` to your real frontend domain.
