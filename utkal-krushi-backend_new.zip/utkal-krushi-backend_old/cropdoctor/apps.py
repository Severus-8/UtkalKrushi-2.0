from django.apps import AppConfig


class CropdoctorConfig(AppConfig):
    name = 'cropdoctor'
