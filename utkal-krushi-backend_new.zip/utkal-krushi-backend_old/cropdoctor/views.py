"""
POST /api/crop-doctor/diagnose

1. If a GEMINI_API_KEY is configured and an image is attached -> real AI
   vision diagnosis, server-side (the key never reaches the browser).
2. Otherwise -> rule-based keyword match against the knowledge base.
3. If nothing matches confidently -> an honest "no confident match"
   advisory pointing to KVK / Kisan Call Centre (never a guessed disease).
"""
import base64

import requests
from django.conf import settings
from rest_framework.decorators import api_view
from rest_framework.response import Response

from .models import CropDisease
from .serializers import CropDiseaseResultSerializer

NO_MATCH_ADVISORY = {
    "or": "🌿 **ନିରୂପଣ ନିଶ୍ଚିତ ହୋଇପାରିଲା ନାହିଁ**\n- ଆପଣ ବର୍ଣ୍ଣନା କରିଥିବା ଲକ୍ଷଣ ଆମ ଜ୍ଞାନ-ଭଣ୍ଡାରର କୌଣସି ରୋଗ ସହିତ ଦୃଢ଼ ଭାବରେ ମେଳ ଖାଉନାହିଁ।\n- ଭୁଲ ଔଷଧ ସିଞ୍ଚନ କରିବା ପରିବର୍ତ୍ତେ ଦୟାକରି ନିକଟସ୍ଥ କୃଷି ବିଜ୍ଞାନ କେନ୍ଦ୍ର (KVK) କିମ୍ବା କିଷାନ କଲ୍ ସେଣ୍ଟର **1551** ସହିତ ଯୋଗାଯୋଗ କରନ୍ତୁ।\n- ପତ୍ରର ସ୍ପଷ୍ଟ ଫଟୋ ଅପଲୋଡ୍ କରି ପୁଣି ଚେଷ୍ଟା କରନ୍ତୁ।",
    "hi": "🌿 **निदान पुष्ट नहीं हो सका**\n- आपके बताए लक्षण हमारे ज्ञान-कोष के किसी रोग से दृढ़ता से मेल नहीं खा रहे हैं।\n- गलत दवा छिड़काव से बचने के लिए कृपया नजदीकी कृषि विज्ञान केंद्र (KVK) या किसान कॉल सेंटर **1551** से संपर्क करें।\n- पत्ती की साफ फोटो अपलोड करके दोबारा कोशिश करें।",
    "en": "🌿 **No Confident Diagnosis**\n- The symptoms you described do not strongly match any disease in our knowledge base.\n- To avoid spraying the wrong chemical, please contact your nearest Krishi Vigyan Kendra (KVK) or the Kisan Call Centre at **1551**.\n- You can also upload a clear photo of the affected leaf and try again.",
}

GEMINI_PROMPT = (
    "Act as an expert agricultural pathologist for Odisha, India. Analyze this crop image "
    "and the farmer's symptom description and reply in short markdown bullet points:\n"
    "1. Identified Disease/Pest Name\n2. Severity (Mild / Moderate / Severe)\n"
    "3. Organic / Biological Treatment (Neem, Trichoderma, etc.)\n"
    "4. Recommended Chemical Spray with exact dosage per liter\n5. Prevention Tips.\n"
    "Always add a final line advising to confirm with the local KVK or Kisan Call Centre 1551.\n"
    "Language: {lang_req}\nSymptoms: {symptoms}"
)

LANG_REQ = {
    "or": "Answer purely in Odia (ଓଡ଼ିଆ) script",
    "hi": "Answer in simple Hindi (हिंदी)",
    "en": "Answer in simple English",
}


def _gemini_vision_diagnose(symptoms, image_base64, lang):
    """Server-side Gemini vision call. Returns reply text or None on any failure."""
    if not settings.GEMINI_API_KEY:
        return None
    # Accept both raw base64 and data-URI prefixed input.
    if "," in image_base64 and image_base64.strip().startswith("data:"):
        image_base64 = image_base64.split(",", 1)[1]
    try:
        base64.b64decode(image_base64, validate=True)
    except Exception:
        return None

    model = getattr(settings, "GEMINI_MODEL", "gemini-2.5-flash")
    prompt = GEMINI_PROMPT.format(lang_req=LANG_REQ.get(lang, LANG_REQ["en"]), symptoms=symptoms or "-")
    try:
        resp = requests.post(
            f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
            params={"key": settings.GEMINI_API_KEY},
            json={"contents": [{"parts": [
                {"text": prompt},
                {"inlineData": {"mimeType": "image/jpeg", "data": image_base64}},
            ]}]},
            timeout=25,
        )
        resp.raise_for_status()
        return resp.json()["candidates"][0]["content"]["parts"][0]["text"].strip()
    except (requests.RequestException, KeyError, IndexError, ValueError):
        return None


def _rule_based_diagnose(symptoms_text):
    """Keyword-overlap scoring. Returns (disease, score); score 0 = no match."""
    text = symptoms_text.lower()
    best, best_score = None, 0
    for disease in CropDisease.objects.all():
        keywords = [k.strip().lower() for k in disease.symptom_keywords.split(",") if k.strip()]
        score = sum(1 for kw in keywords if kw and kw in text)
        if score > best_score:
            best, best_score = disease, score
    return best, best_score


def _format_reply(disease, lang):
    """Markdown report in the requested language (falls back to English content)."""
    if lang == "or":
        return (
            f"🌿 **ରୋଗ ନିରୂପଣ: {disease.name_or or disease.name}**\n"
            f"- **ଫସଲ:** {disease.crop}\n- **ଗମ୍ଭୀରତା:** {disease.severity}\n"
            f"- **ଲକ୍ଷଣ:** {disease.symptoms_or or disease.symptoms}\n"
            f"- **ଜୈବିକ ପ୍ରତିକାର:** {disease.organic_remedy_or or disease.organic_remedy}\n"
            f"- **ରାସାୟନିକ ଔଷଧ:** {disease.chemical_treatment_or or disease.chemical_treatment}\n"
            f"- **ସତର୍କତା:** {disease.preventive_tips_or or disease.preventive_tips}\n"
            f"- _ନିଶ୍ଚିତ ପାଇଁ ନିକଟସ୍ଥ KVK କିମ୍ବା କିଷାନ କଲ୍ ସେଣ୍ଟର ୧୫୫୧ ସହିତ ଯୋଗାଯୋଗ କରନ୍ତୁ।_"
        )
    if lang == "hi":
        return (
            f"🌿 **रोग निदान: {disease.name_hi or disease.name}**\n"
            f"- **फसल:** {disease.crop}\n- **गंभीरता:** {disease.severity}\n"
            f"- **लक्षण:** {disease.symptoms_hi or disease.symptoms}\n"
            f"- **जैविक उपचार:** {disease.organic_remedy}\n"
            f"- **रासायनिक उपचार:** {disease.chemical_treatment}\n"
            f"- **सावधानी:** {disease.preventive_tips}\n"
            f"- _पुष्टि के लिए नजदीकी KVK या किसान कॉल सेंटर 1551 से संपर्क करें।_"
        )
    return (
        f"🌿 **Diagnosis: {disease.name}**\n"
        f"- **Crop:** {disease.crop}\n- **Severity:** {disease.severity}\n"
        f"- **Symptoms:** {disease.symptoms}\n"
        f"- **Organic Remedy:** {disease.organic_remedy}\n"
        f"- **Chemical Control:** {disease.chemical_treatment}\n"
        f"- **Prevention:** {disease.preventive_tips}\n"
        f"- _Confirm with your nearest KVK or the Kisan Call Centre 1551 before spraying._"
    )


@api_view(["POST"])
def diagnose_view(request):
    """
    Body: {"symptoms": "...", "imageBase64": "...", "lang": "or"}
    Response: {"source": "ai" | "knowledge-base" | "none", "reply": "<markdown>",
               "match": {...} | null, "matchScore": int}
    """
    symptoms_text = (request.data.get("symptoms") or "").strip()
    image_base64 = request.data.get("imageBase64") or None
    lang = (request.data.get("lang") or "en").lower()

    if not symptoms_text and not image_base64:
        return Response({"detail": "Please describe the symptoms or upload a photo."}, status=400)

    # 1) Real AI vision (server-side, key stays on the server)
    if image_base64:
        reply = _gemini_vision_diagnose(symptoms_text, image_base64, lang)
        if reply:
            return Response({"source": "ai", "reply": reply, "match": None, "matchScore": None})

    if not symptoms_text:
        return Response({"detail": "Please describe the symptoms you observed."}, status=400)

    # 2) Rule-based knowledge-base match (Odia/Hindi keyword lists included)
    disease, score = _rule_based_diagnose(symptoms_text)
    if disease is None or score == 0:
        # 3) Honest "no confident match" advisory - never guess a disease.
        return Response({
            "source": "none",
            "reply": NO_MATCH_ADVISORY.get(lang, NO_MATCH_ADVISORY["en"]),
            "match": None, "matchScore": 0,
        })

    return Response({
        "source": "knowledge-base",
        "reply": _format_reply(disease, lang),
        "match": CropDiseaseResultSerializer(disease).data,
        "matchScore": score,
    })
