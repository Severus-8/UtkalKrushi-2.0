from django.contrib import admin
from .models import CropDisease

admin.site.register(CropDisease)
