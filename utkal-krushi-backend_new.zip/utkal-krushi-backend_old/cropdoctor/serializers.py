from rest_framework import serializers
from .models import CropDisease


class CropDiseaseResultSerializer(serializers.ModelSerializer):
    """Full trilingual knowledge-base entry, camelCase for the frontend."""
    diseaseName = serializers.CharField(source="name")
    diseaseNameOr = serializers.CharField(source="name_or")
    diseaseNameHi = serializers.CharField(source="name_hi")
    severityColor = serializers.CharField(source="severity_color")
    symptomsOr = serializers.CharField(source="symptoms_or")
    symptomsHi = serializers.CharField(source="symptoms_hi")
    organicRemedy = serializers.CharField(source="organic_remedy")
    organicRemedyOr = serializers.CharField(source="organic_remedy_or")
    chemicalTreatment = serializers.CharField(source="chemical_treatment")
    chemicalTreatmentOr = serializers.CharField(source="chemical_treatment_or")
    preventiveTips = serializers.CharField(source="preventive_tips")
    preventiveTipsOr = serializers.CharField(source="preventive_tips_or")
    imageUrl = serializers.URLField(source="image_url")

    class Meta:
        model = CropDisease
        fields = [
            "disease_id", "crop", "diseaseName", "diseaseNameOr", "diseaseNameHi",
            "severity", "severityColor", "symptoms", "symptomsOr", "symptomsHi",
            "organicRemedy", "organicRemedyOr", "chemicalTreatment", "chemicalTreatmentOr",
            "preventiveTips", "preventiveTipsOr", "imageUrl",
        ]
