from django.db import models


class CropDisease(models.Model):
    """Reference knowledge-base entry used by the Crop Doctor."""
    disease_id = models.SlugField(unique=True)
    name = models.CharField(max_length=200)
    name_or = models.CharField("Name (Odia)", max_length=200, blank=True)
    name_hi = models.CharField("Name (Hindi)", max_length=200, blank=True)
    crop = models.CharField(max_length=100)
    severity = models.CharField(
        max_length=20,
        choices=[("Low", "Low"), ("Medium", "Medium"), ("High", "High"), ("Critical", "Critical")],
    )
    severity_color = models.CharField("Tailwind severity classes", max_length=100, blank=True)
    symptom_keywords = models.TextField(
        help_text="Comma-separated keywords matched against the farmer's symptom description."
    )
    symptoms = models.TextField()
    symptoms_or = models.TextField(blank=True)
    symptoms_hi = models.TextField(blank=True)
    organic_remedy = models.TextField()
    organic_remedy_or = models.TextField(blank=True)
    chemical_treatment = models.TextField()
    chemical_treatment_or = models.TextField(blank=True)
    preventive_tips = models.TextField()
    preventive_tips_or = models.TextField(blank=True)
    image_url = models.URLField(blank=True)

    def __str__(self):
        return self.name
