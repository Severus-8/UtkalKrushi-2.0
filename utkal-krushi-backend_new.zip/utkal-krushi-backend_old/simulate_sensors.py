import time
import random
import requests

API_URL = "http://localhost:8000/api/sensors/ingest/"
DEVICES = [
    {"device_id": "SENSOR-MOIST-01", "base": 64.0, "unit": "%", "jitter": 2.5},
    {"device_id": "SENSOR-PH-01",    "base": 6.7,  "unit": "pH", "jitter": 0.15},
]

print("📡 Field Telemetry simulator running. Pushing readings to:", API_URL)
while True:
    for dev in DEVICES:
        val = round(dev["base"] + random.uniform(-dev["jitter"], dev["jitter"]), 2)
        try:
            r = requests.post(API_URL, json={"device_id": dev["device_id"], "value": val, "unit": dev["unit"]}, timeout=3)
            print(f"[{dev['device_id']}] Sent: {val} {dev['unit']} -> Status {r.status_code}")
        except Exception as e:
            print(f"Telemetry error: {e}")
        time.sleep(1)
    time.sleep(4)
