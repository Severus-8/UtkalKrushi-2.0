from django.db import models


class MandiPrice(models.Model):
    commodity = models.CharField(max_length=200)
    commodity_or = models.CharField("Commodity (Odia)", max_length=200, blank=True)
    commodity_hi = models.CharField("Commodity (Hindi)", max_length=200, blank=True)
    variety = models.CharField(max_length=200, blank=True)
    mandi = models.CharField(max_length=200)
    district = models.CharField(max_length=100)
    market_price = models.DecimalField(max_digits=8, decimal_places=2)
    msp_rate = models.DecimalField(max_digits=8, decimal_places=2)
    price_change = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    trend = models.CharField(max_length=10, choices=[("up", "up"), ("down", "down"), ("flat", "flat")])
    arrival_qty = models.CharField(max_length=100, blank=True)
    last_updated = models.CharField(max_length=100, blank=True,
        help_text="Human-friendly label, e.g. 'Today, 10:30 AM'.")
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.commodity} @ {self.mandi}"
