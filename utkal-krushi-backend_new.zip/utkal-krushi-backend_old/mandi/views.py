from rest_framework.decorators import api_view
from rest_framework.response import Response

from .models import MandiPrice
from .serializers import MandiPriceSerializer


@api_view(["GET"])
def mandi_prices_view(request):
    """GET /api/mandi/prices?district=Bargarh&commodity=Paddy"""
    qs = MandiPrice.objects.all()
    district = request.GET.get("district")
    commodity = request.GET.get("commodity")
    if district:
        qs = qs.filter(district__icontains=district)
    if commodity:
        qs = qs.filter(commodity__icontains=commodity)
    return Response(MandiPriceSerializer(qs, many=True).data)
