from rest_framework import serializers
from .models import MandiPrice


class MandiPriceSerializer(serializers.ModelSerializer):
    """Shape mirrors the frontend's static `mandiData` entries exactly."""
    id = serializers.IntegerField()
    commodityOr = serializers.CharField(source="commodity_or")
    commodityHi = serializers.CharField(source="commodity_hi")
    variety = serializers.CharField()
    marketPrice = serializers.DecimalField(source="market_price", max_digits=8, decimal_places=2)
    mspRate = serializers.DecimalField(source="msp_rate", max_digits=8, decimal_places=2)
    priceChange = serializers.DecimalField(source="price_change", max_digits=8, decimal_places=2)
    arrivalQty = serializers.CharField(source="arrival_qty")
    lastUpdated = serializers.CharField(source="last_updated")

    class Meta:
        model = MandiPrice
        fields = [
            "id", "commodity", "commodityOr", "commodityHi", "variety", "mandi",
            "district", "marketPrice", "mspRate", "priceChange", "trend",
            "arrivalQty", "lastUpdated",
        ]
