from django.contrib import admin
from .models import MandiPrice

admin.site.register(MandiPrice)
