import requests
from django.conf import settings
from rest_framework.decorators import api_view
from rest_framework.response import Response

FALLBACK_REPLIES = {
    "or": "କ୍ଷମା କରନ୍ତୁ, ମୁଁ ଏହି ପ୍ରଶ୍ନର ନିର୍ଦ୍ଦିଷ୍ଟ ଉତ୍ତର ଦେଇପାରିବି ନାହିଁ। ଦୟାକରି ଆପଣଙ୍କ ନିକଟସ୍ଥ କୃଷି ବିଭାଗ କିମ୍ବା KISAN CALL CENTRE (1800-180-1551) ସହିତ ଯୋଗାଯୋଗ କରନ୍ତୁ।",
    "hi": "क्षमा करें, मैं इस प्रश्न का सटीक उत्तर नहीं दे पा रहा। कृपया अपने नज़दीकी कृषि कार्यालय या किसान कॉल सेंटर (1800-180-1551) से संपर्क करें।",
    "en": "Sorry, I don't have a confident answer for that yet. Please contact your local agriculture office or the Kisan Call Centre (1800-180-1551).",
}

BASE_SYSTEM_PROMPT = (
    "You are Krushi AI, an expert assistant for Odisha farmers. "
    "Answer concisely, practically and in a farmer-friendly tone."
)

LANGUAGE_INSTRUCTIONS = {
    "or": "Answer purely in Odia (ଓଡ଼ିଆ) script with simple, short sentences.",
    "hi": "Answer in simple Hindi (हिंदी) with step-by-step points.",
    "en": "Answer in simple English with step-by-step points.",
}


@api_view(["POST"])
def chatbot_view(request):
    """
    POST /api/chatbot/ask   {"message": "...", "lang": "or", "system": "optional extra persona"}

    If GEMINI_API_KEY is set in .env, forwards the question to Gemini with an
    Odisha-agriculture system prompt (the key never leaves the server).
    Otherwise returns a friendly fallback reply so the endpoint works out of the box.
    """
    message = (request.data.get("message") or "").strip()
    lang = (request.data.get("lang") or "en").lower()
    system = (request.data.get("system") or "").strip()
    if not message:
        return Response({"detail": "message is required"}, status=400)

    if settings.GEMINI_API_KEY:
        system_prompt = " ".join(x for x in [BASE_SYSTEM_PROMPT, system,
                                             LANGUAGE_INSTRUCTIONS.get(lang)] if x)
        model = getattr(settings, "GEMINI_MODEL", "gemini-2.5-flash")
        try:
            resp = requests.post(
                f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
                params={"key": settings.GEMINI_API_KEY},
                json={
                    "contents": [{"parts": [{"text": f"{system_prompt}\n\nQuestion: {message}"}]}],
                    "generationConfig": {"temperature": 0.4, "maxOutputTokens": 1000},
                },
                timeout=20,
            )
            resp.raise_for_status()
            data = resp.json()
            reply = data["candidates"][0]["content"]["parts"][0]["text"]
            return Response({"reply": reply.strip(), "source": "ai"})
        except (requests.RequestException, KeyError, IndexError):
            pass  # fall through to the fallback reply below

    return Response({"reply": FALLBACK_REPLIES.get(lang, FALLBACK_REPLIES["en"]), "source": "fallback"})
