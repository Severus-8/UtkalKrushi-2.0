# Single endpoint; wired directly in config/urls.py.
