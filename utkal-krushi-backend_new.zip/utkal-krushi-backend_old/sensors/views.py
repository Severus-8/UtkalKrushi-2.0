from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework import status
from .models import SensorDevice, SensorReading
from .serializers import SensorDeviceSerializer, SensorReadingSerializer, IngestReadingSerializer

@api_view(["GET", "POST"])
@permission_classes([AllowAny])
def device_list(request):
    if request.method == "GET":
        devices = SensorDevice.objects.all()
        return Response(SensorDeviceSerializer(devices, many=True).data)
    
    serializer = SensorDeviceSerializer(data=request.data)
    if serializer.is_valid():
        user = request.user if request.user.is_authenticated else None
        serializer.save(farmer=user)
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(["POST"])
@permission_classes([AllowAny])
def ingest_reading(request):
    ser = IngestReadingSerializer(data=request.data)
    if not ser.is_valid():
        return Response(ser.errors, status=status.HTTP_400_BAD_REQUEST)

    device_id = ser.validated_data["device_id"]
    device, _ = SensorDevice.objects.get_or_create(
        device_id=device_id,
        defaults={"sensor_type": "moisture" if "%" in ser.validated_data.get("unit","%") else "ph", "field_name": "Demo Field"}
    )

    reading = SensorReading.objects.create(
        device=device,
        value=ser.validated_data["value"],
        unit=ser.validated_data.get("unit", "%")
    )
    return Response(SensorReadingSerializer(reading).data, status=status.HTTP_201_CREATED)

@api_view(["GET"])
@permission_classes([AllowAny])
def latest_readings(request):
    devices = SensorDevice.objects.filter(is_active=True)
    result = {}
    for device in devices:
        latest = device.readings.first()
        if latest:
            result[device.sensor_type] = {
                "value": latest.value,
                "unit": latest.unit,
                "timestamp": latest.timestamp,
                "device_id": device.device_id,
            }
    return Response(result)

@api_view(["GET"])
@permission_classes([AllowAny])
def reading_history(request, device_id):
    limit = int(request.query_params.get("limit", 24))
    try:
        device = SensorDevice.objects.get(device_id=device_id)
    except SensorDevice.DoesNotExist:
        return Response({"error": "Device not found"}, status=404)
    readings = device.readings.all()[:limit]
    return Response(SensorReadingSerializer(readings, many=True).data)
