from django.db import models
from django.conf import settings

class SensorDevice(models.Model):
    SENSOR_TYPES = [
        ("moisture", "Soil Moisture"),
        ("ph", "Soil pH"),
        ("temperature", "Temperature"),
        ("humidity", "Air Humidity"),
    ]

    farmer = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="sensor_devices",
        null=True, blank=True
    )
    device_id = models.CharField(max_length=64, unique=True)
    sensor_type = models.CharField(max_length=20, choices=SENSOR_TYPES)
    field_name = models.CharField(max_length=100, default="Main Field")
    district = models.CharField(max_length=50, blank=True)
    is_active = models.BooleanField(default=True)
    registered_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-registered_at"]

    def __str__(self):
        return f"{self.device_id} ({self.sensor_type})"

class SensorReading(models.Model):
    device = models.ForeignKey(SensorDevice, on_delete=models.CASCADE, related_name="readings")
    value = models.FloatField()
    unit = models.CharField(max_length=10, default="%")
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-timestamp"]
