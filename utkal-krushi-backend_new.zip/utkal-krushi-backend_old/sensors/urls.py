from django.urls import path
from . import views

urlpatterns = [
    path("devices/", views.device_list, name="sensor-devices"),
    path("ingest/", views.ingest_reading, name="sensor-ingest"),
    path("latest/", views.latest_readings, name="sensor-latest"),
    path("history/<str:device_id>/", views.reading_history, name="sensor-history"),
]
