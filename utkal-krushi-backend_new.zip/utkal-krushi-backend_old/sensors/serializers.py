from rest_framework import serializers
from .models import SensorDevice, SensorReading

class SensorReadingSerializer(serializers.ModelSerializer):
    class Meta:
        model = SensorReading
        fields = ["id", "value", "unit", "timestamp"]

class SensorDeviceSerializer(serializers.ModelSerializer):
    latest_reading = serializers.SerializerMethodField()
    readings_count = serializers.IntegerField(source="readings.count", read_only=True)

    class Meta:
        model = SensorDevice
        fields = ["id", "device_id", "sensor_type", "field_name", "district", "is_active", "registered_at", "latest_reading", "readings_count"]

    def get_latest_reading(self, obj):
        latest = obj.readings.first()
        return SensorReadingSerializer(latest).data if latest else None

class IngestReadingSerializer(serializers.Serializer):
    device_id = serializers.CharField()
    value = serializers.FloatField()
    unit = serializers.CharField(default="%")
