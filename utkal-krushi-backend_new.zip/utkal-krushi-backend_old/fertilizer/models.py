from django.db import models


class CropFertilizerProfile(models.Model):
    """Per-crop baseline used by the fertilizer/yield calculator (per acre)."""

    crop_id = models.SlugField(unique=True)            # e.g. "paddy"
    crop_name = models.CharField(max_length=200)       # e.g. "Swarna Paddy (ଧାନ)"
    crop_name_or = models.CharField("Crop name (Odia)", max_length=200, blank=True)
    crop_name_hi = models.CharField("Crop name (Hindi)", max_length=200, blank=True)

    yield_qtl_per_acre = models.DecimalField(max_digits=6, decimal_places=2)
    price_per_qtl = models.DecimalField(max_digits=8, decimal_places=2)  # MSP / market rate
    urea_bags_per_acre = models.DecimalField(max_digits=5, decimal_places=2)
    dap_bags_per_acre = models.DecimalField(max_digits=5, decimal_places=2)
    mop_bags_per_acre = models.DecimalField(max_digits=5, decimal_places=2)
    zinc_kg_per_acre = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    fym_tons_per_acre = models.DecimalField(max_digits=5, decimal_places=2, default=0)

    # Split ratios per application phase (fractions of the total dose).
    basal_ratio = models.JSONField(default=dict, blank=True,
        help_text='e.g. {"urea": 0.25, "dap": 1.0, "mop": 0.5, "zinc": 1.0}')
    tillering_ratio = models.JSONField(default=dict, blank=True,
        help_text='e.g. {"urea": 0.45, "dap": 0, "mop": 0, "zinc": 0}')
    flowering_ratio = models.JSONField(default=dict, blank=True,
        help_text='e.g. {"urea": 0.30, "dap": 0, "mop": 0.5, "zinc": 0}')

    # Fertility-correction multipliers for nutrient doses on problem soils.
    soil_boost_laterite = models.DecimalField(max_digits=4, decimal_places=2, default=1.15)
    soil_boost_sandy = models.DecimalField(max_digits=4, decimal_places=2, default=1.10)

    basal_note = models.TextField(blank=True)
    tillering_note = models.TextField(blank=True)
    flowering_note = models.TextField(blank=True)

    def __str__(self):
        return self.crop_name
