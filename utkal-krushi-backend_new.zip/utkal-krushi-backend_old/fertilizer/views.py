"""
POST /api/fertilizer/calculate

Server-side port of the frontend calculator logic (FertilizerCalculator.jsx)
so the app can use either the API or the identical client-side fallback:

  - Land units: acre, guntha (1/40), decimal (1/100), hectare (x2.471), bigha (x0.33)
  - Soil fertility boost: laterite x1.15, sandy x1.10 (per profile)
  - 3-phase application schedule from per-crop split ratios
  - pH-based liming advice, localized (en / or / hi)
"""
from decimal import Decimal, ROUND_HALF_UP

from rest_framework.decorators import api_view
from rest_framework.response import Response

from .models import CropFertilizerProfile

# Conversion factor: input unit -> acres (matches the frontend exactly)
ACRE_PER_UNIT = {
    "acre": Decimal("1"),
    "guntha": Decimal("1") / Decimal("40"),
    "decimal": Decimal("1") / Decimal("100"),
    "hectare": Decimal("2.471"),
    "bigha": Decimal("0.33"),
}

SOIL_MULTIPLIERS = {"laterite": "soil_boost_laterite", "sandy": "soil_boost_sandy"}

LIMING_ADVICE = {
    "normal": {
        "en": "Soil pH is in normal range (6.0 - 7.5). No special amendment required.",
        "or": "ମାଟି pH ସାଧାରଣ ପରିସରରେ (୬.୦ - ୭.୫) ଅଛି। କୌଣସି ବିଶେଷ ସଂଶୋଧନ ଆବଶ୍ୟକ ନାହିଁ।",
        "hi": "मिट्टी का pH सामान्य सीमा (6.0 - 7.5) में है। किसी विशेष सुधार की आवश्यकता नहीं है।",
    },
    "acidic": {
        "en": "Soil is strongly acidic (pH {ph}). Apply 200 - 300 kg Agricultural Lime (Chuna) or Dolomite per acre 15 days before sowing to correct soil acidity and enhance phosphorus uptake.",
        "or": "ମାଟି ଅତ୍ୟଧିକ ଅମ୍ଳୀୟ (pH {ph}) ଅଟେ। ବୁଣିବାର ୧୫ ଦିନ ପୂର୍ବରୁ ଏକର ପିଛା ୨୦୦ ରୁ ୩୦୦ କେଜି କୃଷି ଚୂନ (Lime) ଜମିରେ ପ୍ରୟୋଗ କରନ୍ତୁ।",
        "hi": "मिट्टी अत्यधिक अम्लीय (pH {ph}) है। बुवाई से 15 दिन पहले प्रति एकड़ 200 - 300 किलो कृषि चूना या डोलोमाइट मिलाएं।",
    },
    "alkaline": {
        "en": "Soil is alkaline/saline (pH {ph}). Apply 100 kg Gypsum per acre and ensure adequate organic matter.",
        "or": "ମାଟି କ୍ଷାରୀୟ / ଲୁଣିଆ (pH {ph}) ଅଟେ। ଏକର ପିଛା ୧୦୦ କେଜି ଜିପସମ୍ ପ୍ରୟୋଗ କରନ୍ତୁ ଏବଂ ଜୈବିକ ପଦାର୍ଥ ବଢ଼ାନ୍ତୁ।",
        "hi": "मिट्टी क्षारीय/लवणीय (pH {ph}) है। प्रति एकड़ 100 किलो जिप्सम डालें और जैविक पदार्थ बढ़ाएं।",
    },
}


def _round(value, places=1):
    q = Decimal("0.1") if places == 1 else Decimal("0.01")
    return float(Decimal(str(value)).quantize(q, rounding=ROUND_HALF_UP))


def _liming_advice(ph, lang):
    lang = lang if lang in ("en", "or", "hi") else "en"
    if ph is None:
        key, ph = "normal", 6.5
    elif ph < 5.5:
        key = "acidic"
    elif ph > 7.8:
        key = "alkaline"
    else:
        key = "normal"
    return LIMING_ADVICE[key][lang].format(ph=ph)


@api_view(["POST"])
def calculate_view(request):
    """
    Body: {"crop": "paddy", "landArea": 2, "unit": "acre",
           "soilType": "alluvial", "irrigation": "canal", "soilPh": 6.5, "lang": "or"}

    Response shape == the frontend calculator's local `result` object.
    """
    data = request.data
    crop_id = (data.get("crop") or "").strip().lower()
    lang = (data.get("lang") or "en").lower()

    try:
        land_area = Decimal(str(data.get("landArea", 1)))
    except Exception:
        return Response({"detail": "landArea must be a number"}, status=400)
    if land_area <= 0:
        return Response({"detail": "landArea must be greater than 0"}, status=400)

    unit = (data.get("unit") or "acre").lower()
    if unit not in ACRE_PER_UNIT:
        return Response({"detail": f"Unsupported unit '{unit}'"}, status=400)

    profile = CropFertilizerProfile.objects.filter(crop_id=crop_id).first()
    if profile is None:
        return Response(
            {"detail": f"No fertilizer profile found for crop '{crop_id}'. "
                       f"Run: python manage.py seed_data, or add one in /admin."},
            status=404,
        )

    acres = land_area * ACRE_PER_UNIT[unit]
    soil_type = (data.get("soilType") or "alluvial").lower()
    soil_field = SOIL_MULTIPLIERS.get(soil_type)
    soil_multiplier = Decimal(str(getattr(profile, soil_field))) if soil_field else Decimal("1")

    total_urea = profile.urea_bags_per_acre * acres * soil_multiplier
    total_dap = profile.dap_bags_per_acre * acres * soil_multiplier
    total_mop = profile.mop_bags_per_acre * acres * soil_multiplier
    total_zinc = profile.zinc_kg_per_acre * acres          # zinc/FYM not soil-boosted (frontend parity)
    total_fym = profile.fym_tons_per_acre * acres

    yield_qty = profile.yield_qtl_per_acre * acres
    msp_price = profile.price_per_qtl
    estimated_revenue = yield_qty * msp_price

    basal = profile.basal_ratio or {}
    tillering = profile.tillering_ratio or {}
    flowering = profile.flowering_ratio or {}

    ph = None
    if data.get("soilPh") not in (None, ""):
        try:
            ph = float(data.get("soilPh"))
        except (TypeError, ValueError):
            ph = None

    payload = {
        "cropName": (profile.crop_name_or or profile.crop_name) if lang == "or"
                    else (profile.crop_name_hi or profile.crop_name) if lang == "hi"
                    else profile.crop_name,
        "acres": _round(acres, 2),
        "totalUrea": _round(total_urea),
        "totalDap": _round(total_dap),
        "totalMop": _round(total_mop),
        "totalZinc": _round(total_zinc),
        "totalFym": _round(total_fym),
        "yieldQty": _round(yield_qty),
        "estimatedRev": _round(estimated_revenue, 2),
        "mspPrice": float(msp_price),
        "limingAdvice": _liming_advice(ph, lang),
        "basalUrea": _round(total_urea * Decimal(str(basal.get("urea", 0)))),
        "basalDap": _round(total_dap * Decimal(str(basal.get("dap", 0)))),
        "basalMop": _round(total_mop * Decimal(str(basal.get("mop", 0)))),
        "tilleringUrea": _round(total_urea * Decimal(str(tillering.get("urea", 0)))),
        "floweringUrea": _round(total_urea * Decimal(str(flowering.get("urea", 0)))),
        "floweringMop": _round(total_mop * Decimal(str(flowering.get("mop", 0)))),
        "notes": {
            "basal": profile.basal_note,
            "tillering": profile.tillering_note,
            "flowering": profile.flowering_note,
        },
        "source": "backend",
    }
    return Response(payload)
