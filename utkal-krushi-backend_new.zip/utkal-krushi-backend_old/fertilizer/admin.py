from django.contrib import admin
from .models import CropFertilizerProfile

admin.site.register(CropFertilizerProfile)
