from rest_framework import serializers
from .models import Farmer


class FarmerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Farmer
        fields = [
            "id", "username", "phone", "district", "village",
            "preferred_lang", "land_area_acres",
        ]


class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, min_length=6)

    class Meta:
        model = Farmer
        fields = [
            "id", "username", "password", "phone", "district",
            "village", "preferred_lang", "land_area_acres",
        ]

    def create(self, validated_data):
        password = validated_data.pop("password")
        farmer = Farmer(**validated_data)
        farmer.set_password(password)
        farmer.save()
        return farmer
