from django.contrib.auth.models import AbstractUser
from django.db import models


class Farmer(AbstractUser):
    """Custom user model for a farmer's profile."""
    phone = models.CharField(max_length=15, unique=True)
    district = models.CharField(max_length=100, blank=True)
    village = models.CharField(max_length=100, blank=True)
    preferred_lang = models.CharField(
        max_length=5,
        choices=[("en", "English"), ("or", "Odia"), ("hi", "Hindi")],
        default="or",
    )
    land_area_acres = models.DecimalField(max_digits=6, decimal_places=2, null=True, blank=True)

    USERNAME_FIELD = "username"
    REQUIRED_FIELDS = ["phone"]

    def __str__(self):
        return f"{self.username} ({self.phone})"
