from django.contrib.auth import authenticate
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken

from .models import Farmer
from .serializers import RegisterSerializer, FarmerSerializer


def _tokens_for(farmer):
    refresh = RefreshToken.for_user(farmer)
    return {"access": str(refresh.access_token), "refresh": str(refresh)}


class RegisterView(APIView):
    """POST /api/auth/register  {username, password, phone, district, village, preferred_lang}"""

    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        farmer = serializer.save()
        return Response(
            {"farmer": FarmerSerializer(farmer).data, **_tokens_for(farmer)},
            status=status.HTTP_201_CREATED,
        )


class LoginView(APIView):
    """POST /api/auth/login  {username, password}"""

    def post(self, request):
        username = request.data.get("username")
        password = request.data.get("password")
        farmer = authenticate(request, username=username, password=password)
        if farmer is None:
            return Response({"detail": "Invalid credentials"}, status=status.HTTP_401_UNAUTHORIZED)
        return Response({"farmer": FarmerSerializer(farmer).data, **_tokens_for(farmer)})
