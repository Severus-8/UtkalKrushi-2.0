"""
Seed command - canonical data lives in backend `seed_json/*.json` (ported 1:1
from the React frontend's data files so API responses and offline fallbacks
never drift apart). Extra backend-only knowledge-base entries are defined here.

Usage: python manage.py seed_data
"""
import json
from pathlib import Path

from django.conf import settings
from django.core.management.base import BaseCommand

from cropdoctor.models import CropDisease
from fertilizer.models import CropFertilizerProfile
from mandi.models import MandiPrice
from schemes.models import Scheme

SEED_DIR = Path(settings.BASE_DIR) / "seed_json"


def _load(name):
    with open(SEED_DIR / name, encoding="utf-8") as fh:
        return json.load(fh)


# Curated symptom keywords per disease (English + Odia + Hindi tokens).
DISEASE_KEYWORDS = {
    "rice-blast": "blast,spindle,diamond,grey spot,gray spot,neck rot,paddy leaf spot,ଡଙ୍ଗା,ଧାନ ବ୍ଲାଷ୍ଟ,ପତ୍ର ପୋଡ଼ା,धान का झुलसा,झुलसा",
    "bacterial-leaf-blight": "blight,yellow leaf,wavy lesion,leaf margin,water soaked,bacterial leaf blight,blb,ପତ୍ରପୋଡ଼ା,ଧାର କଡ଼,धान का जीवाणु,पत्ती झुलसा",
    "yellow-stem-borer": "dead heart,white ear,stem borer,hollowed stem,central shoot dry,କାଣ୍ଡ ବିନ୍ଧା,ଡେଡ୍ ହାର୍ଟ,ଧଳା କେଣ୍ଡା,पीला तना छेदक,तना छेदक",
    "chilli-leaf-curl": "leaf curl,curl,curled leaves,whitefly,stunted,puckered,କୁଞ୍ଚିଆ,ଲଙ୍କା,मिर्च,पर्ण कुंचन,मिर्च की पत्ती मुड़ना",
    "tomato-early-blight": "brown ring,concentric ring,leaf spot,target spot,tomato,potato,early blight,alternaria,ଟମାଟୋ,ଆଗୁଆ ଝାଉଁଳା,टमाटर,अगेती झुलसा",
    "groundnut-tikka": "tikka,yellow halo,cercospora,groundnut,peanut,premature shedding,ଚିନାବାଦାମ,ଟିକ୍କା,मूंगफली,टिक्का रोग",
    "maize-fall-armyworm": "armyworm,pin hole,windowing,shot hole,saw dust,faecal pellets,whorl feeding,maize,corn,ଲକ୍ଷ୍ମଣୀ ପୋକ,ମକା,फॉल आर्मीवर्म,मक्का",
}

# Backend-only extras (not present in the frontend JSON) - kept for a superset KB.
EXTRA_DISEASES = [
    dict(
        disease_id="powdery-mildew", name="Powdery Mildew",
        name_or="ପାଉଡ଼ର ଫପୁସ ରୋଗ", name_hi="पाउडरी फफूंद (मिल्ड्यू)",
        crop="Pulses / Vegetables", severity="Medium",
        severity_color="text-yellow-700 bg-yellow-50 border-yellow-200",
        symptom_keywords="white powder,powdery,white coating,mildew,ଫପୁସ,ଧଳା ପାଉଡ଼ର,सफेद फफूंद,पाउडरी मिल्ड्यू",
        symptoms="White powdery fungal growth on leaves and stems, leading to yellowing and leaf drop.",
        organic_remedy="Spray a solution of neem oil (5ml/L) or diluted milk (1:9 with water) weekly.",
        chemical_treatment="Spray Wettable Sulphur 80% WP @ 2g/L or Hexaconazole 5% EC @ 2ml/L.",
        preventive_tips="Ensure good air circulation, avoid overhead irrigation in the evening, remove infected leaves.",
    ),
]

# Port of the frontend calculator's per-acre agronomy standards (FertilizerCalculator.jsx).
FERTILIZER_PROFILES = [
    dict(crop_id="paddy", crop_name="Paddy / Rice (ଧାନ)", crop_name_or="ଧାନ (Paddy)", crop_name_hi="धान / चावल",
         yield_qtl_per_acre=22, price_per_qtl=2300,
         urea_bags_per_acre=2.0, dap_bags_per_acre=1.0, mop_bags_per_acre=0.8, zinc_kg_per_acre=10, fym_tons_per_acre=2,
         basal_ratio={"urea": 0.25, "dap": 1.0, "mop": 0.5, "zinc": 1.0},
         tillering_ratio={"urea": 0.45}, flowering_ratio={"urea": 0.30, "mop": 0.5},
         basal_note="Apply full DAP + half MOP + 1/4th Urea + 10 kg Zinc at transplanting.",
         tillering_note="Top dress ~45% of Urea at 20-25 days after transplanting (active tillering).",
         flowering_note="Apply remaining Urea + remaining MOP at panicle initiation (40-45 days)."),
    dict(crop_id="ragi", crop_name="Ragi / Finger Millet (ମାଣ୍ଡିଆ)", crop_name_or="ମାଣ୍ଡିଆ (Finger Millet)", crop_name_hi="रागी / मड़ुआ",
         yield_qtl_per_acre=12, price_per_qtl=4290,
         urea_bags_per_acre=1.0, dap_bags_per_acre=0.6, mop_bags_per_acre=0.4, zinc_kg_per_acre=5, fym_tons_per_acre=1.5,
         basal_ratio={"urea": 0.5, "dap": 1.0, "mop": 1.0, "zinc": 1.0},
         tillering_ratio={"urea": 0.5}, flowering_ratio={},
         basal_note="Apply full DAP + full MOP + half Urea at sowing.",
         tillering_note="Top dress remaining Urea at 25-30 days after sowing.",
         flowering_note="No further application needed for short-duration ragi."),
    dict(crop_id="moong", crop_name="Green Gram / Moong (ମୁଗ)", crop_name_or="ମୁଗ ଡାଲି (Green Gram)", crop_name_hi="मूंग दाल",
         yield_qtl_per_acre=5.5, price_per_qtl=8682,
         urea_bags_per_acre=0.4, dap_bags_per_acre=0.8, mop_bags_per_acre=0.4, zinc_kg_per_acre=5, fym_tons_per_acre=1,
         basal_ratio={"urea": 1.0, "dap": 1.0, "mop": 1.0, "zinc": 1.0},
         tillering_ratio={}, flowering_ratio={},
         basal_note="Apply full dose of Urea, DAP and MOP at sowing along with Rhizobium seed treatment.",
         tillering_note="No top dressing normally required for short-duration pulses.",
         flowering_note="Foliar spray of 2% DAP solution at flowering can boost pod filling."),
    dict(crop_id="mustard", crop_name="Mustard / Rapeseed (ସୋରିଷ)", crop_name_or="ସୋରିଷ (Mustard)", crop_name_hi="सरसों",
         yield_qtl_per_acre=7, price_per_qtl=5650,
         urea_bags_per_acre=1.4, dap_bags_per_acre=0.8, mop_bags_per_acre=0.5, zinc_kg_per_acre=8, fym_tons_per_acre=1.5,
         basal_ratio={"urea": 0.5, "dap": 1.0, "mop": 1.0, "zinc": 1.0},
         tillering_ratio={"urea": 0.5}, flowering_ratio={},
         basal_note="Apply full DAP + MOP + half Urea at sowing, plus Sulphur @ 20 kg/acre (mustard is S-responsive).",
         tillering_note="Top dress remaining Urea at 25-30 DAS followed by the first irrigation.",
         flowering_note="Avoid late nitrogen; one irrigation at siliqua formation improves grain filling."),
    dict(crop_id="groundnut", crop_name="Groundnut (ଚିନାବାଦାମ)", crop_name_or="ଚିନାବାଦାମ (Groundnut)", crop_name_hi="मूंगफली",
         yield_qtl_per_acre=11, price_per_qtl=6783,
         urea_bags_per_acre=0.6, dap_bags_per_acre=1.0, mop_bags_per_acre=0.8, zinc_kg_per_acre=10, fym_tons_per_acre=2,
         basal_ratio={"urea": 1.0, "dap": 1.0, "mop": 1.0, "zinc": 1.0},
         tillering_ratio={}, flowering_ratio={},
         basal_note="Apply full Urea, DAP, MOP at sowing; Gypsum @ 100 kg/acre at early pegging (30 DAS).",
         tillering_note="Earth-up around 30-35 DAS and keep the pegging zone loose.",
         flowering_note="Ensure steady moisture during pegging and pod development; avoid nitrogen top-ups."),
    dict(crop_id="chilli", crop_name="Chilli / Capsicum (ଲଙ୍କା)", crop_name_or="ଲଙ୍କା (Chilli)", crop_name_hi="मिर्च",
         yield_qtl_per_acre=55, price_per_qtl=4200,
         urea_bags_per_acre=2.5, dap_bags_per_acre=1.2, mop_bags_per_acre=1.0, zinc_kg_per_acre=10, fym_tons_per_acre=3,
         basal_ratio={"urea": 0.3, "dap": 1.0, "mop": 0.5, "zinc": 1.0},
         tillering_ratio={"urea": 0.4}, flowering_ratio={"urea": 0.3, "mop": 0.5},
         basal_note="Apply full DAP + half MOP + 1/3rd Urea at transplanting with 3 tons FYM/acre.",
         tillering_note="Top dress 40% of Urea at 25-30 days after transplanting; mulch to conserve moisture.",
         flowering_note="Apply remaining Urea + remaining MOP at peak flowering; 2% DAP foliar spray aids fruit set."),
    dict(crop_id="maize", crop_name="Maize / Corn (ମକା)", crop_name_or="ମକା (Corn)", crop_name_hi="मक्का",
         yield_qtl_per_acre=24, price_per_qtl=2225,
         urea_bags_per_acre=2.2, dap_bags_per_acre=1.0, mop_bags_per_acre=0.8, zinc_kg_per_acre=10, fym_tons_per_acre=2,
         basal_ratio={"urea": 0.3, "dap": 1.0, "mop": 0.5, "zinc": 1.0},
         tillering_ratio={"urea": 0.4}, flowering_ratio={"urea": 0.3, "mop": 0.5},
         basal_note="Apply full DAP + half MOP + 1/3rd Urea + 10 kg Zinc Sulphate/acre at sowing.",
         tillering_note="Top dress 40% of Urea at knee-high stage (25-30 DAS).",
         flowering_note="Apply remaining Urea + remaining MOP at tasseling/silking for grain filling."),
]

# crops.json ids -> fertilizer crop ids (for extra display names if needed)
CROP_JSON_ID = {"paddy": "rice", "ragi": "ragi", "moong": "moong", "mustard": "mustard",
                "groundnut": "groundnut", "chilli": "chilli", "maize": None}


class Command(BaseCommand):
    help = "Seed canonical data (crop-doctor, fertilizer, mandi, schemes) from seed_json/."

    def handle(self, *args, **options):
        self._seed_crop_diseases()
        self._seed_fertilizer_profiles()
        self._seed_mandi_prices()
        self._seed_schemes()
        self.stdout.write(self.style.SUCCESS(
            f"Seed data loaded: {CropDisease.objects.count()} diseases, "
            f"{CropFertilizerProfile.objects.count()} fertilizer crops, "
            f"{MandiPrice.objects.count()} mandi entries, "
            f"{Scheme.objects.count()} schemes."
        ))

    def _seed_crop_diseases(self):
        diseases = []
        for d in _load("crop_diseases.json"):
            entry = dict(
                disease_id=d["id"], name=d["name"], name_or=d.get("nameOr", ""),
                name_hi=d.get("nameHi", ""), crop=d["crop"], severity=d["severity"],
                severity_color=d.get("severityColor", ""),
                symptom_keywords=DISEASE_KEYWORDS.get(d["id"], d.get("symptoms", "")),
                symptoms=d["symptoms"], symptoms_or=d.get("symptomsOr", ""),
                symptoms_hi=d.get("symptomsHi", ""),
                organic_remedy=d["organicRemedy"], organic_remedy_or=d.get("organicRemedyOr", ""),
                chemical_treatment=d["chemicalTreatment"],
                chemical_treatment_or=d.get("chemicalTreatmentOr", ""),
                preventive_tips=d["preventiveTips"], preventive_tips_or=d.get("preventiveTipsOr", ""),
                image_url=d.get("imageUrl", ""),
            )
            diseases.append(entry)
        diseases.extend(EXTRA_DISEASES)

        for d in diseases:
            CropDisease.objects.update_or_create(disease_id=d["disease_id"], defaults=d)
        # Remove stale knowledge-base entries no longer canonical.
        ids = {d["disease_id"] for d in diseases}
        stale = CropDisease.objects.exclude(disease_id__in=ids)
        for s in stale:
            self.stdout.write(f"  removing stale disease: {s.disease_id}")
            s.delete()

    def _seed_fertilizer_profiles(self):
        crops = {c["id"]: c for c in _load("crops.json")}
        for p in FERTILIZER_PROFILES:
            json_crop = crops.get(CROP_JSON_ID.get(p["crop_id"]) or "", {})
            p.setdefault("crop_name_or", json_crop.get("nameOr", ""))
            p.setdefault("crop_name_hi", json_crop.get("nameHi", ""))
            CropFertilizerProfile.objects.update_or_create(crop_id=p["crop_id"], defaults=p)

    def _seed_mandi_prices(self):
        prices = _load("mandi_prices.json")
        ids = []
        for p in prices:
            MandiPrice.objects.update_or_create(
                pk=p["id"],
                defaults=dict(
                    commodity=p["commodity"], commodity_or=p.get("commodityOr", ""),
                    commodity_hi=p.get("commodityHi", ""), variety=p.get("variety", ""),
                    mandi=p["mandi"], district=p["district"],
                    market_price=p["marketPrice"], msp_rate=p["mspRate"],
                    price_change=p["priceChange"], trend=p["trend"],
                    arrival_qty=p.get("arrivalQty", ""), last_updated=p.get("lastUpdated", ""),
                ),
            )
            ids.append(p["id"])
        stale = MandiPrice.objects.exclude(pk__in=ids)
        for s in stale:
            self.stdout.write(f"  removing stale mandi entry: {s}")
            s.delete()

    def _seed_schemes(self):
        schemes = _load("schemes.json")
        ids = []
        for s in schemes:
            Scheme.objects.update_or_create(
                scheme_id=s["id"],
                defaults=dict(
                    name=s["name"], name_or=s.get("nameOr", ""), name_hi=s.get("nameHi", ""),
                    gov_type=s.get("govType", "central"), category=s.get("category", "all"),
                    badge=s.get("badge", ""), icon=s.get("icon", ""),
                    subsidy_benefit=s.get("subsidyBenefit", ""),
                    subsidy_benefit_or=s.get("subsidyBenefitOr", ""),
                    subsidy_benefit_hi=s.get("subsidyBenefitHi", ""),
                    description=s.get("description", ""),
                    description_or=s.get("descriptionOr", ""),
                    description_hi=s.get("descriptionHi", ""),
                    eligibility="\n".join(s.get("eligibility", [])),
                    documents_needed="\n".join(s.get("documentsNeeded", [])),
                    official_url=s.get("officialUrl", ""),
                    helpline=s.get("helpline", ""),
                ),
            )
            ids.append(s["id"])
        stale = Scheme.objects.exclude(scheme_id__in=ids)
        for s in stale:
            self.stdout.write(f"  removing stale scheme: {s.scheme_id}")
            s.delete()
