from django.db import models


class Scheme(models.Model):
    scheme_id = models.SlugField(unique=True)
    name = models.CharField(max_length=300)
    name_or = models.CharField("Name (Odia)", max_length=300, blank=True)
    name_hi = models.CharField("Name (Hindi)", max_length=300, blank=True)
    gov_type = models.CharField(max_length=20, choices=[("odisha", "Odisha"), ("central", "Central")])
    category = models.CharField(max_length=100, default="all")
    badge = models.CharField(max_length=200, blank=True)
    icon = models.CharField(max_length=10, blank=True)
    subsidy_benefit = models.TextField()
    subsidy_benefit_or = models.TextField(blank=True)
    subsidy_benefit_hi = models.TextField(blank=True)
    description = models.TextField(blank=True)
    description_or = models.TextField(blank=True)
    description_hi = models.TextField(blank=True)
    eligibility = models.TextField(help_text="One item per line", blank=True)
    documents_needed = models.TextField(help_text="One item per line", blank=True)
    official_url = models.URLField(blank=True)
    helpline = models.CharField(max_length=200, blank=True)

    def __str__(self):
        return self.name

    def eligibility_list(self):
        return [x.strip() for x in self.eligibility.splitlines() if x.strip()]

    def documents_list(self):
        return [x.strip() for x in self.documents_needed.splitlines() if x.strip()]
