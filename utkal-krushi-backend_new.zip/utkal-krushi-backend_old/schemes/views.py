from rest_framework.decorators import api_view
from rest_framework.response import Response

from .models import Scheme
from .serializers import SchemeSerializer


@api_view(["GET"])
def schemes_view(request):
    """GET /api/schemes?category=all"""
    qs = Scheme.objects.all()
    category = request.GET.get("category")
    if category and category != "all":
        qs = qs.filter(category=category)
    return Response(SchemeSerializer(qs, many=True).data)
