from rest_framework import serializers
from .models import Scheme


class SchemeSerializer(serializers.ModelSerializer):
    """Shape mirrors the frontend's static `schemesData` entries exactly."""
    id = serializers.CharField(source="scheme_id")
    nameOr = serializers.CharField(source="name_or")
    nameHi = serializers.CharField(source="name_hi")
    govType = serializers.CharField(source="gov_type")
    badge = serializers.CharField()
    icon = serializers.CharField()
    subsidyBenefit = serializers.CharField(source="subsidy_benefit")
    subsidyBenefitOr = serializers.CharField(source="subsidy_benefit_or")
    subsidyBenefitHi = serializers.CharField(source="subsidy_benefit_hi")
    description = serializers.CharField()
    descriptionOr = serializers.CharField(source="description_or")
    descriptionHi = serializers.CharField(source="description_hi")
    eligibility = serializers.SerializerMethodField()
    documentsNeeded = serializers.SerializerMethodField()
    officialUrl = serializers.URLField(source="official_url")
    helpline = serializers.CharField()

    class Meta:
        model = Scheme
        fields = [
            "id", "name", "nameOr", "nameHi", "category", "govType", "badge", "icon",
            "subsidyBenefit", "subsidyBenefitOr", "subsidyBenefitHi",
            "description", "descriptionOr", "descriptionHi",
            "eligibility", "documentsNeeded", "officialUrl", "helpline",
        ]

    def get_eligibility(self, obj):
        return obj.eligibility_list()

    def get_documentsNeeded(self, obj):
        return obj.documents_list()
