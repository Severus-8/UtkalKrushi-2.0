"""
GET /api/weather?district=Bhubaneswar   (or ?lat=20.29&lon=85.82)

Proxies Open-Meteo (free, no API key) and returns BOTH:
  - the raw Open-Meteo-shaped `current` / `hourly` / `daily` blocks, so the
    React component can consume the payload directly with zero remapping, and
  - the friendly guide extras: `location` label + `sprayAdvisory`.
"""
import requests
from rest_framework.decorators import api_view
from rest_framework.response import Response

# A handful of Odisha districts with approximate coordinates so the frontend
# can request `?district=Bhubaneswar` instead of raw lat/lon.
DISTRICT_COORDS = {
    "bhubaneswar": (20.2961, 85.8245, "Bhubaneswar (Khordha)"),
    "khordha": (20.2961, 85.8245, "Bhubaneswar (Khordha)"),
    "cuttack": (20.4625, 85.8830, "Cuttack"),
    "bargarh": (21.3347, 83.6197, "Bargarh"),
    "puri": (19.8135, 85.8312, "Puri"),
    "sambalpur": (21.4669, 83.9756, "Sambalpur"),
    "berhampur": (19.3149, 84.7941, "Berhampur (Ganjam)"),
    "ganjam": (19.3149, 84.7941, "Berhampur (Ganjam)"),
    "balasore": (21.4942, 86.9317, "Balasore"),
    "rourkela": (22.2604, 84.8536, "Rourkela (Sundargarh)"),
    "sundargarh": (22.2604, 84.8536, "Rourkela (Sundargarh)"),
    "koraput": (18.8145, 82.7108, "Koraput"),
    "jeypore": (18.8556, 82.5732, "Jeypore (Koraput)"),
    "kendrapara": (20.5014, 86.8617, "Kendrapara"),
    "dhenkanal": (20.6706, 85.5989, "Dhenkanal"),
    "angul": (20.8381, 85.0975, "Angul"),
    "jajpur": (20.8337, 86.3363, "Jajpur"),
    "bhadrak": (21.0562, 86.4977, "Bhadrak"),
    "nayagarh": (20.0937, 85.0975, "Nayagarh"),
    "bolangir": (20.7084, 83.4759, "Balangir"),
    "titlagarh": (20.5333, 83.1550, "Titlagarh (Balangir)"),
    "kalahandi": (20.1848, 83.4681, "Kalahandi"),
    "rayagada": (19.1719, 83.4157, "Rayagada"),
    "phulbani": (20.4770, 84.2307, "Kandhamal (Phulbani)"),
    "baripada": (21.9419, 86.7217, "Baripada (Mayurbhanj)"),
}


def _spray_advisory(wind_speed, precipitation):
    if precipitation and precipitation > 0.5:
        return {"status": "unsafe", "message": "Avoid spraying - Rain expected/occurring"}
    if wind_speed and wind_speed > 15:
        return {"status": "caution", "message": "Use caution - High wind speed may cause drift"}
    return {"status": "safe", "message": "Safe to spray - Low wind & no rain expected"}


@api_view(["GET"])
def weather_view(request):
    district = request.GET.get("district", "").strip().lower()
    lat = request.GET.get("lat")
    lon = request.GET.get("lon")
    location_label = request.GET.get("district") or "Bhubaneswar (Khordha)"

    if district in DISTRICT_COORDS:
        lat, lon, location_label = DISTRICT_COORDS[district]
    elif not (lat and lon):
        lat, lon, location_label = DISTRICT_COORDS["bhubaneswar"]

    try:
        resp = requests.get(
            "https://api.open-meteo.com/v1/forecast",
            params={
                "latitude": lat,
                "longitude": lon,
                "current": "temperature_2m,apparent_temperature,relative_humidity_2m,"
                           "precipitation,rain,weather_code,wind_speed_10m,wind_direction_10m,cloud_cover",
                "hourly": "temperature_2m,precipitation_probability,weather_code",
                "daily": "weather_code,temperature_2m_max,temperature_2m_min,"
                         "precipitation_sum,precipitation_probability_max",
                "timezone": "Asia/Kolkata",
                "forecast_days": 5,
            },
            timeout=8,
        )
        resp.raise_for_status()
        data = resp.json()
    except requests.RequestException as exc:
        return Response({"detail": f"Weather provider error: {exc}"}, status=502)

    current = data.get("current", {})
    payload = {
        # Raw blocks (identical structure to api.open-meteo.com) for the frontend
        "current": current,
        "hourly": data.get("hourly", {}),
        "daily": data.get("daily", {}),
        # Friendly guide extras
        "location": location_label,
        "latitude": lat,
        "longitude": lon,
        "temperature": current.get("temperature_2m"),
        "apparentTemperature": current.get("apparent_temperature"),
        "humidity": current.get("relative_humidity_2m"),
        "windSpeed": current.get("wind_speed_10m"),
        "precipitation": current.get("precipitation"),
        "weatherCode": current.get("weather_code"),
        "sprayAdvisory": _spray_advisory(current.get("wind_speed_10m"), current.get("precipitation")),
    }
    return Response(payload)
