# Weather has a single endpoint; it's wired directly in config/urls.py.
