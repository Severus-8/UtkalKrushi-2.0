from django.db import models
from django.conf import settings


class LedgerEntry(models.Model):
    """A farmer's per-crop expense/profit khata (ledger) record."""
    farmer = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="ledger_entries",
        null=True, blank=True,
    )
    crop = models.CharField(max_length=200)
    land_area = models.DecimalField(max_digits=6, decimal_places=2)

    expense_seed = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    expense_fertilizer = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    expense_labor = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    expense_machinery = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    expense_irrigation = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    expense_other = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    expected_yield = models.DecimalField(max_digits=8, decimal_places=2)
    selling_price = models.DecimalField(max_digits=8, decimal_places=2)

    created_at = models.DateTimeField(auto_now_add=True)

    @property
    def total_expenses(self):
        return (
            self.expense_seed + self.expense_fertilizer + self.expense_labor
            + self.expense_machinery + self.expense_irrigation + self.expense_other
        )

    @property
    def gross_revenue(self):
        return self.expected_yield * self.selling_price

    @property
    def net_profit(self):
        return self.gross_revenue - self.total_expenses

    def __str__(self):
        return f"{self.crop} - {self.created_at:%Y-%m-%d}"
