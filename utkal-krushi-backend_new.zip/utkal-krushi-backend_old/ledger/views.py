from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response

from .models import LedgerEntry
from .serializers import LedgerEntrySerializer


@api_view(["GET", "POST", "DELETE"])
@permission_classes([AllowAny])
def ledger_view(request):
    """
    GET    /api/ledger        -> list entries (for the logged-in farmer, if authenticated)
    POST   /api/ledger/save   -> create a new entry
    DELETE /api/ledger?id=3   -> delete an entry (demo-friendly; tighten auth in production)
    """
    if request.method == "GET":
        qs = LedgerEntry.objects.all()
        if request.user.is_authenticated:
            qs = qs.filter(farmer=request.user)
        qs = qs.order_by("-created_at")
        return Response(LedgerEntrySerializer(qs, many=True).data)

    if request.method == "DELETE":
        entry_id = request.query_params.get("id") or request.data.get("id")
        if not entry_id:
            return Response({"detail": "id query parameter is required"}, status=400)
        qs = LedgerEntry.objects.all()
        if request.user.is_authenticated:
            qs = qs.filter(farmer=request.user)
        deleted, _ = qs.filter(pk=entry_id).delete()
        if not deleted:
            return Response({"detail": "Entry not found"}, status=404)
        return Response({"detail": "Deleted", "id": entry_id}, status=200)

    serializer = LedgerEntrySerializer(data=request.data, context={"request": request})
    serializer.is_valid(raise_exception=True)
    entry = serializer.save()
    return Response(LedgerEntrySerializer(entry).data, status=201)
