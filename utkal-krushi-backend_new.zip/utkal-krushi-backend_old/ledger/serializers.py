from rest_framework import serializers
from .models import LedgerEntry


class LedgerEntrySerializer(serializers.ModelSerializer):
    farmerId = serializers.SerializerMethodField()
    landArea = serializers.DecimalField(source="land_area", max_digits=6, decimal_places=2)
    expenses = serializers.SerializerMethodField()
    totalExpenses = serializers.DecimalField(source="total_expenses", max_digits=10, decimal_places=2, read_only=True)
    expectedYield = serializers.DecimalField(source="expected_yield", max_digits=8, decimal_places=2)
    sellingPrice = serializers.DecimalField(source="selling_price", max_digits=8, decimal_places=2)
    grossRevenue = serializers.DecimalField(source="gross_revenue", max_digits=12, decimal_places=2, read_only=True)
    netProfit = serializers.DecimalField(source="net_profit", max_digits=12, decimal_places=2, read_only=True)

    class Meta:
        model = LedgerEntry
        fields = [
            "id", "farmerId", "crop", "landArea", "expenses", "totalExpenses",
            "expectedYield", "sellingPrice", "grossRevenue", "netProfit", "created_at",
        ]

    def get_farmerId(self, obj):
        return obj.farmer_id and f"FID-{obj.farmer_id:05d}"

    def get_expenses(self, obj):
        return {
            "seed": obj.expense_seed, "fertilizer": obj.expense_fertilizer,
            "labor": obj.expense_labor, "machinery": obj.expense_machinery,
            "irrigation": obj.expense_irrigation, "other": obj.expense_other,
        }

    def create(self, validated_data):
        expenses = self.initial_data.get("expenses", {}) or {}
        entry = LedgerEntry.objects.create(
            farmer=self.context["request"].user if self.context["request"].user.is_authenticated else None,
            crop=validated_data["crop"],
            land_area=validated_data["land_area"],
            expected_yield=validated_data["expected_yield"],
            selling_price=validated_data["selling_price"],
            expense_seed=expenses.get("seed", 0),
            expense_fertilizer=expenses.get("fertilizer", 0),
            expense_labor=expenses.get("labor", 0),
            expense_machinery=expenses.get("machinery", 0),
            expense_irrigation=expenses.get("irrigation", 0),
            expense_other=expenses.get("other", 0),
        )
        return entry
