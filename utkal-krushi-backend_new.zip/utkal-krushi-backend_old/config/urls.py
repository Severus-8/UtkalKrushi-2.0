"""
Root URL configuration.

Paths mirror BACKEND_API_GUIDE.md exactly (no trailing slashes) so the
React frontend's src/config/api.js endpoint constants work unchanged.
"""
from django.contrib import admin
from django.urls import include, path

from accounts.views import RegisterView, LoginView
from weather.views import weather_view
from cropdoctor.views import diagnose_view
from fertilizer.views import calculate_view
from mandi.views import mandi_prices_view
from schemes.views import schemes_view
from chatbot.views import chatbot_view
from ledger.views import ledger_view

urlpatterns = [
    path("admin/", admin.site.urls),

    # Auth
    path("api/auth/register", RegisterView.as_view()),
    path("api/auth/login", LoginView.as_view()),

    # A. Weather & agro-advisory
    path("api/weather", weather_view),

    # B. AI Crop Doctor
    path("api/crop-doctor/diagnose", diagnose_view),

    # C. Fertilizer & yield calculator
    path("api/fertilizer/calculate", calculate_view),

    # C2. Smart Crop Yield -- dataset-validated ML models (crop suitability +
    # Odisha yield prediction). See smartyield/ml/artifacts/metrics.json.
    path("api/smartyield/", include("smartyield.urls")),

    # D. Mandi market rates & MSP
    path("api/mandi/prices", mandi_prices_view),

    # E. Government schemes & subsidies
    path("api/schemes", schemes_view),

    # F. Krushi AI chatbot
    path("api/chatbot/ask", chatbot_view),

    # G. Farmer ledger (khata) -- GET list / POST save, same URL like the guide
    path("api/ledger", ledger_view),
    path("api/ledger/save", ledger_view),
    # Sensor demo
    path("api/sensors/", include("sensors.urls")),
]
