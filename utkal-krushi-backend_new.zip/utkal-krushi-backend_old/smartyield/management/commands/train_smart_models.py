from django.core.management.base import BaseCommand

from smartyield.ml import train


class Command(BaseCommand):
    help = ("Trains the crop-suitability classifier and the Odisha yield "
            "regressor from real datasets, and writes validation metrics "
            "to smartyield/ml/artifacts/metrics.json.")

    def handle(self, *args, **options):
        metrics = train.run()
        self.stdout.write(self.style.SUCCESS(
            "Done. Crop-suitability holdout accuracy: "
            f"{metrics['crop_suitability_model']['holdout_test_accuracy']:.2%}  |  "
            "Yield model holdout R2: "
            f"{metrics['yield_prediction_model']['holdout_r2']:.3f}"
        ))
