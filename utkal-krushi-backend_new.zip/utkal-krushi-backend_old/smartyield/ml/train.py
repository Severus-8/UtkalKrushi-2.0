"""
Trains and validates the two models behind the Smart Crop Yield & Fertilizer
Calculator, using real datasets (not synthetic data):

1. Crop-suitability classifier
   Dataset: Crop_recommendation.csv (2,200 samples; N, P, K, temperature,
   humidity, pH, rainfall -> one of 22 crops). Widely used Indian
   soil/climate dataset (source lineage: Kaggle "Crop Recommendation
   Dataset", originally compiled from Indian agro-climatic records).
   Answers: "given this soil + weather, which crops actually suit it?"

2. Yield predictor (regression)
   Dataset: District-wise, season-wise crop production statistics for
   Odisha, 1997-2020 (official Govt. of India / data.gov.in series,
   16,025 records across 30 districts and 7 of our crops). Answers:
   "given crop + district + season + year-trend, what yield (qtl/acre)
   should we actually expect?" -- this is what calibrates/replaces the
   old hard-coded per-crop constant in fertilizer/models.py.

Run with:  python manage.py train_smart_models
Outputs (smartyield/ml/artifacts/):
   crop_classifier.joblib, crop_label_encoder.joblib,
   yield_regressor.joblib, yield_district_encoder.joblib,
   yield_crop_encoder.joblib, metrics.json
"""
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.metrics import (
    accuracy_score, f1_score, mean_absolute_error,
    mean_squared_error, r2_score,
)
from sklearn.model_selection import KFold, StratifiedKFold, cross_val_score, train_test_split
from sklearn.preprocessing import LabelEncoder
import joblib

BASE_DIR = Path(__file__).resolve().parent.parent  # smartyield/
DATA_DIR = BASE_DIR / "datasets"
ART_DIR = BASE_DIR / "ml" / "artifacts"
ART_DIR.mkdir(parents=True, exist_ok=True)

# App's OLD hard-coded static baselines (fertilizer/... seed_data.py) kept
# here only so the training report can show the before/after comparison.
OLD_STATIC_BASELINE_QTL_PER_ACRE = {
    "paddy": 22, "ragi": 12, "moong": 5.5, "mustard": 7,
    "groundnut": 11, "chilli": 55, "maize": 24,
}
# App crop_id -> government dataset crop label
APP_TO_GOVT_CROP = {
    "paddy": "Rice", "ragi": "Ragi", "moong": "Moong(Green Gram)",
    "mustard": "Rapeseed &Mustard", "groundnut": "Groundnut",
    "chilli": "Dry Chillies", "maize": "Maize",
}
HA_PER_ACRE = 1 / 2.471  # matches fertilizer/views.py ACRE_PER_UNIT


def _tons_ha_to_qtl_acre(tons_per_ha):
    return tons_per_ha * 10 * HA_PER_ACRE


def train_crop_classifier():
    df = pd.read_csv(DATA_DIR / "crop_recommendation.csv")
    feature_cols = ["N", "P", "K", "temperature", "humidity", "ph", "rainfall"]
    X = df[feature_cols]
    y_raw = df["label"]

    le = LabelEncoder()
    y = le.fit_transform(y_raw)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    clf = RandomForestClassifier(n_estimators=200, random_state=42, n_jobs=-1)
    clf.fit(X_train, y_train)

    y_pred = clf.predict(X_test)
    test_accuracy = accuracy_score(y_test, y_pred)
    test_f1_macro = f1_score(y_test, y_pred, average="macro")

    # NOTE: the source CSV is ordered in contiguous per-crop blocks, so CV
    # folds must be explicitly shuffled -- an un-shuffled KFold would hand
    # some folds zero training examples of certain crops.
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    cv_scores = cross_val_score(clf, X, y, cv=skf, scoring="accuracy")

    # Refit on all data for the deployed model (common practice once CV/
    # holdout accuracy is reported -- more data = better real predictions).
    clf_final = RandomForestClassifier(n_estimators=200, random_state=42, n_jobs=-1)
    clf_final.fit(X, y)

    joblib.dump(clf_final, ART_DIR / "crop_classifier.joblib", compress=3)
    joblib.dump(le, ART_DIR / "crop_label_encoder.joblib", compress=3)

    importances = dict(zip(feature_cols, clf_final.feature_importances_.round(4)))

    return {
        "dataset": "Crop_recommendation.csv",
        "dataset_source": "Indian soil/climate crop-recommendation dataset "
                           "(N, P, K, temperature, humidity, pH, rainfall)",
        "n_samples": int(len(df)),
        "n_classes": int(len(le.classes_)),
        "classes": sorted(le.classes_.tolist()),
        "holdout_test_accuracy": round(float(test_accuracy), 4),
        "holdout_test_f1_macro": round(float(test_f1_macro), 4),
        "cv_5fold_accuracy_mean": round(float(cv_scores.mean()), 4),
        "cv_5fold_accuracy_std": round(float(cv_scores.std()), 4),
        "feature_importances": importances,
        "model": "RandomForestClassifier(n_estimators=200)",
    }


def train_yield_regressor():
    df = pd.read_csv(DATA_DIR / "odisha_crop_yield_1997_2020.csv")
    app_crops = list(APP_TO_GOVT_CROP.values())
    df = df[df["crop"].isin(app_crops)].copy()
    df = df[(df["area"] > 0) & (df["production"] >= 0)]
    df["qtl_per_acre"] = _tons_ha_to_qtl_acre(df["yield"])
    # Drop rows with an implausible yield (data entry artefacts / area outliers)
    df = df[(df["qtl_per_acre"] >= 0) & (df["qtl_per_acre"] < df["qtl_per_acre"].quantile(0.995))]

    district_le = LabelEncoder()
    crop_le = LabelEncoder()
    season_le = LabelEncoder()
    df["district_enc"] = district_le.fit_transform(df["district"])
    df["crop_enc"] = crop_le.fit_transform(df["crop"])
    df["season_enc"] = season_le.fit_transform(df["season"])

    feature_cols = ["district_enc", "crop_enc", "season_enc", "year"]
    X = df[feature_cols]
    y = df["qtl_per_acre"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    reg = RandomForestRegressor(n_estimators=300, max_depth=12, random_state=42, n_jobs=-1)
    reg.fit(X_train, y_train)

    y_pred = reg.predict(X_test)
    mae = mean_absolute_error(y_test, y_pred)
    rmse = mean_squared_error(y_test, y_pred) ** 0.5
    r2 = r2_score(y_test, y_pred)

    # NOTE: rows are grouped in contiguous district/crop/year blocks in the
    # source CSV -- an un-shuffled KFold would hold out whole district/crop
    # combinations at once and badly understate real accuracy. Shuffle.
    kf = KFold(n_splits=5, shuffle=True, random_state=42)
    cv_r2 = cross_val_score(reg, X, y, cv=kf, scoring="r2")

    reg_final = RandomForestRegressor(n_estimators=300, max_depth=12, random_state=42, n_jobs=-1)
    reg_final.fit(X, y)

    joblib.dump(reg_final, ART_DIR / "yield_regressor.joblib", compress=3)
    joblib.dump(district_le, ART_DIR / "yield_district_encoder.joblib", compress=3)
    joblib.dump(crop_le, ART_DIR / "yield_crop_encoder.joblib", compress=3)
    joblib.dump(season_le, ART_DIR / "yield_season_encoder.joblib", compress=3)

    # Before/after calibration table vs the app's old static constants,
    # using the last 10 years (2011-2020) weighted average as "current
    # real-world yield" for each crop.
    recent = df[df["year"] >= 2011]
    calibration = {}
    for app_id, govt_crop in APP_TO_GOVT_CROP.items():
        sub = recent[recent["crop"] == govt_crop]
        if sub.empty:
            continue
        weighted_qtl_acre = _tons_ha_to_qtl_acre(sub["production"].sum() / sub["area"].sum())
        old_static = OLD_STATIC_BASELINE_QTL_PER_ACRE[app_id]
        calibration[app_id] = {
            "govt_crop_label": govt_crop,
            "govt_avg_qtl_per_acre_2011_2020": round(float(weighted_qtl_acre), 2),
            "app_old_static_qtl_per_acre": old_static,
            "old_baseline_overstatement_pct": round(
                (old_static - weighted_qtl_acre) / weighted_qtl_acre * 100, 1
            ),
            "n_district_year_season_rows": int(len(sub)),
        }

    return {
        "dataset": "Odisha district-wise crop production statistics, 1997-2020",
        "dataset_source": "Government of India / data.gov.in official series "
                           "(district, season, crop, area, production, yield)",
        "n_samples": int(len(df)),
        "districts_covered": int(df["district"].nunique()),
        "crops_covered": sorted(df["crop"].unique().tolist()),
        "years_covered": [int(df["year"].min()), int(df["year"].max())],
        "holdout_mae_qtl_per_acre": round(float(mae), 2),
        "holdout_rmse_qtl_per_acre": round(float(rmse), 2),
        "holdout_r2": round(float(r2), 4),
        "cv_5fold_r2_mean": round(float(cv_r2.mean()), 4),
        "cv_5fold_r2_std": round(float(cv_r2.std()), 4),
        "model": "RandomForestRegressor(n_estimators=300, max_depth=12)",
        "calibration_vs_old_static_baseline": calibration,
    }


def run():
    print("Training crop-suitability classifier on Crop_recommendation.csv ...")
    clf_report = train_crop_classifier()
    print(f"  holdout accuracy = {clf_report['holdout_test_accuracy']:.4f}  "
          f"(5-fold CV = {clf_report['cv_5fold_accuracy_mean']:.4f} "
          f"+/- {clf_report['cv_5fold_accuracy_std']:.4f})")

    print("Training yield regressor on Odisha govt. yield data (1997-2020) ...")
    reg_report = train_yield_regressor()
    print(f"  holdout R2 = {reg_report['holdout_r2']:.4f}  "
          f"MAE = {reg_report['holdout_mae_qtl_per_acre']:.2f} qtl/acre  "
          f"(5-fold CV R2 = {reg_report['cv_5fold_r2_mean']:.4f})")

    metrics = {
        "crop_suitability_model": clf_report,
        "yield_prediction_model": reg_report,
    }
    with open(ART_DIR / "metrics.json", "w", encoding="utf-8") as fh:
        json.dump(metrics, fh, indent=2)
    print(f"\nSaved model artifacts + metrics.json -> {ART_DIR}")
    return metrics


if __name__ == "__main__":
    run()
