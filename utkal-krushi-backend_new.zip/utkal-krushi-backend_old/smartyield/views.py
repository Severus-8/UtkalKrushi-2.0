from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from .ml_models import get_yield_prediction, get_crop_recommendations, get_model_info

@api_view(["GET"])
@permission_classes([AllowAny])
def model_info(request):
    return Response(get_model_info())

@api_view(["POST"])
@permission_classes([AllowAny])
def predict_yield(request):
    d = request.data
    result = get_yield_prediction(
        crop_name=d.get("crop", "paddy"),
        area=float(d.get("area", 1)),
        unit=d.get("unit", "acre"),
        soil_type=d.get("soil_type", "alluvial"),
        soil_ph=float(d.get("soil_ph", 6.5)),
        rainfall=float(d.get("rainfall_mm", 1200)),
        temperature=float(d.get("temperature_c", 28)),
        moisture=float(d.get("moisture_pct", 60)),
    )
    return Response(result)

@api_view(["POST"])
@permission_classes([AllowAny])
def recommend_crop(request):
    d = request.data
    recs = get_crop_recommendations(
        N=float(d.get("N", 80)),
        P=float(d.get("P", 40)),
        K=float(d.get("K", 40)),
        temperature=float(d.get("temperature", 28)),
        humidity=float(d.get("humidity", 60)),
        ph=float(d.get("ph", 6.5)),
        rainfall=float(d.get("rainfall", 1200)),
    )
    return Response({"recommendations": recs})
