from django.apps import AppConfig


class SmartyieldConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "smartyield"
    verbose_name = "Smart Crop Yield (ML)"
